<html lang="en"><head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
<title>Salesforce Services Lead Engage</title>
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/animatecss/2.1.0/animate.min.css"><!-- load animate -->
 <!-- <link rel="stylesheet" href="https://s.mlcdn.co/animate.css"> -->
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script><style></style><style></style> 
<style type="text/css">

#background {
    position: fixed;
    top: 50%;
    left: 50%;
    min-width: 100%;
    min-height: 100%;
    width: auto;
    height: auto;
    z-index: -1;
    -webkit-transform: translateX(-50%) translateY(-50%);
    transform: translateX(-50%) translateY(-50%);  
    background-size: cover;
   background: #3E76D3;
	<!-- opacity: 0.3; -->
}

#background1 {
position: fixed;
    top: 50%;
    left: 50%;
    min-width: 100%;
    min-height: 100%;
    width: auto;
    height: auto;
    z-index: 2;
    -webkit-transform: translateX(-50%) translateY(-50%);
    transform: translateX(-50%) translateY(-50%);  
    background-size: cover;
      <!-- background: rgba(240, 76, 35, 0.7); -->
}

.container {
max-width: 890px;

}

#signup_form {
max-width: auto;
text-align: left;
}

#tab1 {
background-color: #ffffff;
}
.footer {
padding: 20px 0;
margin-top: 10px;
border-top: 1px solid #e5e5e5;
background-color: #f5f5f5;
}

.breadcrumb {
padding: 15px 15px;
margin-bottom: 5px;
list-style: none;
background-color: #f5f5f5;
border-radius: 4px;
}

.btn-responsive{
 color: black;
border-width: 4px;
 height: 54px;
border-style: solid;
font-family: Roboto;
font-size: 18px;
padding-left:7px;
padding-top: 9px;
padding-right: 7px;
border-radius:0;
border-color: rgba(96, 148, 199, 1);
white-space: normal !important;
word-wrap: break-word;

}
.btn-responsive:hover{
color: white;
border-color:  rgb(115, 191, 215);
background-color: rgb(115, 191, 215);

}


.btn-responsive-lg:hover
{

color: white;
border-color: rgb(115, 191, 215);
background-color: rgb(115, 191, 215);

}

.alert {
padding: 15px;
margin-bottom: 10px;
border: 1px solid transparent;
border-radius: 4px;
}
label.error {
color: #f00;
font-weight: 400;
}
#div1 {
margin-top: 50px;
margin-bottom: 5px;
}
#para1 {
font-family:  Roboto;
}

.panel-primary>.panel-heading {
color: #fff;
background-color: #428bca;
border-color: #428bca;
}

.col-md-6{
position: relative;
min-height: 1px;
padding-right: 15px;
padding-left: 15px;
}
@media (max-width: 768px) {
  .btn-responsive {
    font-size:80%;
    line-height: 1;
    border-radius:2px;
  }
}
</style>

<style>

#h2 { animation-delay:2.2s; -moz-animation-delay:2.2s; -webkit-animation-delay:2.2s; }
#para1 { animation-delay:2.4s; -moz-animation-delay:2.6s; -webkit-animation-delay:2.4s; }
#para2 { animation-delay:2.5s; -moz-animation-delay:3.6s; -webkit-animation-delay:2.5s; }

@-webkit-keyframes zoomIn {
  from {
    opacity: 0;
    -webkit-transform: scale3d(.3, .3, .3);
    transform: scale3d(.3, .3, .3);
  }

  50% {
    opacity: 1;
  }
}

@keyframes zoomIn {
  from {
    opacity: 0;
    -webkit-transform: scale3d(.3, .3, .3);
    transform: scale3d(.3, .3, .3);
  }

  50% {
    opacity: 1;
  }
}

.zoomIn {
  -webkit-animation-name: zoomIn;
  animation-name: zoomIn;
}

<!--  fadein start -->
@-webkit-keyframes fadeIn {
  from {
    opacity: 0;
  }

  to {
    opacity: 1;
  }
}

@keyframes fadeIn {
  from {
    opacity: 0;
  }

  to {
    opacity: 1;
  }
}

.fadeIn {
  -webkit-animation-name: fadeIn;
  animation-name: fadeIn;
}
 <!--fadein end-->
</style>


<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.0.0.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/jquery.validate.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/jquery.validate.min.js"></script>
<script type="text/javascript" charset="utf-8">
$(document).ready(function() { 
$.validator.addMethod('nofreeemail', function (value) { 
		return /^([\w-.]+@(?!gmail\.com)(?!yahoo\.com)(?!hotmail\.com)(?!facebook\.com)(?!gmail\.com)(?!gmx\.com)(?!googlemail\.com)(?!hotmail\.com)(?!mac\.com)(?!me\.com)(?!mail\.com)(?!msn\.com)(?!yahoo\.com)(?!aol\.com)(?!google\.com)(?!live\.com)(?!att\.net)(?!comcast\.net)(?!sbcglobal\.net)(?!verizon\.net)([\w-]+.)+[\w-]{2,4})?$/.test(value);
	}, 'Free email addresses are not allowed.');
		$("#signup_form").validate({
		errorElement: 'label',
			rules: {
				name: {
					required: true,
				},
				company_name: {
					required: true,
				},
				email: {
					required: true,
					nofreeemail: true
				},
				contact_title: {
					required: true,
				},
				zip: {
					required: true,
				},
				address: {
					required: true,
				},
				city: {
					required: true,
				},
				region: {
					required: true,
				},
				country: {
					required: true,
				},
				std1: {
					required: true,
				},
				std2: {
					required: true,
				},
				std3: {
					required: true,
				},
				std5: {
					required: true,
				},
				std6: {
					required: true,
				},
				std4:  {
					required: true,
				},
				company_size:  {
					required: true,
				},
				areas:  {
					required: true,
				},
				phone:  {
					required: true,
				},
				state:  {
					required: true,
				},
				
				
				cust1:  {
					required: true,
				}
				
			},
			messages: {
				name: {
					required: "The details are incorrect/incomplete"
				},
				company_name: {
					required: "The details are incorrect/incomplete"
				},
				email: {
					required: "Please enter an email address",
					nofreeemail: "Please enter your business email, generic email not allowed"
				},
				contact_title: {
					required: "The details are incorrect/incomplete"
				},
				zip: {
					required: "The details are incorrect/incomplete"
				},
				address: {
					required: "The details are incorrect/incomplete"
				},
				city: {
					required: "The details are incorrect/incomplete"
				},
				region: {
					required: "The details are incorrect/incomplete"
				},
				country: {
					required: "The details are incorrect/incomplete"
				},
				std1: {
					required: "The details are incorrect/incomplete"
				},
				std2: {
					required: "The details are incorrect/incomplete"
				},
				std3: {
					required: "The details are incorrect/incomplete"
				},
				std5: {
					required: "The details are incorrect/incomplete"
				},
				std6: {
					required: "The details are incorrect/incomplete"
				},
				std4:{
					required: "The details are incorrect/incomplete"
				},
				company_size:{
					required: "The details are incorrect/incomplete"
				},
				areas:{
					required: "The details are incorrect/incomplete"
				},
				phone:{
					required: "The details are incorrect/incomplete"
				},
				state:{
					required: "The details are incorrect/incomplete"
				},
				
				
				cust1:{
					required: "The details are incorrect/incomplete"
				}
					
			}
		});
});

</script>



<style></style>









<script async="" src="https://negbar.ad-blocker.org/chrome/adblocker-chromeglobalinjectjs.js"></script><style type="text/css" data-styled-components="FiaaB gTcftA caPIRE" data-styled-components-is-local="true">
/* sc-component-id: sc-keyframes-FiaaB */
@-webkit-keyframes FiaaB{100%{-webkit-transform:rotate(360deg);-ms-transform:rotate(360deg);transform:rotate(360deg);}}@keyframes FiaaB{100%{-webkit-transform:rotate(360deg);-ms-transform:rotate(360deg);transform:rotate(360deg);}}
/* sc-component-id: sc-keyframes-gTcftA */
@-webkit-keyframes gTcftA{10%,90%{-webkit-transform:translate3d(-1px,0,0);-ms-transform:translate3d(-1px,0,0);transform:translate3d(-1px,0,0);}20%,80%{-webkit-transform:translate3d(2px,0,0);-ms-transform:translate3d(2px,0,0);transform:translate3d(2px,0,0);}30%,50%,70%{-webkit-transform:translate3d(-4px,0,0);-ms-transform:translate3d(-4px,0,0);transform:translate3d(-4px,0,0);}40%,60%{-webkit-transform:translate3d(4px,0,0);-ms-transform:translate3d(4px,0,0);transform:translate3d(4px,0,0);}}@keyframes gTcftA{10%,90%{-webkit-transform:translate3d(-1px,0,0);-ms-transform:translate3d(-1px,0,0);transform:translate3d(-1px,0,0);}20%,80%{-webkit-transform:translate3d(2px,0,0);-ms-transform:translate3d(2px,0,0);transform:translate3d(2px,0,0);}30%,50%,70%{-webkit-transform:translate3d(-4px,0,0);-ms-transform:translate3d(-4px,0,0);transform:translate3d(-4px,0,0);}40%,60%{-webkit-transform:translate3d(4px,0,0);-ms-transform:translate3d(4px,0,0);transform:translate3d(4px,0,0);}}
/* sc-component-id: sc-keyframes-caPIRE */
@-webkit-keyframes caPIRE{0%{-webkit-transform:scale(.75);-ms-transform:scale(.75);transform:scale(.75);}20%{-webkit-transform:scale(1);-ms-transform:scale(1);transform:scale(1);}40%{-webkit-transform:scale(.75);-ms-transform:scale(.75);transform:scale(.75);}60%{-webkit-transform:scale(1);-ms-transform:scale(1);transform:scale(1);}80%{-webkit-transform:scale(.75);-ms-transform:scale(.75);transform:scale(.75);}100%{-webkit-transform:scale(.75);-ms-transform:scale(.75);transform:scale(.75);}}@keyframes caPIRE{0%{-webkit-transform:scale(.75);-ms-transform:scale(.75);transform:scale(.75);}20%{-webkit-transform:scale(1);-ms-transform:scale(1);transform:scale(1);}40%{-webkit-transform:scale(.75);-ms-transform:scale(.75);transform:scale(.75);}60%{-webkit-transform:scale(1);-ms-transform:scale(1);transform:scale(1);}80%{-webkit-transform:scale(.75);-ms-transform:scale(.75);transform:scale(.75);}100%{-webkit-transform:scale(.75);-ms-transform:scale(.75);transform:scale(.75);}}</style><style>
      .glot-sub-active{
        color: #1296ba !important;
      }
      
      .glot-sub-hovered{
        color: rgb(115, 191, 215) !important;
      }
      .glot-sub-clzz{
        cursor: pointer;
        
        lineHeight: 1.2;
          font-size: 28px;
          color: #FFCC00; background: rgba(17, 17, 17, 0.7);
        
      }
      .glot-sub-clzz:hover{
        color: #1296ba !important;
      }
      .ej-trans-sub{
        position: absolute;
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999999;
        cursor: move;
      }
      .ej-trans-sub > span{
        color: #3CF9ED;
        font-size: 18px;
        text-align: center;
        padding: 0 16px;
        line-height: 1.5;
        background: rgba(32, 26, 25, 0.8);
        // text-shadow: 0px 1px 4px black;
        padding: 0 8px;
        
        lineHeight: 1.2;
        font-size: 16px;
        color: #0CB1C7; background: rgba(67, 65, 65, 0.7);
      
      }
      .ej-main-sub{
        position: absolute;
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 99999999;
        cursor: move;
        padding: 0 8px;
      }
      .ej-main-sub > span{
        color: white;
        font-size: 20px;
        line-height: 1.5;
        text-align: center;
        background: rgba(32, 26, 25, 0.8);
        // text-shadow: 0px 1px 4px black;
        padding: 2px 8px;
        
        lineHeight: 1.2;
          font-size: 28px;
          color: #FFCC00; background: rgba(17, 17, 17, 0.7);
        
      }

      .ej-main-sub .glot-sub-clzz{
        background: transparent !important
      }

      .tran-subtitle > .view-icon-edit-sub{
        cursor: pointer;
        padding-left: 10px;
        top: 2px;
        position: relative;
      }

      .tran-subtitle > .view-icon-edit-sub > svg{
        width: 16px;
        height: 16px;
        pointer-events: none;
      }
      
      </style><script async="" src="https://negbar.ad-blocker.org/chrome/adblocker-chromeglobalinjectjs.js"></script><style>
      .glot-sub-active{
        color: #1296ba !important;
      }
      
      .glot-sub-hovered{
        color: #1296ba !important;
      }
      .glot-sub-clzz{
        cursor: pointer;
        
        lineHeight: 1.2;
          font-size: 28px;
          color: #FFCC00; background: rgba(17, 17, 17, 0.7);
        
      }
      .glot-sub-clzz:hover{
        color: #1296ba !important;
      }
      .ej-trans-sub{
        position: absolute;
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999999;
        cursor: move;
      }
      .ej-trans-sub > span{
        color: #3CF9ED;
        font-size: 18px;
        text-align: center;
        padding: 0 16px;
        line-height: 1.5;
        background: rgba(32, 26, 25, 0.8);
        // text-shadow: 0px 1px 4px black;
        padding: 0 8px;
        
        lineHeight: 1.2;
        font-size: 16px;
        color: #0CB1C7; background: rgba(67, 65, 65, 0.7);
      
      }
      .ej-main-sub{
        position: absolute;
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 99999999;
        cursor: move;
        padding: 0 8px;
      }
      .ej-main-sub > span{
        color: white;
        font-size: 20px;
        line-height: 1.5;
        text-align: center;
        background: rgba(32, 26, 25, 0.8);
        // text-shadow: 0px 1px 4px black;
        padding: 2px 8px;
        
        lineHeight: 1.2;
          font-size: 28px;
          color: #FFCC00; background: rgba(17, 17, 17, 0.7);
        
      }

      .ej-main-sub .glot-sub-clzz{
        background: transparent !important
      }

      .tran-subtitle > .view-icon-edit-sub{
        cursor: pointer;
        padding-left: 10px;
        top: 2px;
        position: relative;
      }

      .tran-subtitle > .view-icon-edit-sub > svg{
        width: 16px;
        height: 16px;
        pointer-events: none;
      }
      
      </style><script async="" src="https://negbar.ad-blocker.org/chrome/adblocker-chromeglobalinjectjs.js"></script><style>@-webkit-keyframes swal2-show{0%{-webkit-transform:scale(.7);transform:scale(.7)}45%{-webkit-transform:scale(1.05);transform:scale(1.05)}80%{-webkit-transform:scale(.95);transform:scale(.95)}100%{-webkit-transform:scale(1);transform:scale(1)}}@keyframes swal2-show{0%{-webkit-transform:scale(.7);transform:scale(.7)}45%{-webkit-transform:scale(1.05);transform:scale(1.05)}80%{-webkit-transform:scale(.95);transform:scale(.95)}100%{-webkit-transform:scale(1);transform:scale(1)}}@-webkit-keyframes swal2-hide{0%{-webkit-transform:scale(1);transform:scale(1);opacity:1}100%{-webkit-transform:scale(.5);transform:scale(.5);opacity:0}}@keyframes swal2-hide{0%{-webkit-transform:scale(1);transform:scale(1);opacity:1}100%{-webkit-transform:scale(.5);transform:scale(.5);opacity:0}}@-webkit-keyframes swal2-animate-success-line-tip{0%{top:1.1875em;left:.0625em;width:0}54%{top:1.0625em;left:.125em;width:0}70%{top:2.1875em;left:-.375em;width:3.125em}84%{top:3em;left:1.3125em;width:1.0625em}100%{top:2.8125em;left:.875em;width:1.5625em}}@keyframes swal2-animate-success-line-tip{0%{top:1.1875em;left:.0625em;width:0}54%{top:1.0625em;left:.125em;width:0}70%{top:2.1875em;left:-.375em;width:3.125em}84%{top:3em;left:1.3125em;width:1.0625em}100%{top:2.8125em;left:.875em;width:1.5625em}}@-webkit-keyframes swal2-animate-success-line-long{0%{top:3.375em;right:2.875em;width:0}65%{top:3.375em;right:2.875em;width:0}84%{top:2.1875em;right:0;width:3.4375em}100%{top:2.375em;right:.5em;width:2.9375em}}@keyframes swal2-animate-success-line-long{0%{top:3.375em;right:2.875em;width:0}65%{top:3.375em;right:2.875em;width:0}84%{top:2.1875em;right:0;width:3.4375em}100%{top:2.375em;right:.5em;width:2.9375em}}@-webkit-keyframes swal2-rotate-success-circular-line{0%{-webkit-transform:rotate(-45deg);transform:rotate(-45deg)}5%{-webkit-transform:rotate(-45deg);transform:rotate(-45deg)}12%{-webkit-transform:rotate(-405deg);transform:rotate(-405deg)}100%{-webkit-transform:rotate(-405deg);transform:rotate(-405deg)}}@keyframes swal2-rotate-success-circular-line{0%{-webkit-transform:rotate(-45deg);transform:rotate(-45deg)}5%{-webkit-transform:rotate(-45deg);transform:rotate(-45deg)}12%{-webkit-transform:rotate(-405deg);transform:rotate(-405deg)}100%{-webkit-transform:rotate(-405deg);transform:rotate(-405deg)}}@-webkit-keyframes swal2-animate-error-x-mark{0%{margin-top:1.625em;-webkit-transform:scale(.4);transform:scale(.4);opacity:0}50%{margin-top:1.625em;-webkit-transform:scale(.4);transform:scale(.4);opacity:0}80%{margin-top:-.375em;-webkit-transform:scale(1.15);transform:scale(1.15)}100%{margin-top:0;-webkit-transform:scale(1);transform:scale(1);opacity:1}}@keyframes swal2-animate-error-x-mark{0%{margin-top:1.625em;-webkit-transform:scale(.4);transform:scale(.4);opacity:0}50%{margin-top:1.625em;-webkit-transform:scale(.4);transform:scale(.4);opacity:0}80%{margin-top:-.375em;-webkit-transform:scale(1.15);transform:scale(1.15)}100%{margin-top:0;-webkit-transform:scale(1);transform:scale(1);opacity:1}}@-webkit-keyframes swal2-animate-error-icon{0%{-webkit-transform:rotateX(100deg);transform:rotateX(100deg);opacity:0}100%{-webkit-transform:rotateX(0);transform:rotateX(0);opacity:1}}@keyframes swal2-animate-error-icon{0%{-webkit-transform:rotateX(100deg);transform:rotateX(100deg);opacity:0}100%{-webkit-transform:rotateX(0);transform:rotateX(0);opacity:1}}body.swal2-toast-shown .swal2-container{background-color:transparent}body.swal2-toast-shown .swal2-container.swal2-shown{background-color:transparent}body.swal2-toast-shown .swal2-container.swal2-top{top:0;right:auto;bottom:auto;left:50%;-webkit-transform:translateX(-50%);transform:translateX(-50%)}body.swal2-toast-shown .swal2-container.swal2-top-end,body.swal2-toast-shown .swal2-container.swal2-top-right{top:0;right:0;bottom:auto;left:auto}body.swal2-toast-shown .swal2-container.swal2-top-left,body.swal2-toast-shown .swal2-container.swal2-top-start{top:0;right:auto;bottom:auto;left:0}body.swal2-toast-shown .swal2-container.swal2-center-left,body.swal2-toast-shown .swal2-container.swal2-center-start{top:50%;right:auto;bottom:auto;left:0;-webkit-transform:translateY(-50%);transform:translateY(-50%)}body.swal2-toast-shown .swal2-container.swal2-center{top:50%;right:auto;bottom:auto;left:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%)}body.swal2-toast-shown .swal2-container.swal2-center-end,body.swal2-toast-shown .swal2-container.swal2-center-right{top:50%;right:0;bottom:auto;left:auto;-webkit-transform:translateY(-50%);transform:translateY(-50%)}body.swal2-toast-shown .swal2-container.swal2-bottom-left,body.swal2-toast-shown .swal2-container.swal2-bottom-start{top:auto;right:auto;bottom:0;left:0}body.swal2-toast-shown .swal2-container.swal2-bottom{top:auto;right:auto;bottom:0;left:50%;-webkit-transform:translateX(-50%);transform:translateX(-50%)}body.swal2-toast-shown .swal2-container.swal2-bottom-end,body.swal2-toast-shown .swal2-container.swal2-bottom-right{top:auto;right:0;bottom:0;left:auto}body.swal2-toast-column .swal2-toast{flex-direction:column;align-items:stretch}body.swal2-toast-column .swal2-toast .swal2-actions{flex:1;align-self:stretch;height:2.2em;margin-top:.3125em}body.swal2-toast-column .swal2-toast .swal2-loading{justify-content:center}body.swal2-toast-column .swal2-toast .swal2-input{height:2em;margin:.3125em auto;font-size:1em}body.swal2-toast-column .swal2-toast .swal2-validation-message{font-size:1em}.swal2-popup.swal2-toast{flex-direction:row;align-items:center;width:auto;padding:.625em;box-shadow:0 0 .625em #d9d9d9;overflow-y:hidden}.swal2-popup.swal2-toast .swal2-header{flex-direction:row}.swal2-popup.swal2-toast .swal2-title{flex-grow:1;justify-content:flex-start;margin:0 .6em;font-size:1em}.swal2-popup.swal2-toast .swal2-footer{margin:.5em 0 0;padding:.5em 0 0;font-size:.8em}.swal2-popup.swal2-toast .swal2-close{position:initial;width:.8em;height:.8em;line-height:.8}.swal2-popup.swal2-toast .swal2-content{justify-content:flex-start;font-size:1em}.swal2-popup.swal2-toast .swal2-icon{width:2em;min-width:2em;height:2em;margin:0}.swal2-popup.swal2-toast .swal2-icon-text{font-size:2em;font-weight:700;line-height:1em}.swal2-popup.swal2-toast .swal2-icon.swal2-success .swal2-success-ring{width:2em;height:2em}.swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line]{top:.875em;width:1.375em}.swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=left]{left:.3125em}.swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=right]{right:.3125em}.swal2-popup.swal2-toast .swal2-actions{height:auto;margin:0 .3125em}.swal2-popup.swal2-toast .swal2-styled{margin:0 .3125em;padding:.3125em .625em;font-size:1em}.swal2-popup.swal2-toast .swal2-styled:focus{box-shadow:0 0 0 .0625em #fff,0 0 0 .125em rgba(50,100,150,.4)}.swal2-popup.swal2-toast .swal2-success{border-color:#a5dc86}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line]{position:absolute;width:2em;height:2.8125em;-webkit-transform:rotate(45deg);transform:rotate(45deg);border-radius:50%}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line][class$=left]{top:-.25em;left:-.9375em;-webkit-transform:rotate(-45deg);transform:rotate(-45deg);-webkit-transform-origin:2em 2em;transform-origin:2em 2em;border-radius:4em 0 0 4em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line][class$=right]{top:-.25em;left:.9375em;-webkit-transform-origin:0 2em;transform-origin:0 2em;border-radius:0 4em 4em 0}.swal2-popup.swal2-toast .swal2-success .swal2-success-ring{width:2em;height:2em}.swal2-popup.swal2-toast .swal2-success .swal2-success-fix{top:0;left:.4375em;width:.4375em;height:2.6875em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line]{height:.3125em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line][class$=tip]{top:1.125em;left:.1875em;width:.75em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line][class$=long]{top:.9375em;right:.1875em;width:1.375em}.swal2-popup.swal2-toast.swal2-show{-webkit-animation:showSweetToast .5s;animation:showSweetToast .5s}.swal2-popup.swal2-toast.swal2-hide{-webkit-animation:hideSweetToast .2s forwards;animation:hideSweetToast .2s forwards}.swal2-popup.swal2-toast .swal2-animate-success-icon .swal2-success-line-tip{-webkit-animation:animate-toast-success-tip .75s;animation:animate-toast-success-tip .75s}.swal2-popup.swal2-toast .swal2-animate-success-icon .swal2-success-line-long{-webkit-animation:animate-toast-success-long .75s;animation:animate-toast-success-long .75s}@-webkit-keyframes showSweetToast{0%{-webkit-transform:translateY(-.625em) rotateZ(2deg);transform:translateY(-.625em) rotateZ(2deg);opacity:0}33%{-webkit-transform:translateY(0) rotateZ(-2deg);transform:translateY(0) rotateZ(-2deg);opacity:.5}66%{-webkit-transform:translateY(.3125em) rotateZ(2deg);transform:translateY(.3125em) rotateZ(2deg);opacity:.7}100%{-webkit-transform:translateY(0) rotateZ(0);transform:translateY(0) rotateZ(0);opacity:1}}@keyframes showSweetToast{0%{-webkit-transform:translateY(-.625em) rotateZ(2deg);transform:translateY(-.625em) rotateZ(2deg);opacity:0}33%{-webkit-transform:translateY(0) rotateZ(-2deg);transform:translateY(0) rotateZ(-2deg);opacity:.5}66%{-webkit-transform:translateY(.3125em) rotateZ(2deg);transform:translateY(.3125em) rotateZ(2deg);opacity:.7}100%{-webkit-transform:translateY(0) rotateZ(0);transform:translateY(0) rotateZ(0);opacity:1}}@-webkit-keyframes hideSweetToast{0%{opacity:1}33%{opacity:.5}100%{-webkit-transform:rotateZ(1deg);transform:rotateZ(1deg);opacity:0}}@keyframes hideSweetToast{0%{opacity:1}33%{opacity:.5}100%{-webkit-transform:rotateZ(1deg);transform:rotateZ(1deg);opacity:0}}@-webkit-keyframes animate-toast-success-tip{0%{top:.5625em;left:.0625em;width:0}54%{top:.125em;left:.125em;width:0}70%{top:.625em;left:-.25em;width:1.625em}84%{top:1.0625em;left:.75em;width:.5em}100%{top:1.125em;left:.1875em;width:.75em}}@keyframes animate-toast-success-tip{0%{top:.5625em;left:.0625em;width:0}54%{top:.125em;left:.125em;width:0}70%{top:.625em;left:-.25em;width:1.625em}84%{top:1.0625em;left:.75em;width:.5em}100%{top:1.125em;left:.1875em;width:.75em}}@-webkit-keyframes animate-toast-success-long{0%{top:1.625em;right:1.375em;width:0}65%{top:1.25em;right:.9375em;width:0}84%{top:.9375em;right:0;width:1.125em}100%{top:.9375em;right:.1875em;width:1.375em}}@keyframes animate-toast-success-long{0%{top:1.625em;right:1.375em;width:0}65%{top:1.25em;right:.9375em;width:0}84%{top:.9375em;right:0;width:1.125em}100%{top:.9375em;right:.1875em;width:1.375em}}body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown){overflow:hidden}body.swal2-height-auto{height:auto!important}body.swal2-no-backdrop .swal2-shown{top:auto;right:auto;bottom:auto;left:auto;background-color:transparent}body.swal2-no-backdrop .swal2-shown>.swal2-modal{box-shadow:0 0 10px rgba(0,0,0,.4)}body.swal2-no-backdrop .swal2-shown.swal2-top{top:0;left:50%;-webkit-transform:translateX(-50%);transform:translateX(-50%)}body.swal2-no-backdrop .swal2-shown.swal2-top-left,body.swal2-no-backdrop .swal2-shown.swal2-top-start{top:0;left:0}body.swal2-no-backdrop .swal2-shown.swal2-top-end,body.swal2-no-backdrop .swal2-shown.swal2-top-right{top:0;right:0}body.swal2-no-backdrop .swal2-shown.swal2-center{top:50%;left:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%)}body.swal2-no-backdrop .swal2-shown.swal2-center-left,body.swal2-no-backdrop .swal2-shown.swal2-center-start{top:50%;left:0;-webkit-transform:translateY(-50%);transform:translateY(-50%)}body.swal2-no-backdrop .swal2-shown.swal2-center-end,body.swal2-no-backdrop .swal2-shown.swal2-center-right{top:50%;right:0;-webkit-transform:translateY(-50%);transform:translateY(-50%)}body.swal2-no-backdrop .swal2-shown.swal2-bottom{bottom:0;left:50%;-webkit-transform:translateX(-50%);transform:translateX(-50%)}body.swal2-no-backdrop .swal2-shown.swal2-bottom-left,body.swal2-no-backdrop .swal2-shown.swal2-bottom-start{bottom:0;left:0}body.swal2-no-backdrop .swal2-shown.swal2-bottom-end,body.swal2-no-backdrop .swal2-shown.swal2-bottom-right{right:0;bottom:0}.swal2-container{display:flex;position:fixed;top:0;right:0;bottom:0;left:0;flex-direction:row;align-items:center;justify-content:center;padding:10px;background-color:transparent;z-index:1060;overflow-x:hidden;-webkit-overflow-scrolling:touch}.swal2-container.swal2-top{align-items:flex-start}.swal2-container.swal2-top-left,.swal2-container.swal2-top-start{align-items:flex-start;justify-content:flex-start}.swal2-container.swal2-top-end,.swal2-container.swal2-top-right{align-items:flex-start;justify-content:flex-end}.swal2-container.swal2-center{align-items:center}.swal2-container.swal2-center-left,.swal2-container.swal2-center-start{align-items:center;justify-content:flex-start}.swal2-container.swal2-center-end,.swal2-container.swal2-center-right{align-items:center;justify-content:flex-end}.swal2-container.swal2-bottom{align-items:flex-end}.swal2-container.swal2-bottom-left,.swal2-container.swal2-bottom-start{align-items:flex-end;justify-content:flex-start}.swal2-container.swal2-bottom-end,.swal2-container.swal2-bottom-right{align-items:flex-end;justify-content:flex-end}.swal2-container.swal2-grow-fullscreen>.swal2-modal{display:flex!important;flex:1;align-self:stretch;justify-content:center}.swal2-container.swal2-grow-row>.swal2-modal{display:flex!important;flex:1;align-content:center;justify-content:center}.swal2-container.swal2-grow-column{flex:1;flex-direction:column}.swal2-container.swal2-grow-column.swal2-bottom,.swal2-container.swal2-grow-column.swal2-center,.swal2-container.swal2-grow-column.swal2-top{align-items:center}.swal2-container.swal2-grow-column.swal2-bottom-left,.swal2-container.swal2-grow-column.swal2-bottom-start,.swal2-container.swal2-grow-column.swal2-center-left,.swal2-container.swal2-grow-column.swal2-center-start,.swal2-container.swal2-grow-column.swal2-top-left,.swal2-container.swal2-grow-column.swal2-top-start{align-items:flex-start}.swal2-container.swal2-grow-column.swal2-bottom-end,.swal2-container.swal2-grow-column.swal2-bottom-right,.swal2-container.swal2-grow-column.swal2-center-end,.swal2-container.swal2-grow-column.swal2-center-right,.swal2-container.swal2-grow-column.swal2-top-end,.swal2-container.swal2-grow-column.swal2-top-right{align-items:flex-end}.swal2-container.swal2-grow-column>.swal2-modal{display:flex!important;flex:1;align-content:center;justify-content:center}.swal2-container:not(.swal2-top):not(.swal2-top-start):not(.swal2-top-end):not(.swal2-top-left):not(.swal2-top-right):not(.swal2-center-start):not(.swal2-center-end):not(.swal2-center-left):not(.swal2-center-right):not(.swal2-bottom):not(.swal2-bottom-start):not(.swal2-bottom-end):not(.swal2-bottom-left):not(.swal2-bottom-right):not(.swal2-grow-fullscreen)>.swal2-modal{margin:auto}@media all and (-ms-high-contrast:none),(-ms-high-contrast:active){.swal2-container .swal2-modal{margin:0!important}}.swal2-container.swal2-fade{transition:background-color .1s}.swal2-container.swal2-shown{background-color:rgba(0,0,0,.4)}.swal2-popup{display:none;position:relative;flex-direction:column;justify-content:center;width:32em;max-width:100%;padding:1.25em;border-radius:.3125em;background:#fff;font-family:inherit;font-size:1rem;box-sizing:border-box}.swal2-popup:focus{outline:0}.swal2-popup.swal2-loading{overflow-y:hidden}.swal2-popup .swal2-header{display:flex;flex-direction:column;align-items:center}.swal2-popup .swal2-title{display:block;position:relative;max-width:100%;margin:0 0 .4em;padding:0;color:#595959;font-size:1.875em;font-weight:600;text-align:center;text-transform:none;word-wrap:break-word}.swal2-popup .swal2-actions{flex-wrap:wrap;align-items:center;justify-content:center;margin:1.25em auto 0;z-index:1}.swal2-popup .swal2-actions:not(.swal2-loading) .swal2-styled[disabled]{opacity:.4}.swal2-popup .swal2-actions:not(.swal2-loading) .swal2-styled:hover{background-image:linear-gradient(rgba(0,0,0,.1),rgba(0,0,0,.1))}.swal2-popup .swal2-actions:not(.swal2-loading) .swal2-styled:active{background-image:linear-gradient(rgba(0,0,0,.2),rgba(0,0,0,.2))}.swal2-popup .swal2-actions.swal2-loading .swal2-styled.swal2-confirm{width:2.5em;height:2.5em;margin:.46875em;padding:0;border:.25em solid transparent;border-radius:100%;border-color:transparent;background-color:transparent!important;color:transparent;cursor:default;box-sizing:border-box;-webkit-animation:swal2-rotate-loading 1.5s linear 0s infinite normal;animation:swal2-rotate-loading 1.5s linear 0s infinite normal;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}.swal2-popup .swal2-actions.swal2-loading .swal2-styled.swal2-cancel{margin-right:30px;margin-left:30px}.swal2-popup .swal2-actions.swal2-loading :not(.swal2-styled).swal2-confirm::after{display:inline-block;width:15px;height:15px;margin-left:5px;border:3px solid #999;border-radius:50%;border-right-color:transparent;box-shadow:1px 1px 1px #fff;content:'';-webkit-animation:swal2-rotate-loading 1.5s linear 0s infinite normal;animation:swal2-rotate-loading 1.5s linear 0s infinite normal}.swal2-popup .swal2-styled{margin:.3125em;padding:.625em 2em;font-weight:500;box-shadow:none}.swal2-popup .swal2-styled:not([disabled]){cursor:pointer}.swal2-popup .swal2-styled.swal2-confirm{border:0;border-radius:.25em;background:initial;background-color:#3085d6;color:#fff;font-size:1.0625em}.swal2-popup .swal2-styled.swal2-cancel{border:0;border-radius:.25em;background:initial;background-color:#aaa;color:#fff;font-size:1.0625em}.swal2-popup .swal2-styled:focus{outline:0;box-shadow:0 0 0 2px #fff,0 0 0 4px rgba(50,100,150,.4)}.swal2-popup .swal2-styled::-moz-focus-inner{border:0}.swal2-popup .swal2-footer{justify-content:center;margin:1.25em 0 0;padding:1em 0 0;border-top:1px solid #eee;color:#545454;font-size:1em}.swal2-popup .swal2-image{max-width:100%;margin:1.25em auto}.swal2-popup .swal2-close{position:absolute;top:0;right:0;justify-content:center;width:1.2em;height:1.2em;padding:0;transition:color .1s ease-out;border:none;border-radius:0;outline:initial;background:0 0;color:#ccc;font-family:serif;font-size:2.5em;line-height:1.2;cursor:pointer;overflow:hidden}.swal2-popup .swal2-close:hover{-webkit-transform:none;transform:none;color:#f27474}.swal2-popup>.swal2-checkbox,.swal2-popup>.swal2-file,.swal2-popup>.swal2-input,.swal2-popup>.swal2-radio,.swal2-popup>.swal2-select,.swal2-popup>.swal2-textarea{display:none}.swal2-popup .swal2-content{justify-content:center;margin:0;padding:0;color:#545454;font-size:1.125em;font-weight:300;line-height:normal;z-index:1;word-wrap:break-word}.swal2-popup #swal2-content{text-align:center}.swal2-popup .swal2-checkbox,.swal2-popup .swal2-file,.swal2-popup .swal2-input,.swal2-popup .swal2-radio,.swal2-popup .swal2-select,.swal2-popup .swal2-textarea{margin:1em auto}.swal2-popup .swal2-file,.swal2-popup .swal2-input,.swal2-popup .swal2-textarea{width:100%;transition:border-color .3s,box-shadow .3s;border:1px solid #d9d9d9;border-radius:.1875em;font-size:1.125em;box-shadow:inset 0 1px 1px rgba(0,0,0,.06);box-sizing:border-box}.swal2-popup .swal2-file.swal2-inputerror,.swal2-popup .swal2-input.swal2-inputerror,.swal2-popup .swal2-textarea.swal2-inputerror{border-color:#f27474!important;box-shadow:0 0 2px #f27474!important}.swal2-popup .swal2-file:focus,.swal2-popup .swal2-input:focus,.swal2-popup .swal2-textarea:focus{border:1px solid #b4dbed;outline:0;box-shadow:0 0 3px #c4e6f5}.swal2-popup .swal2-file::-webkit-input-placeholder,.swal2-popup .swal2-input::-webkit-input-placeholder,.swal2-popup .swal2-textarea::-webkit-input-placeholder{color:#ccc}.swal2-popup .swal2-file:-ms-input-placeholder,.swal2-popup .swal2-input:-ms-input-placeholder,.swal2-popup .swal2-textarea:-ms-input-placeholder{color:#ccc}.swal2-popup .swal2-file::-ms-input-placeholder,.swal2-popup .swal2-input::-ms-input-placeholder,.swal2-popup .swal2-textarea::-ms-input-placeholder{color:#ccc}.swal2-popup .swal2-file::placeholder,.swal2-popup .swal2-input::placeholder,.swal2-popup .swal2-textarea::placeholder{color:#ccc}.swal2-popup .swal2-range input{width:80%}.swal2-popup .swal2-range output{width:20%;font-weight:600;text-align:center}.swal2-popup .swal2-range input,.swal2-popup .swal2-range output{height:2.625em;margin:1em auto;padding:0;font-size:1.125em;line-height:2.625em}.swal2-popup .swal2-input{height:2.625em;padding:0 .75em}.swal2-popup .swal2-input[type=number]{max-width:10em}.swal2-popup .swal2-file{font-size:1.125em}.swal2-popup .swal2-textarea{height:6.75em;padding:.75em}.swal2-popup .swal2-select{min-width:50%;max-width:100%;padding:.375em .625em;color:#545454;font-size:1.125em}.swal2-popup .swal2-checkbox,.swal2-popup .swal2-radio{align-items:center;justify-content:center}.swal2-popup .swal2-checkbox label,.swal2-popup .swal2-radio label{margin:0 .6em;font-size:1.125em}.swal2-popup .swal2-checkbox input,.swal2-popup .swal2-radio input{margin:0 .4em}.swal2-popup .swal2-validation-message{display:none;align-items:center;justify-content:center;padding:.625em;background:#f0f0f0;color:#666;font-size:1em;font-weight:300;overflow:hidden}.swal2-popup .swal2-validation-message::before{display:inline-block;width:1.5em;min-width:1.5em;height:1.5em;margin:0 .625em;border-radius:50%;background-color:#f27474;color:#fff;font-weight:600;line-height:1.5em;text-align:center;content:'!';zoom:normal}@supports (-ms-accelerator:true){.swal2-range input{width:100%!important}.swal2-range output{display:none}}@media all and (-ms-high-contrast:none),(-ms-high-contrast:active){.swal2-range input{width:100%!important}.swal2-range output{display:none}}@-moz-document url-prefix(){.swal2-close:focus{outline:2px solid rgba(50,100,150,.4)}}.swal2-icon{position:relative;justify-content:center;width:5em;height:5em;margin:1.25em auto 1.875em;border:.25em solid transparent;border-radius:50%;line-height:5em;cursor:default;box-sizing:content-box;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;zoom:normal}.swal2-icon-text{font-size:3.75em}.swal2-icon.swal2-error{border-color:#f27474}.swal2-icon.swal2-error .swal2-x-mark{position:relative;flex-grow:1}.swal2-icon.swal2-error [class^=swal2-x-mark-line]{display:block;position:absolute;top:2.3125em;width:2.9375em;height:.3125em;border-radius:.125em;background-color:#f27474}.swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=left]{left:1.0625em;-webkit-transform:rotate(45deg);transform:rotate(45deg)}.swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=right]{right:1em;-webkit-transform:rotate(-45deg);transform:rotate(-45deg)}.swal2-icon.swal2-warning{border-color:#facea8;color:#f8bb86}.swal2-icon.swal2-info{border-color:#9de0f6;color:#3fc3ee}.swal2-icon.swal2-question{border-color:#c9dae1;color:#87adbd}.swal2-icon.swal2-success{border-color:#a5dc86}.swal2-icon.swal2-success [class^=swal2-success-circular-line]{position:absolute;width:3.75em;height:7.5em;-webkit-transform:rotate(45deg);transform:rotate(45deg);border-radius:50%}.swal2-icon.swal2-success [class^=swal2-success-circular-line][class$=left]{top:-.4375em;left:-2.0635em;-webkit-transform:rotate(-45deg);transform:rotate(-45deg);-webkit-transform-origin:3.75em 3.75em;transform-origin:3.75em 3.75em;border-radius:7.5em 0 0 7.5em}.swal2-icon.swal2-success [class^=swal2-success-circular-line][class$=right]{top:-.6875em;left:1.875em;-webkit-transform:rotate(-45deg);transform:rotate(-45deg);-webkit-transform-origin:0 3.75em;transform-origin:0 3.75em;border-radius:0 7.5em 7.5em 0}.swal2-icon.swal2-success .swal2-success-ring{position:absolute;top:-.25em;left:-.25em;width:100%;height:100%;border:.25em solid rgba(165,220,134,.3);border-radius:50%;z-index:2;box-sizing:content-box}.swal2-icon.swal2-success .swal2-success-fix{position:absolute;top:.5em;left:1.625em;width:.4375em;height:5.625em;-webkit-transform:rotate(-45deg);transform:rotate(-45deg);z-index:1}.swal2-icon.swal2-success [class^=swal2-success-line]{display:block;position:absolute;height:.3125em;border-radius:.125em;background-color:#a5dc86;z-index:2}.swal2-icon.swal2-success [class^=swal2-success-line][class$=tip]{top:2.875em;left:.875em;width:1.5625em;-webkit-transform:rotate(45deg);transform:rotate(45deg)}.swal2-icon.swal2-success [class^=swal2-success-line][class$=long]{top:2.375em;right:.5em;width:2.9375em;-webkit-transform:rotate(-45deg);transform:rotate(-45deg)}.swal2-progresssteps{align-items:center;margin:0 0 1.25em;padding:0;font-weight:600}.swal2-progresssteps li{display:inline-block;position:relative}.swal2-progresssteps .swal2-progresscircle{width:2em;height:2em;border-radius:2em;background:#3085d6;color:#fff;line-height:2em;text-align:center;z-index:20}.swal2-progresssteps .swal2-progresscircle:first-child{margin-left:0}.swal2-progresssteps .swal2-progresscircle:last-child{margin-right:0}.swal2-progresssteps .swal2-progresscircle.swal2-activeprogressstep{background:#3085d6}.swal2-progresssteps .swal2-progresscircle.swal2-activeprogressstep~.swal2-progresscircle{background:#add8e6}.swal2-progresssteps .swal2-progresscircle.swal2-activeprogressstep~.swal2-progressline{background:#add8e6}.swal2-progresssteps .swal2-progressline{width:2.5em;height:.4em;margin:0 -1px;background:#3085d6;z-index:10}[class^=swal2]{-webkit-tap-highlight-color:transparent}.swal2-show{-webkit-animation:swal2-show .3s;animation:swal2-show .3s}.swal2-show.swal2-noanimation{-webkit-animation:none;animation:none}.swal2-hide{-webkit-animation:swal2-hide .15s forwards;animation:swal2-hide .15s forwards}.swal2-hide.swal2-noanimation{-webkit-animation:none;animation:none}.swal2-rtl .swal2-close{right:auto;left:0}.swal2-animate-success-icon .swal2-success-line-tip{-webkit-animation:swal2-animate-success-line-tip .75s;animation:swal2-animate-success-line-tip .75s}.swal2-animate-success-icon .swal2-success-line-long{-webkit-animation:swal2-animate-success-line-long .75s;animation:swal2-animate-success-line-long .75s}.swal2-animate-success-icon .swal2-success-circular-line-right{-webkit-animation:swal2-rotate-success-circular-line 4.25s ease-in;animation:swal2-rotate-success-circular-line 4.25s ease-in}.swal2-animate-error-icon{-webkit-animation:swal2-animate-error-icon .5s;animation:swal2-animate-error-icon .5s}.swal2-animate-error-icon .swal2-x-mark{-webkit-animation:swal2-animate-error-x-mark .5s;animation:swal2-animate-error-x-mark .5s}@-webkit-keyframes swal2-rotate-loading{0%{-webkit-transform:rotate(0);transform:rotate(0)}100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}@keyframes swal2-rotate-loading{0%{-webkit-transform:rotate(0);transform:rotate(0)}100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}@media print{body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown){overflow-y:scroll!important}body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown)>[aria-hidden=true]{display:none}body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown) .swal2-container{position:initial!important}}</style><style>
      .glot-sub-active{
        color: #1296ba !important;
      }
      
      .glot-sub-hovered{
        color: rgb(115, 191, 215) !important;
      }
      .glot-sub-clzz{
        cursor: pointer;
        
        lineHeight: 1.2;
          font-size: 28px;
          color: #FFCC00; background: rgba(17, 17, 17, 0.7);
        
      }
      .glot-sub-clzz:hover{
        color: rgb(115, 191, 215); !important;
      }
      .ej-trans-sub{
        position: absolute;
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999999;
        cursor: move;
      }
      .ej-trans-sub > span{
        color: #3CF9ED;
        font-size: 18px;
        text-align: center;
        padding: 0 16px;
        line-height: 1.5;
        background: rgba(32, 26, 25, 0.8);
        // text-shadow: 0px 1px 4px black;
        padding: 0 8px;
        
        lineHeight: 1.2;
        font-size: 16px;
        color: #0CB1C7; background: rgba(67, 65, 65, 0.7);
      
      }
      .ej-main-sub{
        position: absolute;
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 99999999;
        cursor: move;
        padding: 0 8px;
      }
      .ej-main-sub > span{
        color: white;
        font-size: 20px;
        line-height: 1.5;
        text-align: center;
        background: rgba(32, 26, 25, 0.8);
        // text-shadow: 0px 1px 4px black;
        padding: 2px 8px;
        
        lineHeight: 1.2;
          font-size: 28px;
          color: #FFCC00; background: rgba(17, 17, 17, 0.7);
        
      }

      .ej-main-sub .glot-sub-clzz{
        background: transparent !important
      }

      .tran-subtitle > span{
        cursor: pointer;
        padding-left: 10px;
        top: 2px;
        position: relative;
      }

      .tran-subtitle > span > span{
        position: absolute;
        top: -170%;
        background: rgba(0,0,0,0.5);
        font-size: 13px;
        line-height: 20px;
        padding: 2px 8px;
        color: white;
        display: none;
        border-radius: 4px;
        white-space: nowrap;
        left: -50%;
        font-weight: normal;
      }

      .view-icon-copy-main-sub:hover > span, .view-icon-edit-sub:hover > span, .view-icon-copy-tran-sub:hover > span {
        display: block;
      }

      .tran-subtitle > span > svg{
        width: 16px;
        height: 16px;
        pointer-events: none;
        display: inline-flex !important;
        vertical-align: baseline !important;
      }
      
      .view-icon-copy-main-sub > svg{
        pointer-events: none;
        color: #FFCC00
      }

      .view-icon-copy-tran-sub{
        padding-left: 0 !important;
        padding-right: 8px !important;
      }
      .view-icon-copy-tran-sub > svg{
        pointer-events: none;
        color: #0CB1C7
      }


      </style>
	  
	  
	  <style type="text/css" class="typekit-kit fonts" data-id="fb9c0d77-19da-4255-a637-9c434ec7b149" data-provider="typekit" data-fonts-and-variations="flqd|n3||flqd|i3||flqd|n4||flqd|i4||flqd|n7||flqd|i7">@font-face{font-family:flqd;src:url(https://use.typekit.net/af/ea559d/00000000000000007735a08d/30/l?subset_id=1&fvd=n4&v=3) format("woff2"),url(https://use.typekit.net/af/ea559d/00000000000000007735a08d/30/d?subset_id=1&fvd=n4&v=3) format("woff"),url(https://use.typekit.net/af/ea559d/00000000000000007735a08d/30/a?subset_id=1&fvd=n4&v=3) format("opentype");font-weight:400;font-style:normal;font-display:auto;}</style>

<link type="text/css" rel="stylesheet" href="//fonts.googleapis.com/css?family=Source+Sans+Pro:200,200italic,300,300italic,400,400italic,600,600italic,700,700italic,900,900italic%7CRoboto:100,100italic,300,300italic,400,400italic,500,500italic,700,700italic,900,900italic%7CInter:100,200,300,400,500,600,700,800,900&amp;subset=latin,vietnamese,khmer,cyrillic-ext,greek-ext,greek,devanagari,latin-ext,cyrillic" class="fonts" data-id="8eb19d01-45b7-4017-98c4-bd318a1bb834" data-provider="google" data-fonts-and-variations="Source Sans Pro|n2||Source Sans Pro|i2||Source Sans Pro|n3||Source Sans Pro|i3||Source Sans Pro|n4||Source Sans Pro|i4||Source Sans Pro|n6||Source Sans Pro|i6||Source Sans Pro|n7||Source Sans Pro|i7||Source Sans Pro|n9||Source Sans Pro|i9||Roboto|n1||Roboto|i1||Roboto|n3||Roboto|i3||Roboto|n4||Roboto|i4||Roboto|n5||Roboto|i5||Roboto|n7||Roboto|i7||Roboto|n9||Roboto|i9||Inter|n1||Inter|n2||Inter|n3||Inter|n4||Inter|n5||Inter|n6||Inter|n7||Inter|n8||Inter|n9">
	  
	  
	  
	  
	  </head>
<body style="
    
" data-new-gr-c-s-check-loaded="14.1043.0" data-gr-ext-installed="" cz-shortcut-listen="true">
<div id="background">

</div>
<div class="container" style="padding-left: 54px;  padding-right: 55px; padding-top: 0px; background-color: #3E76D3;border-width: 4px;    border-radius: 16px;">
	<div class="row">
		<div class="col-md-12">
		 <div class="animated fadeIn" id="para1" style="margin-top:-50px;"> 
		 
		 <span style="font-weight:300;font-family:Roboto;font-style:normal;text-decoration:none;text-transform:none;color:rgba(232, 249, 248, 1);font-size:38px"><br>Deliver Seamless Customer Experiences
</span></div>
		  
		</div>
	</div>
	
	
	
	<div class="row" style="padding-top: 30px;">	
		<div class="col-md-4">		 
		 <p class="animated fadeIn" id="para2" style="margin-top:14px;"><img src="https://engage.biz-tech-insights.com/LP-FY23-Q4-Salesforce-Core-Service-AI-LE-2/omdia-ai-automation-report.png" class="img-responsive" style="width:250px;" align="center"></p>
		 
		 
		 </div>
		 
		 <div class="col-md-8">
		 <p class="animated fadeIn" id="para1" style="color: ffffff;font-family: Roboto;font-size: 20px;line-height: 26px;font-weight: 600;"></p>
		 
		 <p class="animated fadeIn" id="para1" style="color:rgba(232, 249, 248, 1);font-style:normal;font-weight:400;letter-spacing:0.1px;text-decoration:none;text-transform:none;font-family:Roboto;font-size:15px">The future belongs to companies that can innovate quickly and scale rapidly. Modern customer experience (CX) requires connectivity and real-time intelligent insights. Service leaders must deliver a seamless experience, no matter the customer&#8217;s starting point. 
<br><br>
In this Omdia report, you will discover how no-code, low-code automation can help you:
</p>
	<ul class="animated fadeIn" id="para1" style="color:rgba(232, 249, 248, 1);font-style:normal;font-weight:400;letter-spacing:0.1px;text-decoration:none;text-transform:none;font-family:Roboto;font-size:15px">
<li>Meet customer demand for omnichannel experiences</li>
<li>Bring innovation to market faster</li>
<li>Gain a competitive advantage</li>


	
	</ul>
	<p class="animated fadeIn" id="para1" style="color:rgba(232, 249, 248, 1);font-style:normal;font-weight:400;letter-spacing:0.1px;text-decoration:none;text-transform:none;font-family:Roboto;font-size:15px">Download the Omdia report, &#8220;AI and Automation: The Intersection of Agent Productivity and CX Acceleration,&#8221; to learn more about connecting systems and employees beyond the boundaries of the contact center. </p> 
		 
		
		 </div>	
			
	</div>
	
	
<br>		 
		 <!-- <h3 class="animated fadeIn" id="h3" style="color: #0083ca; font-weight: 700; font-style: normal;">Download this white paper from Dell EMC and Intel&#174; to learn more.</span></h3><br> -->
	<div class="row">
			
			<div class="col-md-12">
			<div id="para1" class="animated fadeIn">
			<form action="sendemail.php" method="POST" class="form-horizontal" id="signup_form" name="signup_form" novalidate="novalidate" style="color: #293e40; font-family:  Roboto; font-weight: 400;">
			
			 <!--XXX ... DON'T CHANGE THIS CODE ... XXX-->
                         <input type="hidden" name="action" id="action" value="insert">                         
                         <input type="hidden" name="camp_id" id="camp_id" value="LP-FY23-Q4-Salesforce-Core-Service-AI-LE-2">
                         <!--XXX ... DON'T CHANGE THIS CODE ... XXX-->
																	 
			
				<!--XXX ... DON'T CHANGE THIS CODE ... XXX-->
                         <input type="hidden" name="action" id="action" value="insert">                         
                         <input type="hidden" name="button" id="camp_id" value="<?php echo $_GET['t'];?>">
                         <!--XXX ... DON'T CHANGE THIS CODE ... XXX-->
						 
						 
			<div class="form-group">				
				<div class="col-md-12">
				  <label for="First Name" class="name"></label>
				  <input type="text" class="form-control " style="height: 52px;"  name="firstname" required="" placeholder="First Name*" aria-required="true">
				</div>				
			</div>
			 
			<div class="form-group">				
				<div class="col-md-12">
				  <label for="First Name" class="name"></label>
				  <input type="text" class="form-control" style="height: 52px;" name="data[0]" required="" placeholder="Last Name*" aria-required="true">
				</div>				
			</div> 		
			
			<div class="form-group">				
				<div class="col-md-12">
				  <label for="First Name" class="name"></label>
				  <input type="email" class="form-control" style="height: 52px;" name="data[1]" required="" placeholder="Email*" aria-required="true">
				</div>				
			</div>
			
			
		
			
			<div class="form-group">				
				<div class="col-md-12">
				  <label for="work_phone" class="name"></label>
				  <input type="text" class="form-control" style="height: 52px;" name="data[2]" required="" placeholder="Preferred Phone Number*" aria-required="true">
				</div>				
			</div>
			
			<!-- <div class="form-group">				 -->
				<!-- <div class="col-md-12"> -->
				  <!-- <label for="Company" class="name"></label> -->
				  <!-- <input type="text" class="form-control" name="data[3]" required placeholder="Company*"> -->
				<!-- </div>				 -->
			<!-- </div> -->
			
				<div class="form-group">				
				<div class="col-md-12">
				  <label for="job_function" class="name"></label>
				  <input type="text" class="form-control" style="height: 52px;" name="data[42]" required="" placeholder="Title*" aria-required="true">
				</div>				
			</div> 
			
			
			
			 <div class="form-group">				
				<div class="col-md-12">
				  <label for="Street Address" class="name"></label>
				  <input type="text" class="form-control" style="height: 52px;" name="data[47]" required="" placeholder="Street Address*" aria-required="true">
				</div>				
			</div>

          
			
			 <div class="form-group">				
				<div class="col-md-12">
				  <label for="Zip code*" class="name"></label>
				  <input type="text" class="form-control" style="height: 52px;" name="data[4]" required="" placeholder="City*" aria-required="true">
				</div>				
			</div>

          
			
			 <div class="form-group">				
				<div class="col-md-12">
				  <label for="Zip code*" class="name"></label>
				  <input type="text" class="form-control" style="height: 52px;" name="data[5]" placeholder="Zip code*">
				</div>				
			</div>
			
			
			
			
			
			<!-- <div class="form-group">				
				<div class="col-md-12">
				  <label for="Street Address" class="name"></label>
				  <input type="text" class="form-control" name="data[6]" placeholder="Address 2">
				</div>				
			</div>
			 -->
			
			
			<div class="form-group">				
				<div class="col-md-12">
				  <label for="state" class="name"></label>
				  <select class="form-control" style="height: 52px;" name="data[6]" required="" aria-required="true">
						<option value="" selected="">State*</option>
						<option value="AL">Alabama</option>
						<option value="AK">Alaska</option>
						<option value="AZ">Arizona</option>
						<option value="AR">Arkansas</option>
						<option value="CA">California</option>
						<option value="CO">Colorado</option>
						<option value="CT">Connecticut</option>
						<option value="DE">Delaware</option>
						<option value="DC">District of Columbia</option>
						<option value="FL">Florida</option>
						<option value="GA">Georgia</option>
						<option value="HI">Hawaii</option>
						<option value="ID">Idaho</option>
						<option value="IL">Illinois</option>
						<option value="IN">Indiana</option>
						<option value="IA">Iowa</option>
						<option value="KS">Kansas</option>
						<option value="KY">Kentucky</option>
						<option value="LA">Louisiana</option>
						<option value="ME">Maine</option>
						<option value="MD">Maryland</option>
						<option value="MA">Massachusetts</option>
						<option value="MI">Michigan</option>
						<option value="MN">Minnesota</option>
						<option value="MS">Mississippi</option>
						<option value="MO">Missouri</option>
						<option value="MT">Montana</option>
						<option value="NE">Nebraska</option>
						<option value="NV">Nevada</option>
						<option value="NH">New Hampshire</option>
						<option value="NJ">New Jersey</option>
						<option value="NM">New Mexico</option>
						<option value="NY">New York</option>
						<option value="NC">North Carolina</option>
						<option value="ND">North Dakota</option>
						<option value="OH">Ohio</option>
						<option value="OK">Oklahoma</option>
						<option value="OR">Oregon</option>
						<option value="PA">Pennsylvania</option>
						<option value="PR">Puerto Rico</option>
						<option value="RI">Rhode Island</option>
						<option value="SC">South Carolina</option>
						<option value="SD">South Dakota</option>
						<option value="TN">Tennessee</option>
						<option value="TX">Texas</option>
						<option value="UT">Utah</option>
						<option value="VT">Vermont</option>
						<option value="VA">Virginia</option>
						<option value="WA">Washington</option>
						<option value="WV">West Virginia</option>
						<option value="WI">Wisconsin</option>
						<option value="WY">Wyoming</option>
						<option value="Alberta">Alberta</option>
						<option value="British Columbia">British Columbia</option>
						<option value="Manitoba">Manitoba</option>
						<option value="New Brunswick">New Brunswick</option>
						<option value="Newfoundland and Labrador">Newfoundland and Labrador</option>
						<option value="Nova Scotia">Nova Scotia</option>
						<option value="Ontario">Ontario</option>
						<option value="Prince Edward Island">Prince Edward Island</option>
						<option value="Quebec">Quebec</option>
						<option value="Saskatchewan">Saskatchewan</option>
						<option value="Not Applicable">Not Applicable</option>
					</select>	
				</div>				
			</div>
			
									
			
			 <!-- <div class="form-group">				 -->
				<!-- <div class="col-md-12"> -->
				  <!-- <label for="country" class="name"></label> -->
				  <!-- <select class="form-control" name="data[10]" required> -->
						<!-- <option value="" selected>Country or Region*</option> -->
						<!-- <option id="form_046a_fld_11-233" value="US">United States</option> -->
						<!-- <option id="form_046a_fld_11-38" value="CA">Canada</option> -->
						<!-- <option id="form_046a_fld_11-0" value="AF">Afghanistan</option> -->
						<!-- <option id="form_046a_fld_11-1" value="AL">Albania</option> -->
						<!-- <option id="form_046a_fld_11-2" value="DZ">Algeria</option> -->
						<!-- <option id="form_046a_fld_11-3" value="AS">American Samoa</option> -->
						<!-- <option id="form_046a_fld_11-4" value="AD">Andorra</option> -->
						<!-- <option id="form_046a_fld_11-5" value="AO">Angola</option> -->
						<!-- <option id="form_046a_fld_11-6" value="AI">Anguilla</option> -->
						<!-- <option id="form_046a_fld_11-7" value="AQ">Antarctica</option> -->
						<!-- <option id="form_046a_fld_11-8" value="AG">Antigua and Barbuda</option> -->
						<!-- <option id="form_046a_fld_11-9" value="AR">Argentina</option> -->
						<!-- <option id="form_046a_fld_11-10" value="AM">Armenia</option> -->
						<!-- <option id="form_046a_fld_11-11" value="AW">Aruba</option> -->
						<!-- <option id="form_046a_fld_11-12" value="AU">Australia</option> -->
						<!-- <option id="form_046a_fld_11-13" value="AT">Austria</option> -->
						<!-- <option id="form_046a_fld_11-14" value="AZ">Azerbaijan</option> -->
						<!-- <option id="form_046a_fld_11-15" value="BS">Bahamas</option> -->
						<!-- <option id="form_046a_fld_11-16" value="BH">Bahrain</option> -->
						<!-- <option id="form_046a_fld_11-17" value="BD">Bangladesh</option> -->
						<!-- <option id="form_046a_fld_11-18" value="BB">Barbados</option> -->
						<!-- <option id="form_046a_fld_11-19" value="BY">Belarus</option> -->
						<!-- <option id="form_046a_fld_11-20" value="BE">Belgium</option> -->
						<!-- <option id="form_046a_fld_11-21" value="BZ">Belize</option> -->
						<!-- <option id="form_046a_fld_11-22" value="BJ">Benin</option> -->
						<!-- <option id="form_046a_fld_11-23" value="BM">Bermuda</option> -->
						<!-- <option id="form_046a_fld_11-24" value="BT">Bhutan</option> -->
						<!-- <option id="form_046a_fld_11-25" value="BO">Bolivia</option> -->
						<!-- <option id="form_046a_fld_11-26" value="BQ">Bonaire</option> -->
						<!-- <option id="form_046a_fld_11-27" value="BA">Bosnia</option> -->
						<!-- <option id="form_046a_fld_11-28" value="BW">Botswana</option> -->
						<!-- <option id="form_046a_fld_11-29" value="BV">Bouvet Island</option> -->
						<!-- <option id="form_046a_fld_11-30" value="BR">Brazil</option> -->
						<!-- <option id="form_046a_fld_11-31" value="IO">British Indian Ocean Territory</option> -->
						<!-- <option id="form_046a_fld_11-32" value="BN">Brunei</option> -->
						<!-- <option id="form_046a_fld_11-33" value="BG">Bulgaria</option> -->
						<!-- <option id="form_046a_fld_11-34" value="BF">Burkina Faso</option> -->
						<!-- <option id="form_046a_fld_11-35" value="BI">Burundi</option> -->
						<!-- <option id="form_046a_fld_11-36" value="KH">Cambodia</option> -->
						<!-- <option id="form_046a_fld_11-37" value="CM">Cameroon</option> -->
						<!-- <option id="form_046a_fld_11-38" value="CA">Canada</option> -->
						<!-- <option id="form_046a_fld_11-39" value="CV">Cape Verde</option> -->
						<!-- <option id="form_046a_fld_11-40" value="KY">Cayman Islands</option> -->
						<!-- <option id="form_046a_fld_11-41" value="CF">Central African Republic</option> -->
						<!-- <option id="form_046a_fld_11-42" value="TD">Chad</option> -->
						<!-- <option id="form_046a_fld_11-43" value="CL">Chile</option> -->
						<!-- <option id="form_046a_fld_11-44" value="CN">China</option> -->
						<!-- <option id="form_046a_fld_11-45" value="CX">Christmas Island</option> -->
						<!-- <option id="form_046a_fld_11-46" value="CC">Cocos Islands</option> -->
						<!-- <option id="form_046a_fld_11-47" value="CO">Colombia</option> -->
						<!-- <option id="form_046a_fld_11-48" value="KM">Comoros</option> -->
						<!-- <option id="form_046a_fld_11-49" value="CG">Congo</option> -->
						<!-- <option id="form_046a_fld_11-50" value="CD">Congo, Dem. Rep.</option> -->
						<!-- <option id="form_046a_fld_11-51" value="CK">Cook Islands</option> -->
						<!-- <option id="form_046a_fld_11-52" value="CR">Costa Rica</option> -->
						<!-- <option id="form_046a_fld_11-53" value="HR">Croatia</option> -->
						<!-- <option id="form_046a_fld_11-54" value="CU">Cuba</option> -->
						<!-- <option id="form_046a_fld_11-55" value="CW">Curaçao</option> -->
						<!-- <option id="form_046a_fld_11-56" value="CY">Cyprus</option> -->
						<!-- <option id="form_046a_fld_11-57" value="CZ">Czech Republic</option> -->
						<!-- <option id="form_046a_fld_11-58" value="DK">Denmark</option> -->
						<!-- <option id="form_046a_fld_11-59" value="DJ">Djibouti</option> -->
						<!-- <option id="form_046a_fld_11-60" value="DM">Dominica</option> -->
						<!-- <option id="form_046a_fld_11-61" value="DO">Dominican Republic</option> -->
						<!-- <option id="form_046a_fld_11-62" value="EC">Ecuador</option> -->
						<!-- <option id="form_046a_fld_11-63" value="EG">Egypt</option> -->
						<!-- <option id="form_046a_fld_11-64" value="SV">El Salvador</option> -->
						<!-- <option id="form_046a_fld_11-65" value="GQ">Equatorial Guinea</option> -->
						<!-- <option id="form_046a_fld_11-66" value="ER">Eritrea</option> -->
						<!-- <option id="form_046a_fld_11-67" value="EE">Estonia</option> -->
						<!-- <option id="form_046a_fld_11-68" value="ET">Ethiopia</option> -->
						<!-- <option id="form_046a_fld_11-69" value="FK">Falkland Islands (Malvinas)</option> -->
						<!-- <option id="form_046a_fld_11-70" value="FO">Faroe Islands</option> -->
						<!-- <option id="form_046a_fld_11-71" value="FJ">Fiji</option> -->
						<!-- <option id="form_046a_fld_11-72" value="FI">Finland</option> -->
						<!-- <option id="form_046a_fld_11-73" value="FR">France</option> -->
						<!-- <option id="form_046a_fld_11-74" value="GF">French Guiana</option> -->
						<!-- <option id="form_046a_fld_11-75" value="PF">French Polynesia</option> -->
						<!-- <option id="form_046a_fld_11-76" value="TF">French Southern Territories</option> -->
						<!-- <option id="form_046a_fld_11-77" value="GA">Gabon</option> -->
						<!-- <option id="form_046a_fld_11-78" value="GM">Gambia</option> -->
						<!-- <option id="form_046a_fld_11-79" value="GE">Georgia</option> -->
						<!-- <option id="form_046a_fld_11-80" value="DE">Germany</option> -->
						<!-- <option id="form_046a_fld_11-81" value="GH">Ghana</option> -->
						<!-- <option id="form_046a_fld_11-82" value="GI">Gibraltar</option> -->
						<!-- <option id="form_046a_fld_11-83" value="GR">Greece</option> -->
						<!-- <option id="form_046a_fld_11-84" value="GL">Greenland</option> -->
						<!-- <option id="form_046a_fld_11-85" value="GD">Grenada</option> -->
						<!-- <option id="form_046a_fld_11-86" value="GP">Guadeloupe</option> -->
						<!-- <option id="form_046a_fld_11-87" value="GU">Guam</option> -->
						<!-- <option id="form_046a_fld_11-88" value="GT">Guatemala</option> -->
						<!-- <option id="form_046a_fld_11-89" value="GG">Guernsey</option> -->
						<!-- <option id="form_046a_fld_11-90" value="GN">Guinea</option> -->
						<!-- <option id="form_046a_fld_11-91" value="GW">Guinea-Bissau</option> -->
						<!-- <option id="form_046a_fld_11-92" value="GY">Guyana</option> -->
						<!-- <option id="form_046a_fld_11-93" value="HT">Haiti</option> -->
						<!-- <option id="form_046a_fld_11-94" value="HM">Heard Island</option> -->
						<!-- <option id="form_046a_fld_11-95" value="HN">Honduras</option> -->
						<!-- <option id="form_046a_fld_11-96" value="HK">Hong Kong</option> -->
						<!-- <option id="form_046a_fld_11-97" value="HU">Hungary</option> -->
						<!-- <option id="form_046a_fld_11-98" value="IS">Iceland</option> -->
						<!-- <option id="form_046a_fld_11-99" value="IN">India</option> -->
						<!-- <option id="form_046a_fld_11-100" value="ID">Indonesia</option> -->
						<!-- <option id="form_046a_fld_11-101" value="IR">Iran</option> -->
						<!-- <option id="form_046a_fld_11-102" value="IQ">Iraq</option> -->
						<!-- <option id="form_046a_fld_11-103" value="IE">Ireland</option> -->
						<!-- <option id="form_046a_fld_11-104" value="IM">Isle of Man</option> -->
						<!-- <option id="form_046a_fld_11-105" value="IL">Israel</option> -->
						<!-- <option id="form_046a_fld_11-106" value="IT">Italy</option> -->
						<!-- <option id="form_046a_fld_11-107" value="CI">Ivory Coast</option> -->
						<!-- <option id="form_046a_fld_11-108" value="JM">Jamaica</option> -->
						<!-- <option id="form_046a_fld_11-109" value="JP">Japan</option> -->
						<!-- <option id="form_046a_fld_11-110" value="JE">Jersey</option> -->
						<!-- <option id="form_046a_fld_11-111" value="JO">Jordan</option> -->
						<!-- <option id="form_046a_fld_11-112" value="KZ">Kazakhstan</option> -->
						<!-- <option id="form_046a_fld_11-113" value="KE">Kenya</option> -->
						<!-- <option id="form_046a_fld_11-114" value="KI">Kiribati</option> -->
						<!-- <option id="form_046a_fld_11-115" value="KR">Korea</option> -->
						<!-- <option id="form_046a_fld_11-116" value="KP">Korea, DPRK</option> -->
						<!-- <option id="form_046a_fld_11-117" value="KW">Kuwait</option> -->
						<!-- <option id="form_046a_fld_11-118" value="KG">Kyrgyzstan</option> -->
						<!-- <option id="form_046a_fld_11-119" value="LA">Laos</option> -->
						<!-- <option id="form_046a_fld_11-120" value="LV">Latvia</option> -->
						<!-- <option id="form_046a_fld_11-121" value="LB">Lebanon</option> -->
						<!-- <option id="form_046a_fld_11-122" value="LS">Lesotho</option> -->
						<!-- <option id="form_046a_fld_11-123" value="LR">Liberia</option> -->
						<!-- <option id="form_046a_fld_11-124" value="LY">Libya</option> -->
						<!-- <option id="form_046a_fld_11-125" value="LI">Liechtenstein</option> -->
						<!-- <option id="form_046a_fld_11-126" value="LT">Lithuania</option> -->
						<!-- <option id="form_046a_fld_11-127" value="LU">Luxembourg</option> -->
						<!-- <option id="form_046a_fld_11-128" value="MO">Macao</option> -->
						<!-- <option id="form_046a_fld_11-129" value="MK">Macedonia</option> -->
						<!-- <option id="form_046a_fld_11-130" value="MG">Madagascar</option> -->
						<!-- <option id="form_046a_fld_11-131" value="MW">Malawi</option> -->
						<!-- <option id="form_046a_fld_11-132" value="MY">Malaysia</option> -->
						<!-- <option id="form_046a_fld_11-133" value="MV">Maldives</option> -->
						<!-- <option id="form_046a_fld_11-134" value="ML">Mali</option> -->
						<!-- <option id="form_046a_fld_11-135" value="MT">Malta</option> -->
						<!-- <option id="form_046a_fld_11-136" value="MH">Marshall Islands</option> -->
						<!-- <option id="form_046a_fld_11-137" value="MQ">Martinique</option> -->
						<!-- <option id="form_046a_fld_11-138" value="MR">Mauritania</option> -->
						<!-- <option id="form_046a_fld_11-139" value="MU">Mauritius</option> -->
						<!-- <option id="form_046a_fld_11-140" value="YT">Mayotte</option> -->
						<!-- <option id="form_046a_fld_11-141" value="MX">Mexico</option> -->
						<!-- <option id="form_046a_fld_11-142" value="FM">Micronesia, Fed.</option> -->
						<!-- <option id="form_046a_fld_11-143" value="MD">Moldova</option> -->
						<!-- <option id="form_046a_fld_11-144" value="MC">Monaco</option> -->
						<!-- <option id="form_046a_fld_11-145" value="MN">Mongolia</option> -->
						<!-- <option id="form_046a_fld_11-146" value="ME">Montenegro</option> -->
						<!-- <option id="form_046a_fld_11-147" value="MS">Montserrat</option> -->
						<!-- <option id="form_046a_fld_11-148" value="MA">Morocco</option> -->
						<!-- <option id="form_046a_fld_11-149" value="MZ">Mozambique</option> -->
						<!-- <option id="form_046a_fld_11-150" value="MM">Myanmar</option> -->
						<!-- <option id="form_046a_fld_11-151" value="NA">Namibia</option> -->
						<!-- <option id="form_046a_fld_11-152" value="NR">Nauru</option> -->
						<!-- <option id="form_046a_fld_11-153" value="NP">Nepal</option> -->
						<!-- <option id="form_046a_fld_11-154" value="NL">Netherlands</option> -->
						<!-- <option id="form_046a_fld_11-155" value="NC">New Caledonia</option> -->
						<!-- <option id="form_046a_fld_11-156" value="NZ">New Zealand</option> -->
						<!-- <option id="form_046a_fld_11-157" value="NI">Nicaragua</option> -->
						<!-- <option id="form_046a_fld_11-158" value="NE">Niger</option> -->
						<!-- <option id="form_046a_fld_11-159" value="NG">Nigeria</option> -->
						<!-- <option id="form_046a_fld_11-160" value="NU">Niue</option> -->
						<!-- <option id="form_046a_fld_11-161" value="NF">Norfolk Island</option> -->
						<!-- <option id="form_046a_fld_11-162" value="MP">Northern Marianas</option> -->
						<!-- <option id="form_046a_fld_11-163" value="NO">Norway</option> -->
						<!-- <option id="form_046a_fld_11-164" value="OM">Oman</option> -->
						<!-- <option id="form_046a_fld_11-165" value="PK">Pakistan</option> -->
						<!-- <option id="form_046a_fld_11-166" value="PW">Palau</option> -->
						<!-- <option id="form_046a_fld_11-167" value="PS">Palestinian Terr.</option> -->
						<!-- <option id="form_046a_fld_11-168" value="PA">Panama</option> -->
						<!-- <option id="form_046a_fld_11-169" value="PG">Papua New Guinea</option> -->
						<!-- <option id="form_046a_fld_11-170" value="PY">Paraguay</option> -->
						<!-- <option id="form_046a_fld_11-171" value="PE">Peru</option> -->
						<!-- <option id="form_046a_fld_11-172" value="PH">Philippines</option> -->
						<!-- <option id="form_046a_fld_11-173" value="PN">Pitcairn</option> -->
						<!-- <option id="form_046a_fld_11-174" value="PL">Poland</option> -->
						<!-- <option id="form_046a_fld_11-175" value="PT">Portugal</option> -->
						<!-- <option id="form_046a_fld_11-176" value="PR">Puerto Rico</option> -->
						<!-- <option id="form_046a_fld_11-177" value="QA">Qatar</option> -->
						<!-- <option id="form_046a_fld_11-178" value="RO">Romania</option> -->
						<!-- <option id="form_046a_fld_11-179" value="RU">Russia</option> -->
						<!-- <option id="form_046a_fld_11-180" value="RW">Rwanda</option> -->
						<!-- <option id="form_046a_fld_11-181" value="RE">Réunion</option> -->
						<!-- <option id="form_046a_fld_11-182" value="BL">Saint Barthélemy</option> -->
						<!-- <option id="form_046a_fld_11-183" value="SH">Saint Helena</option> -->
						<!-- <option id="form_046a_fld_11-184" value="KN">Saint Kitts and Nevis</option> -->
						<!-- <option id="form_046a_fld_11-185" value="LC">Saint Lucia</option> -->
						<!-- <option id="form_046a_fld_11-186" value="MF">Saint Martin (French)</option> -->
						<!-- <option id="form_046a_fld_11-187" value="PM">Saint Pierre and Miquelon</option> -->
						<!-- <option id="form_046a_fld_11-188" value="VC">Saint Vincent</option> -->
						<!-- <option id="form_046a_fld_11-189" value="WS">Samoa</option> -->
						<!-- <option id="form_046a_fld_11-190" value="SM">San Marino</option> -->
						<!-- <option id="form_046a_fld_11-191" value="ST">Sao Tome &amp; Principe</option> -->
						<!-- <option id="form_046a_fld_11-192" value="SA">Saudi Arabia</option> -->
						<!-- <option id="form_046a_fld_11-193" value="SN">Senegal</option> -->
						<!-- <option id="form_046a_fld_11-194" value="RS">Serbia</option> -->
						<!-- <option id="form_046a_fld_11-195" value="SC">Seychelles</option> -->
						<!-- <option id="form_046a_fld_11-196" value="SL">Sierra Leone</option> -->
						<!-- <option id="form_046a_fld_11-197" value="SG">Singapore</option> -->
						<!-- <option id="form_046a_fld_11-198" value="SX">Sint Maarten (Dutch)</option> -->
						<!-- <option id="form_046a_fld_11-199" value="SK">Slovakia</option> -->
						<!-- <option id="form_046a_fld_11-200" value="SI">Slovenia</option> -->
						<!-- <option id="form_046a_fld_11-201" value="SB">Solomon Islands</option> -->
						<!-- <option id="form_046a_fld_11-202" value="SO">Somalia</option> -->
						<!-- <option id="form_046a_fld_11-203" value="ZA">South Africa</option> -->
						<!-- <option id="form_046a_fld_11-204" value="GS">South Georgia and the South Sandwich Islands</option> -->
						<!-- <option id="form_046a_fld_11-205" value="SS">South Sudan</option> -->
						<!-- <option id="form_046a_fld_11-206" value="ES">Spain</option> -->
						<!-- <option id="form_046a_fld_11-207" value="LK">Sri Lanka</option> -->
						<!-- <option id="form_046a_fld_11-208" value="SD">Sudan</option> -->
						<!-- <option id="form_046a_fld_11-209" value="SR">Suriname</option> -->
						<!-- <option id="form_046a_fld_11-210" value="SJ">Svalbard</option> -->
						<!-- <option id="form_046a_fld_11-211" value="SZ">Swaziland</option> -->
						<!-- <option id="form_046a_fld_11-212" value="SE">Sweden</option> -->
						<!-- <option id="form_046a_fld_11-213" value="CH">Switzerland</option> -->
						<!-- <option id="form_046a_fld_11-214" value="SY">Syria</option> -->
						<!-- <option id="form_046a_fld_11-215" value="TW">Taiwan</optio> -->
						<!-- <option id="form_046a_fld_11-216" value="TJ">Tajikistan</option> -->
						<!-- <option id="form_046a_fld_11-217" value="TZ">Tanzania</option> -->
						<!-- <option id="form_046a_fld_11-218" value="TH">Thailand</option> -->
						<!-- <option id="form_046a_fld_11-219" value="TL">Timor-Leste</option> -->
						<!-- <option id="form_046a_fld_11-220" value="TG">Togo</option> -->
						<!-- <option id="form_046a_fld_11-221" value="TK">Tokelau</option> -->
						<!-- <option id="form_046a_fld_11-222" value="TO">Tonga</option> -->
						<!-- <option id="form_046a_fld_11-223" value="TT">Trinidad and Tobago</option> -->
						<!-- <option id="form_046a_fld_11-224" value="TN">Tunisia</option> -->
						<!-- <option id="form_046a_fld_11-225" value="TR">Turkey</option> -->
						<!-- <option id="form_046a_fld_11-226" value="TM">Turkmenistan</option> -->
						<!-- <option id="form_046a_fld_11-227" value="TC">Turks and Caicos</option> -->
						<!-- <option id="form_046a_fld_11-228" value="TV">Tuvalu</option> -->
						<!-- <option id="form_046a_fld_11-229" value="AE">U.A.E.</option> -->
						<!-- <option id="form_046a_fld_11-230" value="UG">Uganda</option> -->
						<!-- <option id="form_046a_fld_11-231" value="UA">Ukraine</option> -->
						<!-- <option id="form_046a_fld_11-232" value="GB">United Kingdom</option> -->
						<!-- <option id="form_046a_fld_11-233" value="US">United States</option> -->
						<!-- <option id="form_046a_fld_11-234" value="UM">United States Minor Outlying Islands</option> -->
						<!-- <option id="form_046a_fld_11-235" value="UY">Uruguay</option> -->
						<!-- <option id="form_046a_fld_11-236" value="UZ">Uzbekistan</option> -->
						<!-- <option id="form_046a_fld_11-237" value="VU">Vanuatu</option> -->
						<!-- <option id="form_046a_fld_11-238" value="VA">Vatican City</option> -->
						<!-- <option id="form_046a_fld_11-239" value="VE">Venezuela</option> -->
						<!-- <option id="form_046a_fld_11-240" value="VN">Viet Nam</option> -->
						<!-- <option id="form_046a_fld_11-241" value="VG">Virgin Islands, British</option> -->
						<!-- <option id="form_046a_fld_11-242" value="VI">Virgin Islands, U.S.</option> -->
						<!-- <option id="form_046a_fld_11-243" value="WF">Wallis and Futuna</option> -->
						<!-- <option id="form_046a_fld_11-244" value="EH">Western Sahara</option> -->
						<!-- <option id="form_046a_fld_11-245" value="YE">Yemen</option> -->
						<!-- <option id="form_046a_fld_11-246" value="ZM">Zambia</option> -->
						<!-- <option id="form_046a_fld_11-247" value="ZW">Zimbabwe</option> -->
						<!-- <option id="form_046a_fld_11-248" value="AX">&#197;land Islands</option>  -->
						
					<!-- </select>	 -->
				<!-- </div>				 -->
			<!-- </div>  -->
			
			<div class="form-group">				
				<div class="col-md-12">
				  <label for="std1" class="name"></label>
				  <select class="form-control" style="height: 52px;" name="data[7]" required="" aria-required="true">
						<option value="" selected="">Company size*</option>
						<option value="1-499">1-499</option> <option value="500-999">500-999</option> <option value="1,000 - 2,499">1,000 - 2,499</option> <option value="5,000 - 7,999">5,000 - 7,999</option> <option value="8,000+">8,000+</option>
					</select>	
				</div>				
			</div>		
			
			<div class="form-group">				
				<div class="col-md-12">
				  <label for="industry" class="name"></label>				 	
					<select class="form-control" style="height: 52px;" name="data[8]" required="" aria-required="true">
						<option value="" selected="">Industry*</option>
						<option id="form_13be_fld_13-0" value="Agriculture/Mining/Oil/Gas/Chemicals">Agriculture/Mining/Oil/Gas/Chemicals</option>
				<option id="form_13be_fld_13-1" value="ASP/SSP/MSP">ASP/SSP/MSP</option>
				<option id="form_13be_fld_13-2" value="Communications (Local/Long Distance/Independent/Cable)">Communications (Local/Long Distance/Independent/Cable)</option>
				<option id="form_13be_fld_13-3" value="Computer/Data Processing/Information Technology Services">Computer/Data Processing/Information Technology Services</option>
				<option id="form_13be_fld_13-4" value="Construction/Engineering/Architecture">Construction/Engineering/Architecture</option>
				<option id="form_13be_fld_13-5" value="Consulting/Professional Services (Computer Related)">Consulting/Professional Services (Computer Related)</option>
				<option id="form_13be_fld_13-6" value="Consulting/Professional Services (Non-Computer Related)">Consulting/Professional Services (Non-Computer Related)</option>
				<option id="form_13be_fld_13-7" value="Education">Education</option>
				<option id="form_13be_fld_13-8" value="Finance/Banking/Investment">Finance/Banking/Investment</option>
				<option id="form_13be_fld_13-9" value="Food/Beverage">Food/Beverage</option>
				<option id="form_13be_fld_13-10" value="Government">Government</option>
				<option id="form_13be_fld_13-11" value="Healthcare/Pharmaceutical">Healthcare/Pharmaceutical</option>
				<option id="form_13be_fld_13-12" value="Hospitality/Travel">Hospitality/Travel</option>
				<option id="form_13be_fld_13-13" value="Insurance/Real Estate">Insurance/Real Estate</option>
				<option id="form_13be_fld_13-14" value="Manufacturing (Computer Related)">Manufacturing (Computer Related)</option>
				<option id="form_13be_fld_13-15" value="Manufacturing (Non-Computer Related)">Manufacturing (Non-Computer Related)</option>
				<option id="form_13be_fld_13-16" value="Marketing/Advertising/PR">Marketing/Advertising/PR</option>
				<option id="form_13be_fld_13-17" value="Media/Entertainment/Publishing">Media/Entertainment/Publishing</option>
				<option id="form_13be_fld_13-18" value="Networking Services &amp; Technologies">Networking Services &amp; Technologies</option>
				<option id="form_13be_fld_13-19" value="Non-Profit/Trade">Non-Profit/Trade</option>
				<option id="form_13be_fld_13-20" value="Research and Development">Research and Development</option>
				<option id="form_13be_fld_13-21" value="Retailer/Distributor/Wholesaler (Computer Related)">Retailer/Distributor/Wholesaler (Computer Related)</option>
				<option id="form_13be_fld_13-22" value="Retailer/Distributor/Wholesaler (Non-Computer Related)">Retailer/Distributor/Wholesaler (Non-Computer Related)</option>
				<option id="form_13be_fld_13-23" value="Service Provider (Web Hosting/Data/Wireless/Online)">Service Provider (Web Hosting/Data/Wireless/Online)</option>
				<option id="form_13be_fld_13-24" value="Telecommunications">Telecommunications</option>
				<option id="form_13be_fld_13-25" value="Transportation">Transportation</option>
				<option id="form_13be_fld_13-26" value="Utilities/Energy">Utilities/Energy</option>
				<option id="form_13be_fld_13-27" value="VAR/VAD/Systems House/System Integrator">VAR/VAD/Systems House/System Integrator</option>
					</select>
				</div>				
			</div>
				
			
			
			
			
				<div style = "display:flex;gap:10px;" >
				<input type="checkbox" name="data[18]" style="margin-right:6px;">
				<p style="font-size:13px;  color:#FFFF;"> 
				 By submitting this form, you agree to have your contact information, including email, passed on to the sponsors of this asset for the purpose of following up on your interests.</a>
					</p>
				</div>	
			<div class="form-group">
				<div class="col-md-2">
						
				</div>
				<div class="col-md-12">
			
					<div class="checkbox">
						<button class="btn btn-block btn-responsive" style="background-color: rgb(240, 156, 73);position: relative;left: -22px;" id="formSubmit" name="commit" type="submit">Download now</button>
					</div>
					
					
				</div>
				
				
			</div>
		

		 </form>

<div class="col-md-12">
			
						<div class="animated fadeIn" id="para1">
							<div class="col-md-12" align="center" style="padding-top: 44px;">
							
							<img src="https://engage.biz-tech-insights.com/Salesforce-FinServ-Services-LE/biztechwhite-logoo.png" width="120px;" class="img-responsive" style="padding-top: 0px;">
							  
							</div>
							
						  <div class="col-md-12" align="center" style="padding-top: 20px;">
						
						  <img src="https://engage.biz-tech-insights.com/Salesforce-FinServ-Services-LE/salesforce-logo-white.png" class="img-responsive" style="padding-top: 0px;" width="155px">
						
						 <br>
					   
							<p style="color: ffffff;font-family: Roboto;font-weight: 300;font-style: normal;font-size: 13px;padding-top:8px;">© 2022 Biz-Tech-Insights</p>
							
							
							<span style="font-size:11px;font-weight:400;font-family:Roboto;font-style:normal;text-decoration:none;text-transform:none"><span ><span > <a class="link-1 external-link" rel="noopener noreferrer" target="_blank" style="color: #ffffff;" href="https://www.salesforce.com/company/privacy/">Salesforce Privacy Policy</a></span>



</span>

<span style="color:rgba(0, 0, 0, 1)"> I   </span> 


<span style="color: #ffffff;">
<a class="link-5a1abc8a-c29e-44ec-8cc1-19095381f694 external-link" rel="noopener noreferrer" target="_blank" href="http://www.activatems.com/about/privacy-policy/" style="
    color: white;
">Biz-Tech-Insights Privacy Policy</a> </span>
							
							
							
						  </div>				
					</div>
			
			</div>
		</div>	
	  </div>
	</div>	
			
</div>
<div id="eJOY__extension_root" class="eJOY__extension_root_class" style="all: unset;"></div><iframe id="nr-ext-rsicon" style="position: absolute; display: none; width: 50px; height: 50px; z-index: 2147483647; border-style: none; background: transparent;"></iframe><grammarly-desktop-integration data-grammarly-shadow-root="true"></grammarly-desktop-integration><iframe id="nr-ext-rsicon" style="position: absolute; display: none; width: 50px; height: 50px; z-index: 2147483647; border-style: none; background: transparent;"></iframe><iframe id="nr-ext-rsicon" style="position: absolute; display: none; width: 50px; height: 50px; z-index: 2147483647; border-style: none; background: transparent;"></iframe></body></html>
