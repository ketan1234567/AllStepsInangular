<?php
include('../mailer_config/mailerConfig.php');   

if (!empty($_SERVER['HTTP_CLIENT_IP']))   
  {$ip_address = $_SERVER['HTTP_CLIENT_IP'];}
//whether ip is from proxy
elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))  
  {$ip_address = $_SERVER['HTTP_X_FORWARDED_FOR'];}
//whether ip is from remote address
else
  {$ip_address = $_SERVER['REMOTE_ADDR'];}
// echo $ip_address;
//IP ADDRESS END

//DON'T CHANGE THIS CODE (Data Get From LP)
$URL = urlencode($_SERVER['HTTP_REFERER']);

$camp_id ="LP-FY23-Q4-Salesforce-Core-Service-AI-LE-2";
//$camp_id = $_POST["camp_id"];
$firstform = "";
//$firstform = $_POST["firstform"];
$firstname = $_POST["firstname"];
$button = $_POST["button"];
$temp = implode(",", $_POST["data"]);
$temp = $firstname.','.$temp.','.$button;
$pattern = '/[a-z0-9_\-\+\.]+@[a-z0-9\-]+\.([a-z]{2,4})(?:\.[a-z]{2})?/i';
preg_match_all($pattern, $temp, $matches);
$email = array_shift($matches[0]);
//DON'T CHANGE THIS CODE END

$ENDURL = "https://engage.biz-tech-insights.com/LP-FY23-Q4-Salesforce-Core-Service-AI-LE-2/omdia-ai-automation-report.pdf";
//Change last folder name as given below as per the requirement of camp
//ace, bl, comndb, magento, tata, tgif
file_get_contents("http://engage.biz-tech-insights.com/api-final/api/public/index.php/api/insert/user/w8/".base64_encode($ENDURL).",".base64_encode($URL)."/".base64_encode($temp)."/".$camp_id."/".$ip_address);

                     
$mail->From = "campaign@engage.biz-tech-insights.com";
$mail->FromName = "Biz-Tech-Insights";
$mail->addAddress($email, $firstname);

$mail->isHTML(true);

$mail->Subject = 'Thank you for requesting "AI and Automation: The Intersection of Agent Productivity and CX Acceleration"';
$mail->Body = "<p style='text-align: justify; font-size: 14px;'>Dear <b>$firstname</b>,</p>

<p style='text-align: justify; font-size: 14px;'>
Thank you for your recent interest in Biz Tech Insights content on behalf of <b>Salesforce</b>. We hope you found the information valuable.
<br><br>
Please find a copy of your asset '<b>AI and Automation: The Intersection of Agent Productivity and CX Acceleration</b>' to download <a href='https://engage.biz-tech-insights.com/LP-FY23-Q4-Salesforce-Core-Service-AI-LE-2/omdia-ai-automation-report.pdf'>here</a>.
<br><br>
Thank you again for your interest,

</p>
<p style='text-align: justify; font-size: 14px;'>Nina Ridgeway<br><span style='color:black;'>Biz Tech Insights</span>
</p>

<center><p style='text-align: center; font-size: 14px;'>Biz Tech Insights, 100 Montgomery St, Suite 1650, San Francisco, CA 94104<br>You received this email because you signed up to receive content from Biz Tech Insights.<br>You can access our Privacy Policy <a href='https://www.activatems.com/privacy-policy/'>here</a>, or click <a href='https://engage.biz-tech-insights.com/unsubscribed.html'>here</a> to unsubscribe.<br><a href='https://www.salesforce.com/company/privacy/'>Salesforce Privacy Policy</a></p></center>

";
$mail->AltBody = "";

try {
    $mail->send();
	// exit();
    // echo "Message has been sent successfully";
	// header('Location: https://www.google.com/');
	echo "<script>
	window.location.href = 'https://engage.biz-tech-insights.com/LP-FY23-Q4-Salesforce-Core-Service-AI-LE-2/omdia-ai-automation-report.pdf';
	</script>";
} catch (Exception $e) {
    // echo "Mailer Error: " . $mail->ErrorInfo;
}

?>
