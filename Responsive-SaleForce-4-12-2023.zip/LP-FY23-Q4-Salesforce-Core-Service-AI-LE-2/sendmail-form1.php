<?php

//XXX ... DON'T CHANGE THIS CODE ... XXX

$action = $_POST["action"];

$camp_id = $_POST["camp_id"];

$URL = $_SERVER['HTTP_REFERER'];

$firstname = $_POST["firstname"];



$temp = implode(" / ", $_POST["data"]);

$temp = $firstname.' / '.$temp;

$pattern = '/[a-z0-9_\-\+\.]+@[a-z0-9\-]+\.([a-z]{2,4})(?:\.[a-z]{2})?/i';

preg_match_all($pattern, $temp, $matches);

$email = array_shift($matches[0]);

//XXX ... DON'T CHANGE THIS CODE ... XXX





if($email!="")

{



		$to = '';

		$subject = "Thank you for requesting 'Are Traditional Testing Methods Impeding Your Organization’s SAP Innovation?'";

		$from = 'Biz-tech Insights<campaign@advance.biz-tech-insights.com>';

		$from_name="Biz-tech Insights";

		

		 

		// To send HTML mail, the Content-type header must be set

		$headers  = 'MIME-Version: 1.0' . "\r\n";

		$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

		 

		// Create email headers

		$headers .= 'From: '.$from."\r\n".

			'Reply-To: '.$from."\r\n" .

			$headers .= 'Bcc: '.$email. "\r\n";

			

			'X-Mailer: PHP/' . phpversion();

		 

		// Compose a simple HTML email message

		$message = '<html><body>';



		$message .= '<p style="text-align: justify; font-size: 16px;margin-top:8px;margin-left:2px; padding-left:0px;">Dear <b>'.$firstname.'</b>,</p>';



		$message .= "<p style='text-align: justify; font-size: 14px;margin-top:8px;margin-left:2px; padding-left:0px;'>Thank you for requesting <b>Are Traditional Testing Methods Impeding Your Organization’s SAP Innovation?</b>. You can view it immediately by clicking <a href='http://advance.biz-tech-insights.com/LP-FY21-Q3-Tricentis-Lead-Engage/Are-traditional-testing-methods-impeding-your-organizations-SAP-innovation.pdf'>HERE</a>!</p>";

			

		$message .= '<p>&nbsp;</p>';

		$message .= '<p style="text-align: justify; font-size: 14px;margin-top:8px;margin-left:2px; padding-left:0px;">Sincerely,</p>';

		$message .= '<pstyle="text-align: justify; font-size: 14px;margin-top:8px;margin-left:2px; padding-left:0px;">Nina Ridgeway</p>';

		$message .= '<p style="text-align: justify; font-size: 14px;margin-top:8px;margin-left:2px; padding-left:0px;">Biz-tech Insights</p>';

		$message .= '</body></html>';

		 

		// Sending email

		mail($to, $subject, $message, $headers);

		

}





$PDF_URL = "http://advance.biz-tech-insights.com/LP-FY21-Q3-Tricentis-Lead-Engage/Are-traditional-testing-methods-impeding-your-organizations-SAP-innovation.pdf";



//XXX ... DON'T CHANGE THIS CODE ... XXX			

//header('Location: https://advance.biz-tech-insights.com/whitepaper/data-capture.php?link='.$PDF_URL.'&'.'data='.$temp.'&'.'action='.$action.'&'.'camp_id='.$camp_id.'&'.'URL='.$URL);



header('Location: http://advance.biz-tech-insights.com/LP-FY21-Q3-Tricentis-Lead-Engage/Are-traditional-testing-methods-impeding-your-organizations-SAP-innovation.pdf');

//XXX ... DON'T CHANGE THIS CODE ... XXX

?> 