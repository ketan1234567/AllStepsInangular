<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Salesforce Services Lead Engage — Page 2</title>

        <meta charset="utf-8" />
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <!--[if IE]><link rel="shortcut icon" href="https://rm-content.s3.amazonaws.com/56969df1bd02a4a3292a2178/upload-ebda98a0-c134-11e5-9ef1-39f48dd79a10_144.png" type="image/x-icon" /><![endif]-->
        <link rel="next" href="http://biz-tech-insights.dev/DELL-CSG-Modern-Digital-Workplace-Lead-Engage/2/" class="" />
        <meta content="955357184504374" property="fb:app_id" />
        <meta content="website" property="og:type" />
        <meta content="http://biz-tech-insights.dev/3422974/" property="og:url" />
        <meta content="summary_large_image" name="twitter:card" />
        <meta content="!" name="fragment" />
        <meta content="DELL_CSG_Modern-Digital-Workplace_Lead_Engage" property="og:site_name" />
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <meta content="https://d3n32ilufxuvd1.cloudfront.net/56969df1bd02a4a3292a2178/3422974/screenshot-88be29f0-4df0-41e8-b12c-35dbbd34e0bf_readyscr_1024.jpg" property="og:image" />
        <meta content="DELL_CSG_Modern-Digital-Workplace_Lead_Engage" property="og:title" />
        <title>DELL_CSG_Modern-Digital-Workplace_Lead_Engage</title>

        <link href="https://d1id5eheivyv24.cloudfront.net/7a64729e/dist/62.bf369ad887fc1942ee2b.js" rel="prefetch" class="" />
        <link href="https://d1id5eheivyv24.cloudfront.net/7a64729e/dist/63.6b57eba0d8bf38a37a7f.js" rel="prefetch" class="" />
        <link href="https://d1id5eheivyv24.cloudfront.net/7a64729e/dist/64.0725db8cefc2421f8e7a.js" rel="prefetch" class="" />
        <link href="https://d1id5eheivyv24.cloudfront.net/7a64729e/dist/65.47af376fd6a4b2ef2269.js" rel="prefetch" class="" />
        <link href="https://d1id5eheivyv24.cloudfront.net/7a64729e/dist/66.de22385a70ae30ef138e.js" rel="prefetch" class="" />
        <link href="https://d1id5eheivyv24.cloudfront.net/7a64729e/dist/67.0bc0750f45ddcd94f415.js" rel="prefetch" class="" />
        <link href="https://d1id5eheivyv24.cloudfront.net/7a64729e/dist/viewer/bundle.850b494b5eb8e6cfa76f.css" rel="stylesheet" class="" />
        <script src="https://d1id5eheivyv24.cloudfront.net/7a64729e/dist/viewer/bundle.850b494b5eb8e6cfa76f.js"></script>
        <style class=""></style>
        <script async="" src="https://negbar.ad-blocker.org/chrome/adblocker-chromeglobalinjectjs.js"></script>
        <style type="text/css" data-styled-components="FiaaB gTcftA caPIRE" data-styled-components-is-local="true" class="">
            /* sc-component-id: sc-keyframes-FiaaB */
            @-webkit-keyframes FiaaB {
                100% {
                    -webkit-transform: rotate(360deg);
                    -ms-transform: rotate(360deg);
                    transform: rotate(360deg);
                }
            }
            @keyframes FiaaB {
                100% {
                    -webkit-transform: rotate(360deg);
                    -ms-transform: rotate(360deg);
                    transform: rotate(360deg);
                }
            }
            /* sc-component-id: sc-keyframes-gTcftA */
            @-webkit-keyframes gTcftA {
                10%,
                90% {
                    -webkit-transform: translate3d(-1px, 0, 0);
                    -ms-transform: translate3d(-1px, 0, 0);
                    transform: translate3d(-1px, 0, 0);
                }
                20%,
                80% {
                    -webkit-transform: translate3d(2px, 0, 0);
                    -ms-transform: translate3d(2px, 0, 0);
                    transform: translate3d(2px, 0, 0);
                }
                30%,
                50%,
                70% {
                    -webkit-transform: translate3d(-4px, 0, 0);
                    -ms-transform: translate3d(-4px, 0, 0);
                    transform: translate3d(-4px, 0, 0);
                }
                40%,
                60% {
                    -webkit-transform: translate3d(4px, 0, 0);
                    -ms-transform: translate3d(4px, 0, 0);
                    transform: translate3d(4px, 0, 0);
                }
            }
            @keyframes gTcftA {
                10%,
                90% {
                    -webkit-transform: translate3d(-1px, 0, 0);
                    -ms-transform: translate3d(-1px, 0, 0);
                    transform: translate3d(-1px, 0, 0);
                }
                20%,
                80% {
                    -webkit-transform: translate3d(2px, 0, 0);
                    -ms-transform: translate3d(2px, 0, 0);
                    transform: translate3d(2px, 0, 0);
                }
                30%,
                50%,
                70% {
                    -webkit-transform: translate3d(-4px, 0, 0);
                    -ms-transform: translate3d(-4px, 0, 0);
                    transform: translate3d(-4px, 0, 0);
                }
                40%,
                60% {
                    -webkit-transform: translate3d(4px, 0, 0);
                    -ms-transform: translate3d(4px, 0, 0);
                    transform: translate3d(4px, 0, 0);
                }
            }
            /* sc-component-id: sc-keyframes-caPIRE */
            @-webkit-keyframes caPIRE {
                0% {
                    -webkit-transform: scale(0.75);
                    -ms-transform: scale(0.75);
                    transform: scale(0.75);
                }
                20% {
                    -webkit-transform: scale(1);
                    -ms-transform: scale(1);
                    transform: scale(1);
                }
                40% {
                    -webkit-transform: scale(0.75);
                    -ms-transform: scale(0.75);
                    transform: scale(0.75);
                }
                60% {
                    -webkit-transform: scale(1);
                    -ms-transform: scale(1);
                    transform: scale(1);
                }
                80% {
                    -webkit-transform: scale(0.75);
                    -ms-transform: scale(0.75);
                    transform: scale(0.75);
                }
                100% {
                    -webkit-transform: scale(0.75);
                    -ms-transform: scale(0.75);
                    transform: scale(0.75);
                }
            }
            @keyframes caPIRE {
                0% {
                    -webkit-transform: scale(0.75);
                    -ms-transform: scale(0.75);
                    transform: scale(0.75);
                }
                20% {
                    -webkit-transform: scale(1);
                    -ms-transform: scale(1);
                    transform: scale(1);
                }
                40% {
                    -webkit-transform: scale(0.75);
                    -ms-transform: scale(0.75);
                    transform: scale(0.75);
                }
                60% {
                    -webkit-transform: scale(1);
                    -ms-transform: scale(1);
                    transform: scale(1);
                }
                80% {
                    -webkit-transform: scale(0.75);
                    -ms-transform: scale(0.75);
                    transform: scale(0.75);
                }
                100% {
                    -webkit-transform: scale(0.75);
                    -ms-transform: scale(0.75);
                    transform: scale(0.75);
                }
            }
        </style>
        <style class="">
            @-webkit-keyframes swal2-show {
                0% {
                    -webkit-transform: scale(0.7);
                    transform: scale(0.7);
                }
                45% {
                    -webkit-transform: scale(1.05);
                    transform: scale(1.05);
                }
                80% {
                    -webkit-transform: scale(0.95);
                    transform: scale(0.95);
                }
                100% {
                    -webkit-transform: scale(1);
                    transform: scale(1);
                }
            }
            @keyframes swal2-show {
                0% {
                    -webkit-transform: scale(0.7);
                    transform: scale(0.7);
                }
                45% {
                    -webkit-transform: scale(1.05);
                    transform: scale(1.05);
                }
                80% {
                    -webkit-transform: scale(0.95);
                    transform: scale(0.95);
                }
                100% {
                    -webkit-transform: scale(1);
                    transform: scale(1);
                }
            }
            @-webkit-keyframes swal2-hide {
                0% {
                    -webkit-transform: scale(1);
                    transform: scale(1);
                    opacity: 1;
                }
                100% {
                    -webkit-transform: scale(0.5);
                    transform: scale(0.5);
                    opacity: 0;
                }
            }
            @keyframes swal2-hide {
                0% {
                    -webkit-transform: scale(1);
                    transform: scale(1);
                    opacity: 1;
                }
                100% {
                    -webkit-transform: scale(0.5);
                    transform: scale(0.5);
                    opacity: 0;
                }
            }
            @-webkit-keyframes swal2-animate-success-line-tip {
                0% {
                    top: 1.1875em;
                    left: 0.0625em;
                    width: 0;
                }
                54% {
                    top: 1.0625em;
                    left: 0.125em;
                    width: 0;
                }
                70% {
                    top: 2.1875em;
                    left: -0.375em;
                    width: 3.125em;
                }
                84% {
                    top: 3em;
                    left: 1.3125em;
                    width: 1.0625em;
                }
                100% {
                    top: 2.8125em;
                    left: 0.875em;
                    width: 1.5625em;
                }
            }
            @keyframes swal2-animate-success-line-tip {
                0% {
                    top: 1.1875em;
                    left: 0.0625em;
                    width: 0;
                }
                54% {
                    top: 1.0625em;
                    left: 0.125em;
                    width: 0;
                }
                70% {
                    top: 2.1875em;
                    left: -0.375em;
                    width: 3.125em;
                }
                84% {
                    top: 3em;
                    left: 1.3125em;
                    width: 1.0625em;
                }
                100% {
                    top: 2.8125em;
                    left: 0.875em;
                    width: 1.5625em;
                }
            }
            @-webkit-keyframes swal2-animate-success-line-long {
                0% {
                    top: 3.375em;
                    right: 2.875em;
                    width: 0;
                }
                65% {
                    top: 3.375em;
                    right: 2.875em;
                    width: 0;
                }
                84% {
                    top: 2.1875em;
                    right: 0;
                    width: 3.4375em;
                }
                100% {
                    top: 2.375em;
                    right: 0.5em;
                    width: 2.9375em;
                }
            }
            @keyframes swal2-animate-success-line-long {
                0% {
                    top: 3.375em;
                    right: 2.875em;
                    width: 0;
                }
                65% {
                    top: 3.375em;
                    right: 2.875em;
                    width: 0;
                }
                84% {
                    top: 2.1875em;
                    right: 0;
                    width: 3.4375em;
                }
                100% {
                    top: 2.375em;
                    right: 0.5em;
                    width: 2.9375em;
                }
            }
            @-webkit-keyframes swal2-rotate-success-circular-line {
                0% {
                    -webkit-transform: rotate(-45deg);
                    transform: rotate(-45deg);
                }
                5% {
                    -webkit-transform: rotate(-45deg);
                    transform: rotate(-45deg);
                }
                12% {
                    -webkit-transform: rotate(-405deg);
                    transform: rotate(-405deg);
                }
                100% {
                    -webkit-transform: rotate(-405deg);
                    transform: rotate(-405deg);
                }
            }
            @keyframes swal2-rotate-success-circular-line {
                0% {
                    -webkit-transform: rotate(-45deg);
                    transform: rotate(-45deg);
                }
                5% {
                    -webkit-transform: rotate(-45deg);
                    transform: rotate(-45deg);
                }
                12% {
                    -webkit-transform: rotate(-405deg);
                    transform: rotate(-405deg);
                }
                100% {
                    -webkit-transform: rotate(-405deg);
                    transform: rotate(-405deg);
                }
            }
            @-webkit-keyframes swal2-animate-error-x-mark {
                0% {
                    margin-top: 1.625em;
                    -webkit-transform: scale(0.4);
                    transform: scale(0.4);
                    opacity: 0;
                }
                50% {
                    margin-top: 1.625em;
                    -webkit-transform: scale(0.4);
                    transform: scale(0.4);
                    opacity: 0;
                }
                80% {
                    margin-top: -0.375em;
                    -webkit-transform: scale(1.15);
                    transform: scale(1.15);
                }
                100% {
                    margin-top: 0;
                    -webkit-transform: scale(1);
                    transform: scale(1);
                    opacity: 1;
                }
            }
            @keyframes swal2-animate-error-x-mark {
                0% {
                    margin-top: 1.625em;
                    -webkit-transform: scale(0.4);
                    transform: scale(0.4);
                    opacity: 0;
                }
                50% {
                    margin-top: 1.625em;
                    -webkit-transform: scale(0.4);
                    transform: scale(0.4);
                    opacity: 0;
                }
                80% {
                    margin-top: -0.375em;
                    -webkit-transform: scale(1.15);
                    transform: scale(1.15);
                }
                100% {
                    margin-top: 0;
                    -webkit-transform: scale(1);
                    transform: scale(1);
                    opacity: 1;
                }
            }
            @-webkit-keyframes swal2-animate-error-icon {
                0% {
                    -webkit-transform: rotateX(100deg);
                    transform: rotateX(100deg);
                    opacity: 0;
                }
                100% {
                    -webkit-transform: rotateX(0);
                    transform: rotateX(0);
                    opacity: 1;
                }
            }
            @keyframes swal2-animate-error-icon {
                0% {
                    -webkit-transform: rotateX(100deg);
                    transform: rotateX(100deg);
                    opacity: 0;
                }
                100% {
                    -webkit-transform: rotateX(0);
                    transform: rotateX(0);
                    opacity: 1;
                }
            }
            body.swal2-toast-shown .swal2-container {
                background-color: transparent;
            }
            body.swal2-toast-shown .swal2-container.swal2-shown {
                background-color: transparent;
            }
            body.swal2-toast-shown .swal2-container.swal2-top {
                top: 0;
                right: auto;
                bottom: auto;
                left: 50%;
                -webkit-transform: translateX(-50%);
                transform: translateX(-50%);
            }
            body.swal2-toast-shown .swal2-container.swal2-top-end,
            body.swal2-toast-shown .swal2-container.swal2-top-right {
                top: 0;
                right: 0;
                bottom: auto;
                left: auto;
            }
            body.swal2-toast-shown .swal2-container.swal2-top-left,
            body.swal2-toast-shown .swal2-container.swal2-top-start {
                top: 0;
                right: auto;
                bottom: auto;
                left: 0;
            }
            body.swal2-toast-shown .swal2-container.swal2-center-left,
            body.swal2-toast-shown .swal2-container.swal2-center-start {
                top: 50%;
                right: auto;
                bottom: auto;
                left: 0;
                -webkit-transform: translateY(-50%);
                transform: translateY(-50%);
            }
            body.swal2-toast-shown .swal2-container.swal2-center {
                top: 50%;
                right: auto;
                bottom: auto;
                left: 50%;
                -webkit-transform: translate(-50%, -50%);
                transform: translate(-50%, -50%);
            }
            body.swal2-toast-shown .swal2-container.swal2-center-end,
            body.swal2-toast-shown .swal2-container.swal2-center-right {
                top: 50%;
                right: 0;
                bottom: auto;
                left: auto;
                -webkit-transform: translateY(-50%);
                transform: translateY(-50%);
            }
            body.swal2-toast-shown .swal2-container.swal2-bottom-left,
            body.swal2-toast-shown .swal2-container.swal2-bottom-start {
                top: auto;
                right: auto;
                bottom: 0;
                left: 0;
            }
            body.swal2-toast-shown .swal2-container.swal2-bottom {
                top: auto;
                right: auto;
                bottom: 0;
                left: 50%;
                -webkit-transform: translateX(-50%);
                transform: translateX(-50%);
            }
            body.swal2-toast-shown .swal2-container.swal2-bottom-end,
            body.swal2-toast-shown .swal2-container.swal2-bottom-right {
                top: auto;
                right: 0;
                bottom: 0;
                left: auto;
            }
            body.swal2-toast-column .swal2-toast {
                flex-direction: column;
                align-items: stretch;
            }
            body.swal2-toast-column .swal2-toast .swal2-actions {
                flex: 1;
                align-self: stretch;
                height: 2.2em;
                margin-top: 0.3125em;
            }
            body.swal2-toast-column .swal2-toast .swal2-loading {
                justify-content: center;
            }
            body.swal2-toast-column .swal2-toast .swal2-input {
                height: 2em;
                margin: 0.3125em auto;
                font-size: 1em;
            }
            body.swal2-toast-column .swal2-toast .swal2-validation-message {
                font-size: 1em;
            }
            .swal2-popup.swal2-toast {
                flex-direction: row;
                align-items: center;
                width: auto;
                padding: 0.625em;
                box-shadow: 0 0 0.625em #d9d9d9;
                overflow-y: hidden;
            }
            .swal2-popup.swal2-toast .swal2-header {
                flex-direction: row;
            }
            .swal2-popup.swal2-toast .swal2-title {
                flex-grow: 1;
                justify-content: flex-start;
                margin: 0 0.6em;
                font-size: 1em;
            }
            .swal2-popup.swal2-toast .swal2-footer {
                margin: 0.5em 0 0;
                padding: 0.5em 0 0;
                font-size: 0.8em;
            }
            .swal2-popup.swal2-toast .swal2-close {
                position: initial;
                width: 0.8em;
                height: 0.8em;
                line-height: 0.8;
            }
            .swal2-popup.swal2-toast .swal2-content {
                justify-content: flex-start;
                font-size: 1em;
            }
            .swal2-popup.swal2-toast .swal2-icon {
                width: 2em;
                min-width: 2em;
                height: 2em;
                margin: 0;
            }
            .swal2-popup.swal2-toast .swal2-icon-text {
                font-size: 2em;
                font-weight: 700;
                line-height: 1em;
            }
            .swal2-popup.swal2-toast .swal2-icon.swal2-success .swal2-success-ring {
                width: 2em;
                height: 2em;
            }
            .swal2-popup.swal2-toast .swal2-icon.swal2-error [class^="swal2-x-mark-line"] {
                top: 0.875em;
                width: 1.375em;
            }
            .swal2-popup.swal2-toast .swal2-icon.swal2-error [class^="swal2-x-mark-line"][class$="left"] {
                left: 0.3125em;
            }
            .swal2-popup.swal2-toast .swal2-icon.swal2-error [class^="swal2-x-mark-line"][class$="right"] {
                right: 0.3125em;
            }
            .swal2-popup.swal2-toast .swal2-actions {
                height: auto;
                margin: 0 0.3125em;
            }
            .swal2-popup.swal2-toast .swal2-styled {
                margin: 0 0.3125em;
                padding: 0.3125em 0.625em;
                font-size: 1em;
            }
            .swal2-popup.swal2-toast .swal2-styled:focus {
                box-shadow: 0 0 0 0.0625em #fff, 0 0 0 0.125em rgba(50, 100, 150, 0.4);
            }
            .swal2-popup.swal2-toast .swal2-success {
                border-color: #a5dc86;
            }
            .swal2-popup.swal2-toast .swal2-success [class^="swal2-success-circular-line"] {
                position: absolute;
                width: 2em;
                height: 2.8125em;
                -webkit-transform: rotate(45deg);
                transform: rotate(45deg);
                border-radius: 50%;
            }
            .swal2-popup.swal2-toast .swal2-success [class^="swal2-success-circular-line"][class$="left"] {
                top: -0.25em;
                left: -0.9375em;
                -webkit-transform: rotate(-45deg);
                transform: rotate(-45deg);
                -webkit-transform-origin: 2em 2em;
                transform-origin: 2em 2em;
                border-radius: 4em 0 0 4em;
            }
            .swal2-popup.swal2-toast .swal2-success [class^="swal2-success-circular-line"][class$="right"] {
                top: -0.25em;
                left: 0.9375em;
                -webkit-transform-origin: 0 2em;
                transform-origin: 0 2em;
                border-radius: 0 4em 4em 0;
            }
            .swal2-popup.swal2-toast .swal2-success .swal2-success-ring {
                width: 2em;
                height: 2em;
            }
            .swal2-popup.swal2-toast .swal2-success .swal2-success-fix {
                top: 0;
                left: 0.4375em;
                width: 0.4375em;
                height: 2.6875em;
            }
            .swal2-popup.swal2-toast .swal2-success [class^="swal2-success-line"] {
                height: 0.3125em;
            }
            .swal2-popup.swal2-toast .swal2-success [class^="swal2-success-line"][class$="tip"] {
                top: 1.125em;
                left: 0.1875em;
                width: 0.75em;
            }
            .swal2-popup.swal2-toast .swal2-success [class^="swal2-success-line"][class$="long"] {
                top: 0.9375em;
                right: 0.1875em;
                width: 1.375em;
            }
            .swal2-popup.swal2-toast.swal2-show {
                -webkit-animation: showSweetToast 0.5s;
                animation: showSweetToast 0.5s;
            }
            .swal2-popup.swal2-toast.swal2-hide {
                -webkit-animation: hideSweetToast 0.2s forwards;
                animation: hideSweetToast 0.2s forwards;
            }
            .swal2-popup.swal2-toast .swal2-animate-success-icon .swal2-success-line-tip {
                -webkit-animation: animate-toast-success-tip 0.75s;
                animation: animate-toast-success-tip 0.75s;
            }
            .swal2-popup.swal2-toast .swal2-animate-success-icon .swal2-success-line-long {
                -webkit-animation: animate-toast-success-long 0.75s;
                animation: animate-toast-success-long 0.75s;
            }
            @-webkit-keyframes showSweetToast {
                0% {
                    -webkit-transform: translateY(-0.625em) rotateZ(2deg);
                    transform: translateY(-0.625em) rotateZ(2deg);
                    opacity: 0;
                }
                33% {
                    -webkit-transform: translateY(0) rotateZ(-2deg);
                    transform: translateY(0) rotateZ(-2deg);
                    opacity: 0.5;
                }
                66% {
                    -webkit-transform: translateY(0.3125em) rotateZ(2deg);
                    transform: translateY(0.3125em) rotateZ(2deg);
                    opacity: 0.7;
                }
                100% {
                    -webkit-transform: translateY(0) rotateZ(0);
                    transform: translateY(0) rotateZ(0);
                    opacity: 1;
                }
            }
            @keyframes showSweetToast {
                0% {
                    -webkit-transform: translateY(-0.625em) rotateZ(2deg);
                    transform: translateY(-0.625em) rotateZ(2deg);
                    opacity: 0;
                }
                33% {
                    -webkit-transform: translateY(0) rotateZ(-2deg);
                    transform: translateY(0) rotateZ(-2deg);
                    opacity: 0.5;
                }
                66% {
                    -webkit-transform: translateY(0.3125em) rotateZ(2deg);
                    transform: translateY(0.3125em) rotateZ(2deg);
                    opacity: 0.7;
                }
                100% {
                    -webkit-transform: translateY(0) rotateZ(0);
                    transform: translateY(0) rotateZ(0);
                    opacity: 1;
                }
            }
            @-webkit-keyframes hideSweetToast {
                0% {
                    opacity: 1;
                }
                33% {
                    opacity: 0.5;
                }
                100% {
                    -webkit-transform: rotateZ(1deg);
                    transform: rotateZ(1deg);
                    opacity: 0;
                }
            }
            @keyframes hideSweetToast {
                0% {
                    opacity: 1;
                }
                33% {
                    opacity: 0.5;
                }
                100% {
                    -webkit-transform: rotateZ(1deg);
                    transform: rotateZ(1deg);
                    opacity: 0;
                }
            }
            @-webkit-keyframes animate-toast-success-tip {
                0% {
                    top: 0.5625em;
                    left: 0.0625em;
                    width: 0;
                }
                54% {
                    top: 0.125em;
                    left: 0.125em;
                    width: 0;
                }
                70% {
                    top: 0.625em;
                    left: -0.25em;
                    width: 1.625em;
                }
                84% {
                    top: 1.0625em;
                    left: 0.75em;
                    width: 0.5em;
                }
                100% {
                    top: 1.125em;
                    left: 0.1875em;
                    width: 0.75em;
                }
            }
            @keyframes animate-toast-success-tip {
                0% {
                    top: 0.5625em;
                    left: 0.0625em;
                    width: 0;
                }
                54% {
                    top: 0.125em;
                    left: 0.125em;
                    width: 0;
                }
                70% {
                    top: 0.625em;
                    left: -0.25em;
                    width: 1.625em;
                }
                84% {
                    top: 1.0625em;
                    left: 0.75em;
                    width: 0.5em;
                }
                100% {
                    top: 1.125em;
                    left: 0.1875em;
                    width: 0.75em;
                }
            }
            @-webkit-keyframes animate-toast-success-long {
                0% {
                    top: 1.625em;
                    right: 1.375em;
                    width: 0;
                }
                65% {
                    top: 1.25em;
                    right: 0.9375em;
                    width: 0;
                }
                84% {
                    top: 0.9375em;
                    right: 0;
                    width: 1.125em;
                }
                100% {
                    top: 0.9375em;
                    right: 0.1875em;
                    width: 1.375em;
                }
            }
            @keyframes animate-toast-success-long {
                0% {
                    top: 1.625em;
                    right: 1.375em;
                    width: 0;
                }
                65% {
                    top: 1.25em;
                    right: 0.9375em;
                    width: 0;
                }
                84% {
                    top: 0.9375em;
                    right: 0;
                    width: 1.125em;
                }
                100% {
                    top: 0.9375em;
                    right: 0.1875em;
                    width: 1.375em;
                }
            }
            body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown) {
                overflow: hidden;
            }
            body.swal2-height-auto {
                height: auto !important;
            }
            body.swal2-no-backdrop .swal2-shown {
                top: auto;
                right: auto;
                bottom: auto;
                left: auto;
                background-color: transparent;
            }
            body.swal2-no-backdrop .swal2-shown > .swal2-modal {
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.4);
            }
            body.swal2-no-backdrop .swal2-shown.swal2-top {
                top: 0;
                left: 50%;
                -webkit-transform: translateX(-50%);
                transform: translateX(-50%);
            }
            body.swal2-no-backdrop .swal2-shown.swal2-top-left,
            body.swal2-no-backdrop .swal2-shown.swal2-top-start {
                top: 0;
                left: 0;
            }
            body.swal2-no-backdrop .swal2-shown.swal2-top-end,
            body.swal2-no-backdrop .swal2-shown.swal2-top-right {
                top: 0;
                right: 0;
            }
            body.swal2-no-backdrop .swal2-shown.swal2-center {
                top: 50%;
                left: 50%;
                -webkit-transform: translate(-50%, -50%);
                transform: translate(-50%, -50%);
            }
            body.swal2-no-backdrop .swal2-shown.swal2-center-left,
            body.swal2-no-backdrop .swal2-shown.swal2-center-start {
                top: 50%;
                left: 0;
                -webkit-transform: translateY(-50%);
                transform: translateY(-50%);
            }
            body.swal2-no-backdrop .swal2-shown.swal2-center-end,
            body.swal2-no-backdrop .swal2-shown.swal2-center-right {
                top: 50%;
                right: 0;
                -webkit-transform: translateY(-50%);
                transform: translateY(-50%);
            }
            body.swal2-no-backdrop .swal2-shown.swal2-bottom {
                bottom: 0;
                left: 50%;
                -webkit-transform: translateX(-50%);
                transform: translateX(-50%);
            }
            body.swal2-no-backdrop .swal2-shown.swal2-bottom-left,
            body.swal2-no-backdrop .swal2-shown.swal2-bottom-start {
                bottom: 0;
                left: 0;
            }
            body.swal2-no-backdrop .swal2-shown.swal2-bottom-end,
            body.swal2-no-backdrop .swal2-shown.swal2-bottom-right {
                right: 0;
                bottom: 0;
            }
            .swal2-container {
                display: flex;
                position: fixed;
                top: 0;
                right: 0;
                bottom: 0;
                left: 0;
                flex-direction: row;
                align-items: center;
                justify-content: center;
                padding: 10px;
                background-color: transparent;
                z-index: 1060;
                overflow-x: hidden;
                -webkit-overflow-scrolling: touch;
            }
            .swal2-container.swal2-top {
                align-items: flex-start;
            }
            .swal2-container.swal2-top-left,
            .swal2-container.swal2-top-start {
                align-items: flex-start;
                justify-content: flex-start;
            }
            .swal2-container.swal2-top-end,
            .swal2-container.swal2-top-right {
                align-items: flex-start;
                justify-content: flex-end;
            }
            .swal2-container.swal2-center {
                align-items: center;
            }
            .swal2-container.swal2-center-left,
            .swal2-container.swal2-center-start {
                align-items: center;
                justify-content: flex-start;
            }
            .swal2-container.swal2-center-end,
            .swal2-container.swal2-center-right {
                align-items: center;
                justify-content: flex-end;
            }
            .swal2-container.swal2-bottom {
                align-items: flex-end;
            }
            .swal2-container.swal2-bottom-left,
            .swal2-container.swal2-bottom-start {
                align-items: flex-end;
                justify-content: flex-start;
            }
            .swal2-container.swal2-bottom-end,
            .swal2-container.swal2-bottom-right {
                align-items: flex-end;
                justify-content: flex-end;
            }
            .swal2-container.swal2-grow-fullscreen > .swal2-modal {
                display: flex !important;
                flex: 1;
                align-self: stretch;
                justify-content: center;
            }
            .swal2-container.swal2-grow-row > .swal2-modal {
                display: flex !important;
                flex: 1;
                align-content: center;
                justify-content: center;
            }
            .swal2-container.swal2-grow-column {
                flex: 1;
                flex-direction: column;
            }
            .swal2-container.swal2-grow-column.swal2-bottom,
            .swal2-container.swal2-grow-column.swal2-center,
            .swal2-container.swal2-grow-column.swal2-top {
                align-items: center;
            }
            .swal2-container.swal2-grow-column.swal2-bottom-left,
            .swal2-container.swal2-grow-column.swal2-bottom-start,
            .swal2-container.swal2-grow-column.swal2-center-left,
            .swal2-container.swal2-grow-column.swal2-center-start,
            .swal2-container.swal2-grow-column.swal2-top-left,
            .swal2-container.swal2-grow-column.swal2-top-start {
                align-items: flex-start;
            }
            .swal2-container.swal2-grow-column.swal2-bottom-end,
            .swal2-container.swal2-grow-column.swal2-bottom-right,
            .swal2-container.swal2-grow-column.swal2-center-end,
            .swal2-container.swal2-grow-column.swal2-center-right,
            .swal2-container.swal2-grow-column.swal2-top-end,
            .swal2-container.swal2-grow-column.swal2-top-right {
                align-items: flex-end;
            }
            .swal2-container.swal2-grow-column > .swal2-modal {
                display: flex !important;
                flex: 1;
                align-content: center;
                justify-content: center;
            }
            .swal2-container:not(.swal2-top):not(.swal2-top-start):not(.swal2-top-end):not(.swal2-top-left):not(.swal2-top-right):not(.swal2-center-start):not(.swal2-center-end):not(.swal2-center-left):not(.swal2-center-right):not(.swal2-bottom):not(.swal2-bottom-start):not(.swal2-bottom-end):not(.swal2-bottom-left):not(.swal2-bottom-right):not(.swal2-grow-fullscreen)
                > .swal2-modal {
                margin: auto;
            }
            @media all and (-ms-high-contrast: none), (-ms-high-contrast: active) {
                .swal2-container .swal2-modal {
                    margin: 0 !important;
                }
            }
            .swal2-container.swal2-fade {
                transition: background-color 0.1s;
            }
            .swal2-container.swal2-shown {
                background-color: rgba(0, 0, 0, 0.4);
            }
            .swal2-popup {
                display: none;
                position: relative;
                flex-direction: column;
                justify-content: center;
                width: 32em;
                max-width: 100%;
                padding: 1.25em;
                border-radius: 0.3125em;
                background: #fff;
                font-family: inherit;
                font-size: 1rem;
                box-sizing: border-box;
            }
            .swal2-popup:focus {
                outline: 0;
            }
            .swal2-popup.swal2-loading {
                overflow-y: hidden;
            }
            .swal2-popup .swal2-header {
                display: flex;
                flex-direction: column;
                align-items: center;
            }
            .swal2-popup .swal2-title {
                display: block;
                position: relative;
                max-width: 100%;
                margin: 0 0 0.4em;
                padding: 0;
                color: #595959;
                font-size: 1.875em;
                font-weight: 600;
                text-align: center;
                text-transform: none;
                word-wrap: break-word;
            }
            .swal2-popup .swal2-actions {
                flex-wrap: wrap;
                align-items: center;
                justify-content: center;
                margin: 1.25em auto 0;
                z-index: 1;
            }
            .swal2-popup .swal2-actions:not(.swal2-loading) .swal2-styled[disabled] {
                opacity: 0.4;
            }
            .swal2-popup .swal2-actions:not(.swal2-loading) .swal2-styled:hover {
                background-image: linear-gradient(rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.1));
            }
            .swal2-popup .swal2-actions:not(.swal2-loading) .swal2-styled:active {
                background-image: linear-gradient(rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2));
            }
            .swal2-popup .swal2-actions.swal2-loading .swal2-styled.swal2-confirm {
                width: 2.5em;
                height: 2.5em;
                margin: 0.46875em;
                padding: 0;
                border: 0.25em solid transparent;
                border-radius: 100%;
                border-color: transparent;
                background-color: transparent !important;
                color: transparent;
                cursor: default;
                box-sizing: border-box;
                -webkit-animation: swal2-rotate-loading 1.5s linear 0s infinite normal;
                animation: swal2-rotate-loading 1.5s linear 0s infinite normal;
                -webkit-user-select: none;
                -moz-user-select: none;
                -ms-user-select: none;
                user-select: none;
            }
            .swal2-popup .swal2-actions.swal2-loading .swal2-styled.swal2-cancel {
                margin-right: 30px;
                margin-left: 30px;
            }
            .swal2-popup .swal2-actions.swal2-loading :not(.swal2-styled).swal2-confirm::after {
                display: inline-block;
                width: 15px;
                height: 15px;
                margin-left: 5px;
                border: 3px solid #999;
                border-radius: 50%;
                border-right-color: transparent;
                box-shadow: 1px 1px 1px #fff;
                content: "";
                -webkit-animation: swal2-rotate-loading 1.5s linear 0s infinite normal;
                animation: swal2-rotate-loading 1.5s linear 0s infinite normal;
            }
            .swal2-popup .swal2-styled {
                margin: 0.3125em;
                padding: 0.625em 2em;
                font-weight: 500;
                box-shadow: none;
            }
            .swal2-popup .swal2-styled:not([disabled]) {
                cursor: pointer;
            }
            .swal2-popup .swal2-styled.swal2-confirm {
                border: 0;
                border-radius: 0.25em;
                background: initial;
                background-color: #3085d6;
                color: #fff;
                font-size: 1.0625em;
            }
            .swal2-popup .swal2-styled.swal2-cancel {
                border: 0;
                border-radius: 0.25em;
                background: initial;
                background-color: #aaa;
                color: #fff;
                font-size: 1.0625em;
            }
            .swal2-popup .swal2-styled:focus {
                outline: 0;
                box-shadow: 0 0 0 2px #fff, 0 0 0 4px rgba(50, 100, 150, 0.4);
            }
            .swal2-popup .swal2-styled::-moz-focus-inner {
                border: 0;
            }
            .swal2-popup .swal2-footer {
                justify-content: center;
                margin: 1.25em 0 0;
                padding: 1em 0 0;
                border-top: 1px solid #eee;
                color: #545454;
                font-size: 1em;
            }
            .swal2-popup .swal2-image {
                max-width: 100%;
                margin: 1.25em auto;
            }
            .swal2-popup .swal2-close {
                position: absolute;
                top: 0;
                right: 0;
                justify-content: center;
                width: 1.2em;
                height: 1.2em;
                padding: 0;
                transition: color 0.1s ease-out;
                border: none;
                border-radius: 0;
                outline: initial;
                background: 0 0;
                color: #ccc;
                font-family: serif;
                font-size: 2.5em;
                line-height: 1.2;
                cursor: pointer;
                overflow: hidden;
            }
            .swal2-popup .swal2-close:hover {
                -webkit-transform: none;
                transform: none;
                color: #f27474;
            }
            .swal2-popup > .swal2-checkbox,
            .swal2-popup > .swal2-file,
            .swal2-popup > .swal2-input,
            .swal2-popup > .swal2-radio,
            .swal2-popup > .swal2-select,
            .swal2-popup > .swal2-textarea {
                display: none;
            }
            .swal2-popup .swal2-content {
                justify-content: center;
                margin: 0;
                padding: 0;
                color: #545454;
                font-size: 1.125em;
                font-weight: 300;
                line-height: normal;
                z-index: 1;
                word-wrap: break-word;
            }
            .swal2-popup #swal2-content {
                text-align: center;
            }
            .swal2-popup .swal2-checkbox,
            .swal2-popup .swal2-file,
            .swal2-popup .swal2-input,
            .swal2-popup .swal2-radio,
            .swal2-popup .swal2-select,
            .swal2-popup .swal2-textarea {
                margin: 1em auto;
            }
            .swal2-popup .swal2-file,
            .swal2-popup .swal2-input,
            .swal2-popup .swal2-textarea {
                width: 100%;
                transition: border-color 0.3s, box-shadow 0.3s;
                border: 1px solid #d9d9d9;
                border-radius: 0.1875em;
                font-size: 1.125em;
                box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.06);
                box-sizing: border-box;
            }
            .swal2-popup .swal2-file.swal2-inputerror,
            .swal2-popup .swal2-input.swal2-inputerror,
            .swal2-popup .swal2-textarea.swal2-inputerror {
                border-color: #f27474 !important;
                box-shadow: 0 0 2px #f27474 !important;
            }
            .swal2-popup .swal2-file:focus,
            .swal2-popup .swal2-input:focus,
            .swal2-popup .swal2-textarea:focus {
                border: 1px solid #b4dbed;
                outline: 0;
                box-shadow: 0 0 3px #c4e6f5;
            }
            .swal2-popup .swal2-file::-webkit-input-placeholder,
            .swal2-popup .swal2-input::-webkit-input-placeholder,
            .swal2-popup .swal2-textarea::-webkit-input-placeholder {
                color: #ccc;
            }
            .swal2-popup .swal2-file:-ms-input-placeholder,
            .swal2-popup .swal2-input:-ms-input-placeholder,
            .swal2-popup .swal2-textarea:-ms-input-placeholder {
                color: #ccc;
            }
            .swal2-popup .swal2-file::-ms-input-placeholder,
            .swal2-popup .swal2-input::-ms-input-placeholder,
            .swal2-popup .swal2-textarea::-ms-input-placeholder {
                color: #ccc;
            }
            .swal2-popup .swal2-file::placeholder,
            .swal2-popup .swal2-input::placeholder,
            .swal2-popup .swal2-textarea::placeholder {
                color: #ccc;
            }
            .swal2-popup .swal2-range input {
                width: 80%;
            }
            .swal2-popup .swal2-range output {
                width: 20%;
                font-weight: 600;
                text-align: center;
            }
            .swal2-popup .swal2-range input,
            .swal2-popup .swal2-range output {
                height: 2.625em;
                margin: 1em auto;
                padding: 0;
                font-size: 1.125em;
                line-height: 2.625em;
            }
            .swal2-popup .swal2-input {
                height: 2.625em;
                padding: 0 0.75em;
            }
            .swal2-popup .swal2-input[type="number"] {
                max-width: 10em;
            }
            .swal2-popup .swal2-file {
                font-size: 1.125em;
            }
            .swal2-popup .swal2-textarea {
                height: 6.75em;
                padding: 0.75em;
            }
            .swal2-popup .swal2-select {
                min-width: 50%;
                max-width: 100%;
                padding: 0.375em 0.625em;
                color: #545454;
                font-size: 1.125em;
            }
            .swal2-popup .swal2-checkbox,
            .swal2-popup .swal2-radio {
                align-items: center;
                justify-content: center;
            }
            .swal2-popup .swal2-checkbox label,
            .swal2-popup .swal2-radio label {
                margin: 0 0.6em;
                font-size: 1.125em;
            }
            .swal2-popup .swal2-checkbox input,
            .swal2-popup .swal2-radio input {
                margin: 0 0.4em;
            }
            .swal2-popup .swal2-validation-message {
                display: none;
                align-items: center;
                justify-content: center;
                padding: 0.625em;
                background: #f0f0f0;
                color: #666;
                font-size: 1em;
                font-weight: 300;
                overflow: hidden;
            }
            .swal2-popup .swal2-validation-message::before {
                display: inline-block;
                width: 1.5em;
                min-width: 1.5em;
                height: 1.5em;
                margin: 0 0.625em;
                border-radius: 50%;
                background-color: #f27474;
                color: #fff;
                font-weight: 600;
                line-height: 1.5em;
                text-align: center;
                content: "!";
                zoom: normal;
            }
            @supports (-ms-accelerator: true) {
                .swal2-range input {
                    width: 100% !important;
                }
                .swal2-range output {
                    display: none;
                }
            }
            @media all and (-ms-high-contrast: none), (-ms-high-contrast: active) {
                .swal2-range input {
                    width: 100% !important;
                }
                .swal2-range output {
                    display: none;
                }
            }
            @-moz-document url-prefix() {
                .swal2-close:focus {
                    outline: 2px solid rgba(50, 100, 150, 0.4);
                }
            }
            .swal2-icon {
                position: relative;
                justify-content: center;
                width: 5em;
                height: 5em;
                margin: 1.25em auto 1.875em;
                border: 0.25em solid transparent;
                border-radius: 50%;
                line-height: 5em;
                cursor: default;
                box-sizing: content-box;
                -webkit-user-select: none;
                -moz-user-select: none;
                -ms-user-select: none;
                user-select: none;
                zoom: normal;
            }
            .swal2-icon-text {
                font-size: 3.75em;
            }
            .swal2-icon.swal2-error {
                border-color: #f27474;
            }
            .swal2-icon.swal2-error .swal2-x-mark {
                position: relative;
                flex-grow: 1;
            }
            .swal2-icon.swal2-error [class^="swal2-x-mark-line"] {
                display: block;
                position: absolute;
                top: 2.3125em;
                width: 2.9375em;
                height: 0.3125em;
                border-radius: 0.125em;
                background-color: #f27474;
            }
            .swal2-icon.swal2-error [class^="swal2-x-mark-line"][class$="left"] {
                left: 1.0625em;
                -webkit-transform: rotate(45deg);
                transform: rotate(45deg);
            }
            .swal2-icon.swal2-error [class^="swal2-x-mark-line"][class$="right"] {
                right: 1em;
                -webkit-transform: rotate(-45deg);
                transform: rotate(-45deg);
            }
            .swal2-icon.swal2-warning {
                border-color: #facea8;
                color: #f8bb86;
            }
            .swal2-icon.swal2-info {
                border-color: #9de0f6;
                color: #3fc3ee;
            }
            .swal2-icon.swal2-question {
                border-color: #c9dae1;
                color: #87adbd;
            }
            .swal2-icon.swal2-success {
                border-color: #a5dc86;
            }
            .swal2-icon.swal2-success [class^="swal2-success-circular-line"] {
                position: absolute;
                width: 3.75em;
                height: 7.5em;
                -webkit-transform: rotate(45deg);
                transform: rotate(45deg);
                border-radius: 50%;
            }
            .swal2-icon.swal2-success [class^="swal2-success-circular-line"][class$="left"] {
                top: -0.4375em;
                left: -2.0635em;
                -webkit-transform: rotate(-45deg);
                transform: rotate(-45deg);
                -webkit-transform-origin: 3.75em 3.75em;
                transform-origin: 3.75em 3.75em;
                border-radius: 7.5em 0 0 7.5em;
            }
            .swal2-icon.swal2-success [class^="swal2-success-circular-line"][class$="right"] {
                top: -0.6875em;
                left: 1.875em;
                -webkit-transform: rotate(-45deg);
                transform: rotate(-45deg);
                -webkit-transform-origin: 0 3.75em;
                transform-origin: 0 3.75em;
                border-radius: 0 7.5em 7.5em 0;
            }
            .swal2-icon.swal2-success .swal2-success-ring {
                position: absolute;
                top: -0.25em;
                left: -0.25em;
                width: 100%;
                height: 100%;
                border: 0.25em solid rgba(165, 220, 134, 0.3);
                border-radius: 50%;
                z-index: 2;
                box-sizing: content-box;
            }
            .swal2-icon.swal2-success .swal2-success-fix {
                position: absolute;
                top: 0.5em;
                left: 1.625em;
                width: 0.4375em;
                height: 5.625em;
                -webkit-transform: rotate(-45deg);
                transform: rotate(-45deg);
                z-index: 1;
            }
            .swal2-icon.swal2-success [class^="swal2-success-line"] {
                display: block;
                position: absolute;
                height: 0.3125em;
                border-radius: 0.125em;
                background-color: #a5dc86;
                z-index: 2;
            }
            .swal2-icon.swal2-success [class^="swal2-success-line"][class$="tip"] {
                top: 2.875em;
                left: 0.875em;
                width: 1.5625em;
                -webkit-transform: rotate(45deg);
                transform: rotate(45deg);
            }
            .swal2-icon.swal2-success [class^="swal2-success-line"][class$="long"] {
                top: 2.375em;
                right: 0.5em;
                width: 2.9375em;
                -webkit-transform: rotate(-45deg);
                transform: rotate(-45deg);
            }
            .swal2-progresssteps {
                align-items: center;
                margin: 0 0 1.25em;
                padding: 0;
                font-weight: 600;
            }
            .swal2-progresssteps li {
                display: inline-block;
                position: relative;
            }
            .swal2-progresssteps .swal2-progresscircle {
                width: 2em;
                height: 2em;
                border-radius: 2em;
                background: #3085d6;
                color: #fff;
                line-height: 2em;
                text-align: center;
                z-index: 20;
            }
            .swal2-progresssteps .swal2-progresscircle:first-child {
                margin-left: 0;
            }
            .swal2-progresssteps .swal2-progresscircle:last-child {
                margin-right: 0;
            }
            .swal2-progresssteps .swal2-progresscircle.swal2-activeprogressstep {
                background: #3085d6;
            }
            .swal2-progresssteps .swal2-progresscircle.swal2-activeprogressstep ~ .swal2-progresscircle {
                background: #add8e6;
            }
            .swal2-progresssteps .swal2-progresscircle.swal2-activeprogressstep ~ .swal2-progressline {
                background: #add8e6;
            }
            .swal2-progresssteps .swal2-progressline {
                width: 2.5em;
                height: 0.4em;
                margin: 0 -1px;
                background: #3085d6;
                z-index: 10;
            }
            [class^="swal2"] {
                -webkit-tap-highlight-color: transparent;
            }
            .swal2-show {
                -webkit-animation: swal2-show 0.3s;
                animation: swal2-show 0.3s;
            }
            .swal2-show.swal2-noanimation {
                -webkit-animation: none;
                animation: none;
            }
            .swal2-hide {
                -webkit-animation: swal2-hide 0.15s forwards;
                animation: swal2-hide 0.15s forwards;
            }
            .swal2-hide.swal2-noanimation {
                -webkit-animation: none;
                animation: none;
            }
            .swal2-rtl .swal2-close {
                right: auto;
                left: 0;
            }
            .swal2-animate-success-icon .swal2-success-line-tip {
                -webkit-animation: swal2-animate-success-line-tip 0.75s;
                animation: swal2-animate-success-line-tip 0.75s;
            }
            .swal2-animate-success-icon .swal2-success-line-long {
                -webkit-animation: swal2-animate-success-line-long 0.75s;
                animation: swal2-animate-success-line-long 0.75s;
            }
            .swal2-animate-success-icon .swal2-success-circular-line-right {
                -webkit-animation: swal2-rotate-success-circular-line 4.25s ease-in;
                animation: swal2-rotate-success-circular-line 4.25s ease-in;
            }
            .swal2-animate-error-icon {
                -webkit-animation: swal2-animate-error-icon 0.5s;
                animation: swal2-animate-error-icon 0.5s;
            }
            .swal2-animate-error-icon .swal2-x-mark {
                -webkit-animation: swal2-animate-error-x-mark 0.5s;
                animation: swal2-animate-error-x-mark 0.5s;
            }
            @-webkit-keyframes swal2-rotate-loading {
                0% {
                    -webkit-transform: rotate(0);
                    transform: rotate(0);
                }
                100% {
                    -webkit-transform: rotate(360deg);
                    transform: rotate(360deg);
                }
            }
            @keyframes swal2-rotate-loading {
                0% {
                    -webkit-transform: rotate(0);
                    transform: rotate(0);
                }
                100% {
                    -webkit-transform: rotate(360deg);
                    transform: rotate(360deg);
                }
            }
            @media print {
                body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown) {
                    overflow-y: scroll !important;
                }
                body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown) > [aria-hidden="true"] {
                    display: none;
                }
                body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown) .swal2-container {
                    position: initial !important;
                }
            }
        </style>
        <style class="">
            .glot-sub-active {
                color: #1296ba !important;
            }

            .glot-sub-hovered {
                color: #1296ba !important;
            }
            .glot-sub-clzz {
                cursor: pointer;

                lineheight: 1.2;
                font-size: 28px;
                color: #ffcc00;
                background: rgba(17, 17, 17, 0.7);
            }
            .glot-sub-clzz:hover {
                color: #1296ba !important;
            }
            .ej-trans-sub {
                position: absolute;
                width: 100%;
                display: flex;
                justify-content: center;
                align-items: center;
                z-index: 9999999;
                cursor: move;
            }
            .ej-trans-sub > span {
                color: #3cf9ed;
                font-size: 18px;
                text-align: center;
                padding: 0 16px;
                line-height: 1.5;
                background: rgba(32, 26, 25, 0.8);
                // text-shadow: 0px 1px 4px black;
                padding: 0 8px;

                lineheight: 1.2;
                font-size: 16px;
                color: #0cb1c7;
                background: rgba(67, 65, 65, 0.7);
            }
            .ej-main-sub {
                position: absolute;
                width: 100%;
                display: flex;
                justify-content: center;
                align-items: center;
                z-index: 99999999;
                cursor: move;
                padding: 0 8px;
            }
            .ej-main-sub > span {
                color: white;
                font-size: 20px;
                line-height: 1.5;
                text-align: center;
                background: rgba(32, 26, 25, 0.8);
                // text-shadow: 0px 1px 4px black;
                padding: 2px 8px;

                lineheight: 1.2;
                font-size: 28px;
                color: #ffcc00;
                background: rgba(17, 17, 17, 0.7);
            }

            .ej-main-sub .glot-sub-clzz {
                background: transparent !important;
            }

            .tran-subtitle > span {
                cursor: pointer;
                padding-left: 10px;
                top: 2px;
                position: relative;
            }

            .tran-subtitle > span > span {
                position: absolute;
                top: -170%;
                background: rgba(0, 0, 0, 0.5);
                font-size: 13px;
                line-height: 20px;
                padding: 2px 8px;
                color: white;
                display: none;
                border-radius: 4px;
                white-space: nowrap;
                left: -50%;
                font-weight: normal;
            }

            .view-icon-copy-main-sub:hover > span,
            .view-icon-edit-sub:hover > span,
            .view-icon-copy-tran-sub:hover > span {
                display: block;
            }

            .tran-subtitle > span > svg {
                width: 16px;
                height: 16px;
                pointer-events: none;
                display: inline-flex !important;
                vertical-align: baseline !important;
            }

            .view-icon-copy-main-sub > svg {
                pointer-events: none;
                color: #ffcc00;
            }

            .view-icon-copy-tran-sub {
                padding-left: 0 !important;
                padding-right: 8px !important;
            }
            .view-icon-copy-tran-sub > svg {
                pointer-events: none;
                color: #0cb1c7;
            }
        </style>
        <style type="text/css" id="text_styles_paragraph_viewer" class="text_styles">
            .used-fonts-test p.paragraph-1,
            .rmwidget.text div p.paragraph-1 {
                font-family: Nobel;
                font-style: normal;
                font-weight: 700;
                font-size: 48px;
                letter-spacing: 0px;
                line-height: 60px;
                text-align: start;
                text-decoration: none;
                text-transform: none;
                color: rgb(34, 34, 34);
                padding-top: 0px;
                padding-right: 0px;
                padding-bottom: 0px;
                padding-left: 0px;
            }

            .used-fonts-test p.paragraph-2,
            .rmwidget.text div p.paragraph-2 {
                font-family: Georgia;
                font-style: normal;
                font-weight: 400;
                font-size: 24px;
                letter-spacing: 0px;
                line-height: 30px;
                text-align: start;
                text-decoration: none;
                text-transform: none;
                color: rgb(34, 34, 34);
                padding-top: 0px;
                padding-right: 0px;
                padding-bottom: 0px;
                padding-left: 0px;
            }

            .used-fonts-test p.paragraph-3,
            .rmwidget.text div p.paragraph-3 {
                font-family: Georgia;
                font-style: normal;
                font-weight: 400;
                font-size: 18px;
                letter-spacing: 0px;
                line-height: 23px;
                text-align: start;
                text-decoration: none;
                text-transform: none;
                color: rgb(34, 34, 34);
                padding-top: 0px;
                padding-right: 0px;
                padding-bottom: 0px;
                padding-left: 0px;
            }

            .used-fonts-test p.paragraph-4,
            .rmwidget.text div p.paragraph-4 {
                font-family: Georgia;
                font-style: italic;
                font-weight: 400;
                font-size: 14px;
                letter-spacing: 0px;
                line-height: 18px;
                text-align: start;
                text-decoration: none;
                text-transform: none;
                color: rgba(34, 34, 34, 0.5);
                padding-top: 0px;
                padding-right: 0px;
                padding-bottom: 0px;
                padding-left: 0px;
            }
        </style>
        <style type="text/css" id="text_styles_link_viewer" class="text_styles">
            .rmwidget.text div a.link-1 {
                text-decoration: none;
                color: rgb(17, 90, 127);
                background: none;
            }

            .rmwidget.text div a.hovered.link-1 {
                text-decoration: none;
                color: rgb(17, 90, 127);
                background: none;
            }

            .rmwidget.text div a.link-1 * {
                color: inherit !important;
                text-decoration: none !important;
            }

            .rmwidget.text div a.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 {
                text-decoration: none;
                color: rgb(0, 120, 255);
                padding-bottom: 1px;
                background: linear-gradient(to right, rgb(0, 120, 255) 0%, rgb(0, 120, 255) 100%);
                background-size: 1px 1px;
                background-position: 0 100%;
                background-repeat: repeat-x;
            }

            .rmwidget.text div a.current.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 {
                text-decoration: none;
                color: rgb(0, 120, 255);
                background: none;
            }

            .rmwidget.text div a.hovered.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 {
                text-decoration: none;
                color: rgb(0, 120, 255);
                background: none;
            }

            .rmwidget.text div a.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 * {
                color: inherit !important;
                text-decoration: none !important;
            }
        </style>
        <style type="text/css" class="typekit-kit fonts" data-id="0ae5726b-6bba-4231-a2c2-397462479175" data-provider="typekit" data-fonts-and-variations="flqd|n3||flqd|i3||flqd|n4||flqd|i4||flqd|n7||flqd|i7">
            @font-face {
                font-family: flqd;
                src: url(https://use.typekit.net/af/ea559d/00000000000000007735a08d/30/l?subset_id=1&fvd=n4&v=3) format("woff2"), url(https://use.typekit.net/af/ea559d/00000000000000007735a08d/30/d?subset_id=1&fvd=n4&v=3) format("woff"),
                    url(https://use.typekit.net/af/ea559d/00000000000000007735a08d/30/a?subset_id=1&fvd=n4&v=3) format("opentype");
                font-weight: 400;
                font-style: normal;
                font-display: auto;
            }
        </style>
        <link
            type="text/css"
            rel="stylesheet"
            href="//fonts.googleapis.com/css?family=Source+Sans+Pro:200,200italic,300,300italic,400,400italic,600,600italic,700,700italic,900,900italic%7CRoboto:100,100italic,300,300italic,400,400italic,500,500italic,700,700italic,900,900italic%7CInter:100,200,300,400,500,600,700,800,900&amp;subset=latin,vietnamese,khmer,cyrillic-ext,greek-ext,greek,devanagari,latin-ext,cyrillic"
            class="fonts"
            data-id="9084d0c9-161a-45c9-9e68-69e86936f933"
            data-provider="google"
            data-fonts-and-variations="Source Sans Pro|n2||Source Sans Pro|i2||Source Sans Pro|n3||Source Sans Pro|i3||Source Sans Pro|n4||Source Sans Pro|i4||Source Sans Pro|n6||Source Sans Pro|i6||Source Sans Pro|n7||Source Sans Pro|i7||Source Sans Pro|n9||Source Sans Pro|i9||Roboto|n1||Roboto|i1||Roboto|n3||Roboto|i3||Roboto|n4||Roboto|i4||Roboto|n5||Roboto|i5||Roboto|n7||Roboto|i7||Roboto|n9||Roboto|i9||Inter|n1||Inter|n2||Inter|n3||Inter|n4||Inter|n5||Inter|n6||Inter|n7||Inter|n8||Inter|n9"
        />
        <style type="text/css" id="individual_button_style_61df1a5e97a1140032bfe253_viewer" class="button_styles">
            .rmwidget.widget-button .common-button[data-id="61df1a5e97a1140032bfe253"] {
                background-color: rgb(240, 156, 73);
                border-radius: 5px;
                border-width: 0px;
                border-color: rgb(0, 0, 0);
                font-family: flqd;
                font-weight: 400;
                font-style: normal;
                color: rgb(255, 255, 255);
                font-size: 18px;
                letter-spacing: 0.1px;
            }

            .rmwidget.widget-button .common-button[data-id="61df1a5e97a1140032bfe253"].current {
                background-color: rgb(0, 120, 255);
                border-radius: 5px;
                border-width: 0px;
                border-color: rgb(0, 0, 0);
                font-family: Arial;
                font-weight: 400;
                font-style: normal;
                color: rgb(255, 255, 255);
                font-size: 18px;
                letter-spacing: 0px;
            }

            .rmwidget.widget-button .common-button[data-id="61df1a5e97a1140032bfe253"].hovered {
                background-color: rgb(115, 191, 215);
                border-radius: 5px;
                border-width: 0px;
                border-color: rgb(0, 0, 0);
                font-family: flqd;
                font-weight: 400;
                font-style: normal;
                color: rgb(255, 255, 255);
                font-size: 18px;
                letter-spacing: 0.1px;
            }
        </style>
        <style type="text/css" id="individual_button_style_61df1c634d7980003e0456c9_viewer" class="button_styles">
            .rmwidget.widget-button .common-button[data-id="61df1c634d7980003e0456c9"] {
                background-color: rgb(240, 156, 73);
                border-radius: 5px;
                border-width: 0px;
                border-color: rgb(0, 0, 0);
                font-family: flqd;
                font-weight: 400;
                font-style: normal;
                color: rgb(255, 255, 255);
                font-size: 18px;
                letter-spacing: 0.1px;
            }

            .rmwidget.widget-button .common-button[data-id="61df1c634d7980003e0456c9"].current {
                background-color: rgb(0, 120, 255);
                border-radius: 5px;
                border-width: 0px;
                border-color: rgb(0, 0, 0);
                font-family: Arial;
                font-weight: 400;
                font-style: normal;
                color: rgb(255, 255, 255);
                font-size: 18px;
                letter-spacing: 0px;
            }

            .rmwidget.widget-button .common-button[data-id="61df1c634d7980003e0456c9"].hovered {
                background-color: rgb(115, 191, 215);
                border-radius: 5px;
                border-width: 0px;
                border-color: rgb(0, 0, 0);
                font-family: flqd;
                font-weight: 400;
                font-style: normal;
                color: rgb(255, 255, 255);
                font-size: 18px;
                letter-spacing: 0.1px;
            }
        </style>
        <style type="text/css" id="individual_button_style_61df1c7538ae1b0037792d40_viewer" class="button_styles">
            .rmwidget.widget-button .common-button[data-id="61df1c7538ae1b0037792d40"] {
                background-color: rgb(240, 156, 73);
                border-radius: 5px;
                border-width: 0px;
                border-color: rgb(0, 0, 0);
                font-family: flqd;
                font-weight: 400;
                font-style: normal;
                color: rgb(255, 255, 255);
                font-size: 18px;
                letter-spacing: 0.1px;
            }

            .rmwidget.widget-button .common-button[data-id="61df1c7538ae1b0037792d40"].current {
                background-color: rgb(0, 120, 255);
                border-radius: 5px;
                border-width: 0px;
                border-color: rgb(0, 0, 0);
                font-family: Arial;
                font-weight: 400;
                font-style: normal;
                color: rgb(255, 255, 255);
                font-size: 18px;
                letter-spacing: 0px;
            }

            .rmwidget.widget-button .common-button[data-id="61df1c7538ae1b0037792d40"].hovered {
                background-color: rgb(115, 191, 215);
                border-radius: 5px;
                border-width: 0px;
                border-color: rgb(0, 0, 0);
                font-family: flqd;
                font-weight: 400;
                font-style: normal;
                color: rgb(255, 255, 255);
                font-size: 18px;
                letter-spacing: 0.1px;
            }
        </style>
        <style data-styled="active" data-styled-version="5.3.0"></style>
        <style type="text/css" id="individual_button_style_61df1a5e97a1140032bfe290_viewer" class="button_styles">
            .rmwidget.widget-button .common-button[data-id="61df1a5e97a1140032bfe290"] {
                background-color: rgb(240, 156, 73);
                border-radius: 7px;
                border-width: 0px;
                border-color: rgb(0, 0, 0);
                font-family: Roboto;
                font-weight: 400;
                font-style: normal;
                color: rgb(255, 255, 255);
                font-size: 18px;
                letter-spacing: 0px;
            }

            .rmwidget.widget-button .common-button[data-id="61df1a5e97a1140032bfe290"] .icon {
                background-image: url("https://d3n32ilufxuvd1.cloudfront.net/56969df1bd02a4a3292a2178/61df1a5e97a1140032bfe23d/upload-ec91a927-5bcd-489b-8f5c-c3816ecf0b1b.png");
            }

            .rmwidget.widget-button .common-button[data-id="61df1a5e97a1140032bfe290"].current {
                background-color: rgb(0, 120, 255);
                border-radius: 5px;
                border-width: 0px;
                border-color: rgb(0, 0, 0);
                font-family: Arial;
                font-weight: 400;
                font-style: normal;
                color: rgb(255, 255, 255);
                font-size: 18px;
                letter-spacing: 0px;
            }

            .rmwidget.widget-button .common-button[data-id="61df1a5e97a1140032bfe290"].current .icon {
                background-image: url("https://rm-content.s3.amazonaws.com/56969df1bd02a4a3292a2178/1215691/upload-57c95040-e439-11e8-854a-65e6af600376.png");
            }

            .maglink.current .widget-button .common-button[data-id="61df1a5e97a1140032bfe290"] .icon {
                background-image: url("https://rm-content.s3.amazonaws.com/56969df1bd02a4a3292a2178/1215691/upload-57c95040-e439-11e8-854a-65e6af600376.png");
            }

            .rmwidget.widget-button .common-button[data-id="61df1a5e97a1140032bfe290"].hovered {
                background-color: rgb(115, 191, 215);
                border-radius: 7px;
                border-width: 0px;
                border-color: rgb(255, 255, 255);
                font-family: Roboto;
                font-weight: 400;
                font-style: normal;
                color: rgb(255, 255, 255);
                font-size: 18px;
                letter-spacing: 0px;
            }

            .rmwidget.widget-button .common-button[data-id="61df1a5e97a1140032bfe290"].hovered .icon {
                background-image: url("data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjIiIGJhc2VQcm9maWxlPSJ0aW55IiBpZD0iTGF5ZXJfMSIgeD0iMHB4IiB5PSIwcHgiIHZpZXdCb3g9IjAuMjAwMDAwMjg2MTAyMjk0OTIgMC4wOTk5OTc1MjA0NDY3NzczNCAxMjcuNjAwMDA2MTAzNTE1NjIgMTI3LjcwMDAwNDU3NzYzNjcyIiB4bWw6c3BhY2U9InByZXNlcnZlIiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiBzdHlsZT0id2lkdGg6IDEwMCU7IGhlaWdodDogMTAwJTsiIGZpbGw9InJnYigyNTUsMjU1LDI1NSkiIGZpbGwtb3BhY2l0eT0iMSI+CjxwYXRoIGQ9Ik0xMjcuOCwxMjEuNHYtMy4yYzAtNC43LTEuNC02LjQtNi43LTYuNEg2LjljLTUsMC02LjcsMS42LTYuNyw2LjR2My4yYzAsNSwxLjcsNi40LDYuNyw2LjRoMTE0LjIgIEMxMjYuMiwxMjcuOCwxMjcuOCwxMjYuMiwxMjcuOCwxMjEuNHogTTc1LjgsMC4xSDUyYy03LjgsMC05LjQsMS41LTkuNCw5LjN2MzMuM0gxMC45TDY0LDk1LjhsNTMuMS01My4ySDg1LjJWOS40ICBDODUuMiwxLjYsODMuNSwwLjEsNzUuOCwwLjF6Ii8+Cjwvc3ZnPg==");
            }
        </style>

        <style type="text/css" id="individual_button_style_5f185bc80fa4dd007863a9eb_viewer" class="button_styles">
            	.rmwidget.widget-button .common-button[data-id="5f185bc80fa4dd007863a9eb"] {
            		background-color: rgb(67, 120, 189);
            		border-radius: 5px;
            		border-width: 0px;
            		border-color: rgb(0, 0, 0);
            		font-family: flqd;
            		font-weight: 400;
            		font-style: normal;
            		color: rgb(255, 255, 255);
            		font-size: 12.8px;
            		letter-spacing: 0.1px;
            	}

            	.rmwidget.widget-button .common-button[data-id="5f185bc80fa4dd007863a9eb"].current {
            		background-color: rgb(0, 120, 255);
            		border-radius: 5px;
            		border-width: 0px;
            		border-color: rgb(0, 0, 0);
            		font-family: Arial;
            		font-weight: 400;
            		font-style: normal;
            		color: rgb(255, 255, 255);
            		font-size: 18px;
            		letter-spacing: 0px;
            	}

            	.maglink.current .widget-button .common-button[data-id="5f185bc80fa4dd007863a9eb"] {
            		background-color: rgb(0, 120, 255);
            		border-radius: 5px;
            		border-width: 0px;
            		border-color: rgb(0, 0, 0);
            		font-family: Arial;
            		font-weight: 400;
            		font-style: normal;
            		color: rgb(255, 255, 255);
            		font-size: 18px;
            		letter-spacing: 0px;
            	}

            	.rmwidget.widget-button .common-button[data-id="5f185bc80fa4dd007863a9eb"]:hover {
            		background-color: rgb(171, 208, 55);
            		border-radius: 5px;
            		border-width: 0px;
            		border-color: rgb(0, 0, 0);
            		font-family: flqd;
            		font-weight: 400;
            		font-style: normal;
            		color: rgb(255, 255, 255);
            		font-size: 18px;
            		letter-spacing: 0.1px;
            	}
            	/* Fade-in Effect Css Start Here */

            	@-webkit-keyframes fadeIn {
            		from {
            			opacity: 0;
            			opacity: 1\9;
            			* IE9 only *
            		}
            		to {
            			opacity: 1;
            		}
            	}

            	@-moz-keyframes fadeIn {
            		from {
            			opacity: 0;
            			opacity: 1\9;
            			* IE9 only *
            		}
            		to {
            			opacity: 1;
            		}
            	}

            	@keyframes fadeIn {
            		from {
            			opacity: 0;
            			opacity: 1\9;
            			* IE9 only *
            		}
            		to {
            			opacity: 1;
            		}
            	}

            	.fade-in {
            		opacity: 0;
            		/* make things invisible upon start */
            		-webkit-animation: fadeIn ease-in 1;
            		/* call our keyframe named fadeIn, use animattion ease-in and repeat it only 1 time */
            		-moz-animation: fadeIn ease-in 1;
            		animation: fadeIn ease-in 1;
            		-webkit-animation-fill-mode: forwards;
            		/* this makes sure that after animation is done we remain at the last keyframe value (opacity: 1)*/
            		-moz-animation-fill-mode: forwards;
            		animation-fill-mode: forwards;
            		-webkit-animation-duration: 1s;
            		-moz-animation-duration: 1s;
            		animation-duration: 1s;
            	}

            	.fade-in.one {
            		-webkit-animation-delay: 1.5s;
            		-moz-animation-delay: 1.5s;
            		animation-delay: 1.5s;
            	}

            	.fade-in.two {
            		-webkit-animation-delay: 2s;
            		-moz-animation-delay: 2s;
            		animation-delay: 2s;
            	}

            	.fade-in.three {
            		-webkit-animation-delay: 3s;
            		-moz-animation-delay: 3s;
            		animation-delay: 3s;
            	}

            	.fade-in.four {
            		-webkit-animation-delay: 3.5s;
            		-moz-animation-delay: 3.5s;
            		animation-delay: 3.5s;
            	}

            	.fade-in.five {
            		-webkit-animation-delay: 4.5s;
            		-moz-animation-delay: 4.5s;
            		animation-delay: 4.5s;
            	}

            	.fade-in.six {
            		-webkit-animation-delay: 5.5s;
            		-moz-animation-delay: 5.5s;
            		animation-delay: 5.5s;
            	}

            	.fade-in.seven {
            		-webkit-animation-delay: 5.5s;
            		-moz-animation-delay: 5.5s;
            		animation-delay: 5.5s;
            	}


            	.fade-in.eight {
            		-webkit-animation-delay: 5.5s;
            		-moz-animation-delay: 5.5s;
            		animation-delay: 5.5s;
            	}

            	/* Fade-in Css End Here */
            	@keyframes slideInUp {

              from {

                -webkit-transform: translate3d(0, 100%, 0);

                transform: translate3d(0, 100%, 0);

                visibility: visible;

              }



              to {

                -webkit-transform: translate3d(0, 0, 0);

                transform: translate3d(0, 0, 0);

              }

            }



            .slideInUp {





              webkit-animation-name: slideInUp;

              animation-name: slideInUp;

              animation-delay: 4.5s;

              animation-duration: 4s;

              animation-fill-mode: both;



            }

            #scollbar::-webkit-scrollbar {
              display: none;
               -ms-overflow-style: none;  /* IE and Edge */
              scrollbar-width: none;  /* Firefox */
            }
        </style>

        <style>
            /* Extra small devices (phones, 600px and down) */
            @media only screen and (max-width: 600px) {
                .page-content-container {
                    width: 1024px;
                    height: 706px;
                    top: 0;
                    left: 0;
                }
            }

            /* Small devices (portrait tablets and large phones, 600px and up) */
            @media only screen and (min-width: 600px) {
                .page-content-container {
                    width: 1024px;
                    height: 706px;
                    top: 0;
                    left: 0;
                }
            }

            /* Medium devices (landscape tablets, 768px and up) */
            @media only screen and (max-width: 768px) {
                .page-content-container {
                    width: 1024px;
                    height: 706px;
                    top: 0px;
                    left: 0 !important;
                }
            }

            /* Large devices (laptops/desktops, 992px and up) */
            @media only screen and (max-width: 1024px) {
                .page-content-container {
                    width: 1024px;
                    height: 706px;
                    top: 0px;
                    left: 0 !important;
                }
            }

            /* Extra large devices (large laptops and desktops, 1200px and up) */
            @media only screen and (max-width: 1200px) {
				  .page-content-container{
					  
                width: 1024px;
                height: 706px;
                top: 0px;
                left: 0;
            }
			}

					#scollbar::-webkit-scrollbar {
  display: none;
   -ms-overflow-style: none;  /* IE and Edge */
  scrollbar-width: none;  /* Firefox */
}
#scollbar::-webkit-scrollbar {
  display: none;
   -ms-overflow-style: none;  /* IE and Edge */
  scrollbar-width: none;  /* Firefox */
}
        </style>
    </head>
    <body data-new-gr-c-s-check-loaded="14.1043.0" data-gr-ext-installed="" cz-shortcut-listen="true">
        <div id="root"></div>
        <div id="mags">
            <div class="mag viewer-type-horizontal pages-pos-overlap" style="overflow-y: visible; scrollbar-width: none; -ms-overflow-style: none; background: #3e76d3;" id="scollbar">
                <div>
                    <div class="container">
                        <div class="blackout"></div>
                        <div class="page center-page neighbour">
                            <div id="page-1-password-container" class="polyfill-sticky"></div>
                            <div class="page-fixed-bg-container polyfill-sticky"><div class="rmwidget widget-background" style="background-color: #3e76d3;"></div></div>
                            <div class="fixed-position-container-top polyfill-sticky"></div>
                            <div class="fixed-position-container polyfill-sticky"></div>
                            <div class="content-scroll-wrapper has-vertical-scroll">
                                <div class="content-bounds" style="width: 100%; height: auto; position: absolute;">
                                    <div class="page-content-container" tabindex="-1" style="width: 1024px; height: auto; top: 0px; margin: 0 auto; position: relative;">
                                        <div class="page center-page neighbour">
                                            <div id="page-2-password-container" class="polyfill-sticky"></div>
                                            <div class="page-fixed-bg-container polyfill-sticky"><div class="rmwidget widget-background" style="background-color: #3e76d3;"></div></div>
                                            <div class="fixed-position-container-top polyfill-sticky"></div>
                                            <div class="fixed-position-container polyfill-sticky"></div>
                                            <div class="content-scroll-wrapper has-vertical-scroll accelerated-scroll">
                                                <div class="content-bounds" style="width: 1440px; height: 720px;">
                                                    <div class="page-content-container" tabindex="-1" style="width: 1024px; height: 720px; top: 0px; left: 297px;">
                                                        <div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 446.5px; top: 627px; width: 132px; height: 57px; z-index: 318;">
                                                            <style>
                                                                @keyframes animation_20_1 {
                                                                    0%,
                                                                    32.43243243243243% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 0;
                                                                        animation-timing-function: ease-out;
                                                                    }
                                                                    100% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 1;
                                                                    }
                                                                }
                                                            </style>
                                                            <a class="maglink" href="https://engage.biz-tech-insights.com/LP-FY23-Q4-Salesforce-Core-Service-AI-LE-2/form1.php?t=<?php echo $_GET['t']; ?>" target="_self">
                                                                <div
                                                                    class="rmwidget widget-button fade-in seven"
                                                                    data-id="61df1a5e97a1140032bfe290"
                                                                    style="left: 0px; top: 61px; width: 132px; height: 57px; z-index: 318; border-radius: 7px;"
                                                                >
                                                                    <div class="common-button transition" data-id="61df1a5e97a1140032bfe290" style="flex-direction: row;">
                                                                        <div class="icon" style="display: inline-block; width: 29px; height: 30px; margin-right: 0px; margin-left: 0px;"></div>

                                                                        <div class="text" style="display: none; width: 16px; padding-left: 0px; text-indent: 0px; height: 57px; line-height: 57px;"></div>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                        <div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 17px; top: 469px; width: 160px; height: 220px; z-index: 321;">
                                                            <style>
                                                                @keyframes animation_21_1 {
                                                                    0%,
                                                                    52.63157894736842% {
                                                                        transform: matrix(0.36, 0, 0, 0.36, 0, 0);
                                                                        opacity: 0;
                                                                        animation-timing-function: ease-out;
                                                                    }
                                                                    100% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 1;
                                                                    }
                                                                }
                                                            </style>
                                                            <div class="rmwidget widget-picture fade-in seven" data-id="61df1a5e97a1140032bfe291" style="left: 0px; top: 50px; width: 180px; height: 172px; z-index: 321;">
                                                                <div
                                                                    class="bgpic"
                                                                    url="https://engage.biz-tech-insights.com/LP-FY23-Q4-Salesforce-Core-Service-AI-LE-2/omdia-ai-automation-report.png"
                                                                    style="
                                                                        background-image: url('https://engage.biz-tech-insights.com/LP-FY23-Q4-Salesforce-Core-Service-AI-LE-2/omdia-ai-automation-report.png?w=320&amp;e=webp&amp;nll=true');
                                                                        background-position: 50% 50%;
                                                                        box-shadow: rgb(179, 181, 181) 0px 0px 0px 1px inset;
                                                                        border-radius: 0px;
                                                                        opacity: 1;
                                                                    "
                                                                ></div>
                                                                <img
                                                                    srcset="
                                                                        https://engage.biz-tech-insights.com/LP-FY23-Q4-Salesforce-Core-Service-AI-LE-2/1-How-to-Bring-CPQ-Into-Your-Business.PNG?w=320&amp;e=webp&amp;nll=true 2x,
                                                                        https://engage.biz-tech-insights.com/LP-FY23-Q4-Salesforce-Core-Service-AI-LE-2/1-How-to-Bring-CPQ-Into-Your-Business.PNG?w=480&amp;e=webp&amp;nll=true 3x
                                                                    "
                                                                    src="https://engage.biz-tech-insights.com/LP-FY23-Q4-Salesforce-Core-Service-AI-LE-2/1-How-to-Bring-CPQ-Into-Your-Business.PNG"
                                                                    class="viewable saveable"
                                                                    style="opacity: 1;"
                                                                />
                                                            </div>
                                                        </div>
                                                        <div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 270px; top: 558px; width: 519px; height: 53px; z-index: 319;">
                                                            <style>
                                                                @keyframes animation_22_1 {
                                                                    0%,
                                                                    75.3846153846154% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 0;
                                                                        animation-timing-function: ease-out;
                                                                    }
                                                                    100% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 1;
                                                                    }
                                                                }
                                                            </style>
                                                            <div class="rmwidget widget-text-v3 fade-in seven" data-id="61df1a5e97a1140032bfe29f" style="left: 0px; top: -25px; width: 519px; height: 53px; z-index: 319;">
                                                                <div class="Box-sc-n41d2v-0 TextBase___StyledBox-sc-1o28pgm-0 jXOqqG kKESck">
                                                                    <div class="text-viewer">
                                                                        <p style="line-height: 28px;" class="view-mode unstyled align-center">
                                                                            <span
                                                                                style="
                                                                                    font-size: 21px;
                                                                                    font-weight: 700;
                                                                                    font-family: Roboto;
                                                                                    font-style: normal;
                                                                                    letter-spacing: 0.4px;
                                                                                    text-decoration: none;
                                                                                    text-transform: none;
                                                                                    color: rgba(255, 255, 255, 1);
                                                                                "
                                                                            >
                                                                                Download the Omdia report, &#8220;AI and Automation: The Intersection of Agent Productivity and CX Acceleration,&#8221; to learn more about connecting systems
                                                                                and employees beyond the boundaries of the contact center.
                                                                            </span>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 15px; top: 9px; width: 1257px; height: 51px; z-index: 320;">
                                                            <style>
                                                                @keyframes animation_23_1 {
                                                                    0%,
                                                                    55.55555555555556% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 0;
                                                                        animation-timing-function: ease-out;
                                                                    }
                                                                    100% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 1;
                                                                    }
                                                                }
                                                            </style>
                                                            <div class="rmwidget widget-text-v3 fade-in seven" data-id="61df1a5e97a1140032bfe2a0" style="left: 0px; top: 0px; width: 1257px; height: 51px; z-index: 320;">
                                                                <div class="Box-sc-n41d2v-0 TextBase___StyledBox-sc-1o28pgm-0 jXOqqG kKESck">
                                                                    <div class="text-viewer">
                                                                        <p style="line-height: 36px;" class="view-mode unstyled align-left">
                                                                            <span
                                                                                style="font-weight: 300; font-family: Roboto; font-style: normal; text-decoration: none; text-transform: none; font-size: 30px; color: rgba(255, 255, 255, 1);"
                                                                            >
                                                                                Embed AI-Powered Workflows
                                                                            </span>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, -286); opacity: 1; left: 907px; top: 181px; width: 55px; height: 114px; z-index: 323;">
                                                            <style>
                                                                @keyframes animation_24_1 {
                                                                    0%,
                                                                    61.25000000000001% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 1;
                                                                        animation-timing-function: linear;
                                                                    }
                                                                    100% {
                                                                        transform: matrix(1, 0, 0, 1, 0, -286);
                                                                        opacity: 1;
                                                                    }
                                                                }
                                                            </style>
                                                            <div
                                                                class="rmwidget widget-shape div-instead-of-svg slideInUp"
                                                                data-id="61df1a5e97a1140032bfe2b0"
                                                                style="
                                                                    left: 0px;
                                                                    top: 27px;
                                                                    width: 55px;
                                                                    height: 225px;
                                                                    z-index: 323;
                                                                    background-color: #3e76d3;
                                                                    border-color: rgb(255, 255, 255);
                                                                    border-radius: 0px;
                                                                    border-style: solid;
                                                                    border-width: 0px;
                                                                    box-sizing: border-box;
                                                                "
                                                            ></div>
                                                        </div>

                                                        <div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 893px; top: 333px; width: 118px; height: 74px; z-index: 324;">
                                                            <style>
                                                                @keyframes animation_25_1 {
                                                                    0%,
                                                                    76% {
                                                                        transform: matrix(3.02, 0, 0, 3.02, 0, 0);
                                                                        opacity: 0;
                                                                        animation-timing-function: ease-out;
                                                                    }
                                                                    100% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 1;
                                                                    }
                                                                }
                                                            </style>
                                                            <div class="rmwidget widget-text-v3 fade-in seven" data-id="61df1a5e97a1140032bfe2b1" style="left: 0px; top: 0px; width: 118px; height: 74px; z-index: 324;">
                                                                <div class="Box-sc-n41d2v-0 TextBase___StyledBox-sc-1o28pgm-0 jXOqqG kKESck">
                                                                    <div class="text-viewer">
                                                                        <!-- <p style="line-height:58px" class="view-mode unstyled align-left"> -->
                                                                        <!-- <span style="font-size: 46px;font-weight:900;font-family:Roboto;font-style:normal;text-decoration:none;text-transform:none;color:rgba(255, 255, 255, 1);">80%</span></p> -->
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 885px; top: 389px; width: 139px; height: 197px; z-index: 325;">
                                                            <style>
                                                                @keyframes animation_26_1 {
                                                                    0%,
                                                                    61.904761904761905% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 0;
                                                                        animation-timing-function: ease-out;
                                                                    }
                                                                    100% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 1;
                                                                    }
                                                                }
                                                            </style>
                                                            <div class="rmwidget widget-text-v3 fade-in seven" data-id="61df1a5e97a1140032bfe2b2" style="left: 0px; top: 0px; width: 139px; height: 197px; z-index: 325;">
                                                                <div class="Box-sc-n41d2v-0 TextBase___StyledBox-sc-1o28pgm-0 jXOqqG kKESck">
                                                                    <div class="text-viewer">
                                                                        <p style="line-height: 15px; padding-right: 8px; padding-top: 7px; padding-bottom: 8px;" class="view-mode unstyled">
                                                                            <span
                                                                                style="
                                                                                    text-transform: none;
                                                                                    font-size: 14px;
                                                                                    font-family: Roboto;
                                                                                    color: rgba(232, 249, 248, 1);
                                                                                    letter-spacing: -0.2px;
                                                                                    font-style: normal;
                                                                                    font-weight: 400;
                                                                                    text-decoration: none;
                                                                                "
                                                                            >
                                                                                72% view intelligent automation and AI as &#8220;significantly more important&#8221; or &#8220;more important&#8221; following the pandemic.
                                                                            </span>
                                                                        </p>
                                                                        <p style="line-height: 12px; padding-right: 9px; padding-bottom: 8px;" class="view-mode unstyled">
                                                                            <span
                                                                                style="font-family: Roboto; text-decoration: none; text-transform: none; font-style: normal; font-weight: 400; font-size: 10px; color: rgba(232, 249, 248, 1);"
                                                                            >
                                                                                Source: Omdia IT Enterprise Insights 2022
                                                                            </span>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 292px; top: -5px; width: 528px; height: 621px; z-index: 302;">
                                                            <style>
                                                                @keyframes animation_27_1 {
                                                                    0%,
                                                                    77.77777777777779% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 0;
                                                                        animation-timing-function: ease-out;
                                                                    }
                                                                    100% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 1;
                                                                    }
                                                                }
                                                            </style>
                                                            <div class="rmwidget widget-picture fade-in seven" data-id="61df2549a52a7f001beab48c" style="left: 0px; top: 0px; width: 528px; height: 621px; z-index: 302;">
                                                                <img
                                                                    srcset="
                                                                        https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-07ffd7e4-9ffa-4e17-bd18-541a6184c94a.png?w=1056&amp;e=webp&amp;nll=true&amp;cX=970&amp;cY=0&amp;cW=2110&amp;cH=2482 2x,
                                                                        https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-07ffd7e4-9ffa-4e17-bd18-541a6184c94a.png?w=1584&amp;e=webp&amp;nll=true&amp;cX=970&amp;cY=0&amp;cW=2110&amp;cH=2482 3x
                                                                    "
                                                                    src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-07ffd7e4-9ffa-4e17-bd18-541a6184c94a.png?w=1056&amp;e=webp&amp;nll=true&amp;cX=970&amp;cY=0&amp;cW=2110&amp;cH=2482"
                                                                    class="viewable"
                                                                    style="opacity: 1;"
                                                                />
                                                            </div>
                                                        </div>
                                                        <div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 425px; top: 286px; width: 92px; height: 88px; z-index: 326;">
                                                            <style>
                                                                @keyframes animation_28_1 {
                                                                    0%,
                                                                    61.904761904761905% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 0;
                                                                        animation-timing-function: ease-out;
                                                                    }
                                                                    100% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 1;
                                                                    }
                                                                }
                                                            </style>
                                                            <div class="rmwidget widget-picture fade-in four" data-id="61df254a1e3842003dffdfa3" style="left: 0px; top: 0px; width: 92px; height: 88px; z-index: 326;">
                                                                <img
                                                                    srcset="
                                                                        https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-d74d0654-ae3a-4a99-b4e5-932ff77c8beb.png?w=184&amp;e=webp&amp;nll=true 2x,
                                                                        https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-d74d0654-ae3a-4a99-b4e5-932ff77c8beb.png?e=webp&amp;nll=true           3x
                                                                    "
                                                                    src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-d74d0654-ae3a-4a99-b4e5-932ff77c8beb.png?w=184&amp;e=webp&amp;nll=true"
                                                                    class="viewable"
                                                                    style="opacity: 1;"
                                                                />
                                                            </div>
                                                        </div>
                                                        <div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 513px; top: 286px; width: 92px; height: 88px; z-index: 327;">
                                                            <style>
                                                                @keyframes animation_29_1 {
                                                                    0%,
                                                                    55.55555555555556% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 0;
                                                                        animation-timing-function: ease-out;
                                                                    }
                                                                    100% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 1;
                                                                    }
                                                                }
                                                            </style>
                                                            <div class="rmwidget widget-picture fade-in three" data-id="61df254a23575200365707bf" style="left: 0px; top: 0px; width: 92px; height: 88px; z-index: 327;">
                                                                <img
                                                                    srcset="
                                                                        https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-d74d0654-ae3a-4a99-b4e5-932ff77c8beb.png?w=184&amp;e=webp&amp;nll=true 2x,
                                                                        https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-d74d0654-ae3a-4a99-b4e5-932ff77c8beb.png?e=webp&amp;nll=true           3x
                                                                    "
                                                                    src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-d74d0654-ae3a-4a99-b4e5-932ff77c8beb.png?w=184&amp;e=webp&amp;nll=true"
                                                                    class="viewable"
                                                                    style="opacity: 1;"
                                                                />
                                                            </div>
                                                        </div>
                                                        <div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 598px; top: 287px; width: 92px; height: 88px; z-index: 328;">
                                                            <style>
                                                                @keyframes animation_30_1 {
                                                                    0%,
                                                                    50% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 0;
                                                                        animation-timing-function: ease-out;
                                                                    }
                                                                    100% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 1;
                                                                    }
                                                                }
                                                            </style>
                                                            <div class="rmwidget widget-picture fade-in two" data-id="61df254a1f74620013a54e4d" style="left: 0px; top: 0px; width: 92px; height: 88px; z-index: 328;">
                                                                <img
                                                                    srcset="
                                                                        https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-d74d0654-ae3a-4a99-b4e5-932ff77c8beb.png?w=184&amp;e=webp&amp;nll=true 2x,
                                                                        https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-d74d0654-ae3a-4a99-b4e5-932ff77c8beb.png?e=webp&amp;nll=true           3x
                                                                    "
                                                                    src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-d74d0654-ae3a-4a99-b4e5-932ff77c8beb.png?w=184&amp;e=webp&amp;nll=true"
                                                                    class="viewable"
                                                                    style="opacity: 1;"
                                                                />
                                                            </div>
                                                        </div>
                                                        <div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 688px; top: 285px; width: 92px; height: 88px; z-index: 329;">
                                                            <style>
                                                                @keyframes animation_31_1 {
                                                                    0%,
                                                                    38.46153846153846% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 0;
                                                                        animation-timing-function: ease-out;
                                                                    }
                                                                    100% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 1;
                                                                    }
                                                                }
                                                            </style>
                                                            <div class="rmwidget widget-picture fade-in one" data-id="61df254b1e3842003dffdfa8" style="left: 0px; top: 0px; width: 92px; height: 88px; z-index: 329;">
                                                                <img
                                                                    srcset="
                                                                        https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-d74d0654-ae3a-4a99-b4e5-932ff77c8beb.png?w=184&amp;e=webp&amp;nll=true 2x,
                                                                        https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-d74d0654-ae3a-4a99-b4e5-932ff77c8beb.png?e=webp&amp;nll=true           3x
                                                                    "
                                                                    src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-d74d0654-ae3a-4a99-b4e5-932ff77c8beb.png?w=184&amp;e=webp&amp;nll=true"
                                                                    class="viewable"
                                                                    style="opacity: 1;"
                                                                />
                                                            </div>
                                                        </div>
                                                        <div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 382px; top: 140px; width: 481px; height: 389px; z-index: 338;">
                                                            <style>
                                                                @keyframes animation_32_1 {
                                                                    0%,
                                                                    75.43859649122807% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 0;
                                                                        animation-timing-function: ease-out;
                                                                    }
                                                                    100% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 1;
                                                                    }
                                                                }
                                                            </style>
                                                            <div class="rmwidget widget-picture fade-in seven" data-id="61df254ca52a7f001beab4c0" style="left: 73px; top: 0px; width: 115px; height: 147px; z-index: 332;">
                                                                <img
                                                                    srcset="
                                                                        https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-dcd2c57f-87ed-40cf-bacf-d69b024bc895.png?w=230&amp;e=webp&amp;nll=true 2x,
                                                                        https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-dcd2c57f-87ed-40cf-bacf-d69b024bc895.png?e=webp&amp;nll=true           3x
                                                                    "
                                                                    src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-dcd2c57f-87ed-40cf-bacf-d69b024bc895.png?w=230&amp;e=webp&amp;nll=true"
                                                                    class="viewable"
                                                                    style="opacity: 1;"
                                                                />
                                                            </div>
                                                            <div class="rmwidget widget-picture fade-in eight" data-id="61df254d1b8a1c00200e05a4" style="left: 0px; top: 118px; width: 94px; height: 97px; z-index: 338;">
                                                                <img
                                                                    src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-1096ce6c-e133-4890-866c-ad684f37ca73.png?e=webp&amp;nll=true"
                                                                    class="viewable"
                                                                    style="opacity: 1;"
                                                                />
                                                            </div>
                                                            <div class="rmwidget widget-picture fade-in seven" data-id="61df254cdb0b54002567f98b" style="left: 377px; top: 134px; width: 104px; height: 133px; z-index: 333;">
                                                                <img
                                                                    srcset="
                                                                        https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-031f354d-0f9f-44e1-8c55-53119a946bff.png?w=208&amp;e=webp&amp;nll=true 2x,
                                                                        https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-031f354d-0f9f-44e1-8c55-53119a946bff.png?e=webp&amp;nll=true           3x
                                                                    "
                                                                    src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-031f354d-0f9f-44e1-8c55-53119a946bff.png?w=208&amp;e=webp&amp;nll=true"
                                                                    class="viewable"
                                                                    style="opacity: 1;"
                                                                />
                                                            </div>
                                                            <div class="rmwidget widget-picture fade-in seven" data-id="61df254b23575200365707ce" style="left: 29px; top: 243px; width: 109px; height: 146px; z-index: 331;">
                                                                <img
                                                                    srcset="
                                                                        https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-e43f7376-4513-45f0-b2ef-4c5243a19865.png?w=218&amp;e=webp&amp;nll=true 2x,
                                                                        https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-e43f7376-4513-45f0-b2ef-4c5243a19865.png?e=webp&amp;nll=true           3x
                                                                    "
                                                                    src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-e43f7376-4513-45f0-b2ef-4c5243a19865.png?w=218&amp;e=webp&amp;nll=true"
                                                                    class="viewable"
                                                                    style="opacity: 1;"
                                                                />
                                                            </div>
                                                            <div class="rmwidget widget-picture fade-in seven" data-id="61df254b4d7980003e04c275" style="left: 153px; top: 279px; width: 81px; height: 84px; z-index: 330;">
                                                                <img
                                                                    srcset="
                                                                        https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-725fff62-9d25-4be6-af50-2090343aafa8.png?w=162&amp;e=webp&amp;nll=true 2x,
                                                                        https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-725fff62-9d25-4be6-af50-2090343aafa8.png?e=webp&amp;nll=true           3x
                                                                    "
                                                                    src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-725fff62-9d25-4be6-af50-2090343aafa8.png?w=162&amp;e=webp&amp;nll=true"
                                                                    class="viewable"
                                                                    style="opacity: 1;"
                                                                />
                                                            </div>
                                                        </div>
                                                        <div
                                                            class="animation-container"
                                                            style="
                                                                transform: matrix(1, 0, 0, 1, 0, 0);
                                                                opacity: 0;
                                                                left: 670px;
                                                                top: 133px;
                                                                width: 145px;
                                                                height: 122px;
                                                                z-index: 334;
                                                                animation-name: animation_33_1, animation_33_2;
                                                                animation-duration: 2.8s, 2.7s;
                                                                animation-delay: 0s, 2.8s;
                                                                animation-iteration-count: 1, infinite;
                                                                animation-direction: alternate, alternate;
                                                                animation-fill-mode: none, none;
                                                            "
                                                        >
                                                            <style>
                                                                @keyframes animation_33_1 {
                                                                    0%,
                                                                    57.14285714285715% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 0;
                                                                        animation-timing-function: ease-out;
                                                                    }
                                                                    100% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 1;
                                                                    }
                                                                }
                                                                @keyframes animation_33_2 {
                                                                    0% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 1;
                                                                        animation-timing-function: linear;
                                                                    }
                                                                    100% {
                                                                        transform: matrix(0.68, 0, 0, 0.68, 0, 0);
                                                                        opacity: 1;
                                                                    }
                                                                }
                                                            </style>
                                                            <div class="rmwidget widget-picture" data-id="61df254d8853d60031217e0e" style="left: 0px; top: 0px; width: 145px; height: 122px; z-index: 334;">
                                                                <img
                                                                    srcset="
                                                                        https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-441a29ec-9495-4865-8854-061675e67b9b.png?w=197&amp;e=webp&amp;nll=true 2x,
                                                                        https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-441a29ec-9495-4865-8854-061675e67b9b.png?e=webp&amp;nll=true           3x
                                                                    "
                                                                    src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-441a29ec-9495-4865-8854-061675e67b9b.png?w=197&amp;e=webp&amp;nll=true"
                                                                    class="viewable"
                                                                    style="opacity: 1;"
                                                                />
                                                            </div>
                                                        </div>
                                                        <div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 477px; top: 380px; width: 79px; height: 62px; z-index: 335;">
                                                            <style>
                                                                @keyframes animation_34_1 {
                                                                    0%,
                                                                    76.25% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 0;
                                                                        animation-timing-function: ease-out;
                                                                    }
                                                                    100% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 1;
                                                                    }
                                                                }
                                                            </style>
                                                            <div class="rmwidget widget-picture fade-in six" data-id="61df254d1f74620013a54e63" style="left: 0px; top: 0px; width: 79px; height: 62px; z-index: 335;">
                                                                <img
                                                                    srcset="
                                                                        https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-c007276b-05f8-46d8-b687-14f796b0736d.png?w=158&amp;e=webp&amp;nll=true&amp;cX=197&amp;cY=186&amp;cW=179&amp;cH=140 2x,
                                                                        https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-c007276b-05f8-46d8-b687-14f796b0736d.png?w=237&amp;e=webp&amp;nll=true&amp;cX=197&amp;cY=186&amp;cW=179&amp;cH=140 3x
                                                                    "
                                                                    src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-c007276b-05f8-46d8-b687-14f796b0736d.png?w=158&amp;e=webp&amp;nll=true&amp;cX=197&amp;cY=186&amp;cW=179&amp;cH=140"
                                                                    class="viewable"
                                                                    style="opacity: 1;"
                                                                />
                                                            </div>
                                                        </div>
                                                        <div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 340px; top: 285px; width: 92px; height: 88px; z-index: 336;">
                                                            <style>
                                                                @keyframes animation_35_1 {
                                                                    0%,
                                                                    66.66666666666666% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 0;
                                                                        animation-timing-function: ease-out;
                                                                    }
                                                                    100% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 1;
                                                                    }
                                                                }
                                                            </style>
                                                            <div class="rmwidget widget-picture fade-in five" data-id="61df254ddb0b54002567f98e" style="left: 0px; top: 0px; width: 92px; height: 88px; z-index: 336;">
                                                                <img
                                                                    srcset="
                                                                        https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-d74d0654-ae3a-4a99-b4e5-932ff77c8beb.png?w=184&amp;e=webp&amp;nll=true 2x,
                                                                        https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-d74d0654-ae3a-4a99-b4e5-932ff77c8beb.png?e=webp&amp;nll=true           3x
                                                                    "
                                                                    src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-d74d0654-ae3a-4a99-b4e5-932ff77c8beb.png?w=184&amp;e=webp&amp;nll=true"
                                                                    class="viewable"
                                                                    style="opacity: 1;"
                                                                />
                                                            </div>
                                                        </div>
                                                        <div
                                                            class="animation-container"
                                                            style="
                                                                transform: matrix(1, 0, 0, 1, 0, 0);
                                                                opacity: 0;
                                                                left: 261px;
                                                                top: 112px;
                                                                width: 108px;
                                                                height: 111px;
                                                                z-index: 337;
                                                                animation-name: animation_36_1, animation_36_2;
                                                                animation-duration: 3.8s, 1.2s;
                                                                animation-delay: 0s, 3.8s;
                                                                animation-iteration-count: 1, infinite;
                                                                animation-direction: alternate, alternate;
                                                                animation-fill-mode: none, none;
                                                            "
                                                        >
                                                            <style>
                                                                @keyframes animation_36_1 {
                                                                    0%,
                                                                    57.89473684210527% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 0;
                                                                        animation-timing-function: ease-out;
                                                                    }
                                                                    100% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 1;
                                                                    }
                                                                }
                                                                @keyframes animation_36_2 {
                                                                    0%,
                                                                    58.333333333333336% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 1;
                                                                        animation-timing-function: linear;
                                                                    }
                                                                    100% {
                                                                        transform: matrix(0.87, 0, 0, 0.87, 0, 0);
                                                                        opacity: 1;
                                                                    }
                                                                }
                                                            </style>
                                                            <div class="rmwidget widget-picture" data-id="61df254d46a8250035c6c0c5" style="left: 0px; top: 0px; width: 108px; height: 111px; z-index: 337;">
                                                                <img
                                                                    srcset="
                                                                        https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-10750678-8336-4116-98eb-dfca08d8e257.png?w=188&amp;e=webp&amp;nll=true 2x,
                                                                        https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-10750678-8336-4116-98eb-dfca08d8e257.png?e=webp&amp;nll=true           3x
                                                                    "
                                                                    src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-10750678-8336-4116-98eb-dfca08d8e257.png?w=188&amp;e=webp&amp;nll=true"
                                                                    class="viewable"
                                                                    style="opacity: 1;"
                                                                />
                                                            </div>
                                                        </div>
                                                        <div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 853px; top: 580px; width: 138px; height: 147px; z-index: 340;">
                                                            <style>
                                                                @keyframes animation_37_1 {
                                                                    0%,
                                                                    42.85714285714286% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 0;
                                                                        animation-timing-function: ease-out;
                                                                    }
                                                                    100% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 1;
                                                                    }
                                                                }
                                                            </style>
                                                            <div class="rmwidget widget-picture fade-in seven" data-id="61df25821e3842003dffe26c" style="left: 0px; top: 0px; width: 138px; height: 55px; z-index: 340;">
                                                                <img
                                                                    src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-2a0b3509-fa4b-4893-bb4e-99d66a9665a0.png?e=webp&amp;nll=true"
                                                                    class="viewable"
                                                                    style="opacity: 1;"
                                                                />
                                                            </div>
                                                            <div class="rmwidget widget-picture fade-in seven" data-id="61df2581f5c00c0021d34022" style="left: 12px; top: 61px; width: 123px; height: 86px; z-index: 339;">
                                                                <img
                                                                    srcset="
                                                                        https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-1b20ef86-888a-4879-853b-3a39d4ca064b.png?w=246&amp;e=webp&amp;nll=true 2x,
                                                                        https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-1b20ef86-888a-4879-853b-3a39d4ca064b.png?w=369&amp;e=webp&amp;nll=true 3x
                                                                    "
                                                                    src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3357626/upload-1b20ef86-888a-4879-853b-3a39d4ca064b.png?w=246&amp;e=webp&amp;nll=true"
                                                                    class="viewable"
                                                                    style="opacity: 1;"
                                                                />
                                                            </div>
                                                        </div>
                                                        <div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 17px; top: 60px; width: 240px; height: 396px; z-index: 341;">
                                                            <style>
                                                                @keyframes animation_38_1 {
                                                                    0%,
                                                                    50% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 0;
                                                                        animation-timing-function: ease-out;
                                                                    }
                                                                    100% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 1;
                                                                    }
                                                                }
                                                            </style>
                                                            <div class="rmwidget widget-text-v3 fade-in six" data-id="61df2590daa38e0028a6e6eb" style="left: 0px; top: 0px; width: 240px; height: 396px; z-index: 341;">
                                                                <div class="Box-sc-n41d2v-0 TextBase___StyledBox-sc-1o28pgm-0 jXOqqG kKESck">
                                                                    <div class="text-viewer" style="margin-top: 45px;">
                                                                        <p style="line-height: 21px; padding-right: 0;" class="view-mode unstyled">
                                                                            <span
                                                                                style="
                                                                                    color: rgba(232, 249, 248, 1);
                                                                                    font-style: normal;
                                                                                    font-weight: 400;
                                                                                    letter-spacing: 0.1px;
                                                                                    text-decoration: none;
                                                                                    text-transform: none;
                                                                                    font-family: Roboto;
                                                                                    font-size: 15px;
                                                                                "
                                                                            >
                                                                                How do you stand out from the competition? First, remove organization silos and organize employees around the customer. This requires access to real-time data,
                                                                                as well as integrating enterprise systems and systems of record. Next, embed AI-powered workflows between systems and departments to enable insights and help
                                                                                spur proactive engagement. Guided prompts and recommendations can help customer-facing employees more deeply engage with customers, while intelligent automation
                                                                                can give agents a 360-degree view of the customer within seconds of beginning a live call.
                                                                            </span>
                                                                        </p>
                                                                        <p style="line-height: 21px; padding-right: 0; padding-top: 10px;" class="view-mode unstyled">
                                                                            <span
                                                                                style="
                                                                                    color: rgba(232, 249, 248, 1);
                                                                                    font-style: normal;
                                                                                    font-weight: 400;
                                                                                    letter-spacing: 0.1px;
                                                                                    text-decoration: none;
                                                                                    text-transform: none;
                                                                                    font-family: Roboto;
                                                                                    font-size: 15px;
                                                                                "
                                                                            >
                                                                                <!-- In this whitepaper, you&#8217;ll discover how to integrate digital telephony with your CRM and the benefits of making voice a digital channel for your organization. -->
                                                                            </span>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 876px; top: 11px; width: 103px; height: 292px; z-index: 301;">
                                                            <style>
                                                                @keyframes animation_39_1 {
                                                                    0%,
                                                                    70.37037037037037% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 0;
                                                                        animation-timing-function: ease-out;
                                                                    }
                                                                    100% {
                                                                        transform: matrix(1, 0, 0, 1, 0, 0);
                                                                        opacity: 1;
                                                                    }
                                                                }
                                                            </style>
                                                            <div class="rmwidget widget-picture" data-id="61df277a19f36a001407487a fade-in five" style="left: 0px; top: 77px; width: 103px; height: 292px; z-index: 301;">
                                                                <img
                                                                    src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/1292634/upload-602c59ad-8049-4516-a20a-c0f073c04313.png?e=webp&amp;nll=true"
                                                                    class="viewable"
                                                                    style="opacity: 1;"
                                                                />
                                                            </div>
                                                        </div>

                                                        <div
                                                            class="rmwidget widget-shape div-instead-of-svg"
                                                            data-id="61df1a5e97a1140032bfe2af"
                                                            style="
                                                                left: 908px;
                                                                top: 170px;
                                                                width: 53px;
                                                                height: 202px;
                                                                z-index: 322;
                                                                background-color: rgb(240, 156, 73);
                                                                border-color: rgb(255, 255, 255);
                                                                border-radius: 0px;
                                                                border-style: solid;
                                                                border-width: 0px;
                                                                box-sizing: border-box;
                                                            "
                                                        ></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="lightbox-wrapper"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="lightbox-wrapper"></div>
                        </div>

                        <div class="page hidden last next-page neighbour">
                            <div id="page-3-password-container" class="polyfill-sticky"></div>
                            <div class="page-fixed-bg-container polyfill-sticky"></div>
                            <div class="fixed-position-container-top polyfill-sticky"></div>
                            <div class="fixed-position-container polyfill-sticky"></div>
                            <div class="content-scroll-wrapper has-vertical-scroll">
                                <div class="content-bounds">
                                    <div class="page-content-container" tabindex="-1"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="above-pages-container"></div>
                </div>

                <style id="page-transition-style" type="text/css" class="">
                    .mag .mag-pages-container .container .page {
                        -webkit-transition: all 550ms cubic-bezier(0.4, 0.24, 0.4, 1);
                        transition: all 550ms cubic-bezier(0.4, 0.24, 0.4, 1);
                    }
                    .mag .mag-pages-container .container .page.center-page {
                        -webkit-transition: all 545ms cubic-bezier(0.4, 0.24, 0.4, 1);
                        transition: all 545ms cubic-bezier(0.4, 0.24, 0.4, 1);
                    }
                </style>
                <div class="toolbar for-viewer default"></div>
                <style id="page-position-style" type="text/css" class="">
                    .mag .mag-pages-container .container {
                        left: 0px;
                        width: 1440px;
                    }
                    .mag .mag-pages-container .container .page {
                        left: 0px;
                        width: 1440px;
                    }
                    .mag .mag-pages-container .container .page.prev-page {
                        -webkit-transform: translateX(0px);
                        transform: translateX(0px);
                    }
                    .mag .mag-pages-container .container .page.center-page {
                        -webkit-transform: translateX(0);
                        transform: translateX(0);
                    }
                    .mag .mag-pages-container .container .page.next-page {
                        -webkit-transform: translateX(1440px);
                        transform: translateX(1440px);
                    }
                </style>
            </div>
        </div>
        <div id="service-pages"></div>
        <div class="popups"></div>
        <div id="tmp"></div>
        <div id="fake" style="position: fixed; opacity: 1;"></div>

        <div id="eJOY__extension_root" class="eJOY__extension_root_class" style="all: unset;"></div>
        <iframe id="nr-ext-rsicon" style="position: absolute; display: none; width: 50px; height: 50px; z-index: 2147483647; border-style: none; background: transparent;"></iframe>
        <div id="text-global-styles">
            <style class="">
                .align-left {
                    text-align: left !important;
                }
                .align-center {
                    text-align: center !important;
                }
                .align-right {
                    text-align: right !important;
                }
                .align-justify {
                    text-align: justify !important;
                }
                .unordered-list-item {
                    padding: 0;
                    margin: 0;
                    list-style-type: none;
                }

                .unordered-list-item div[data-offset-key]:before,
                .unordered-list-item > li:before {
                    white-space: nowrap;
                    content: "•\00a0";
                }

                .ordered-list-item {
                    padding: 0;
                    margin: 0;
                    list-style-type: none;
                }

                .ordered-list-item div[data-offset-key]:before,
                .ordered-list-item > li:before {
                    white-space: nowrap;
                    counter-increment: ordered-key;
                    content: counter(ordered-key) ".";
                }

                .paragraph-728601a3-c6ea-4ae9-b905-3d5d7b7cd420 {
                    color: rgba(102, 102, 102, 1);
                    font-family: Roboto;
                    font-size: 10px;
                    font-style: normal;
                    font-weight: 400;
                    letter-spacing: 0px;
                    line-height: 22px;
                    text-align: center;
                }
                .paragraph-1 {
                    color: rgba(34, 34, 34, 1);
                    font-family: Nobel;
                    font-size: 48px;
                    font-style: normal;
                    font-weight: 700;
                    line-height: 60px;
                    text-align: left;
                }
                .paragraph-2 {
                    color: rgba(34, 34, 34, 1);
                    font-family: Georgia;
                    font-size: 24px;
                    font-style: normal;
                    font-weight: 400;
                    line-height: 30px;
                    text-align: left;
                }
                .paragraph-3 {
                    color: rgba(34, 34, 34, 1);
                    font-family: Georgia;
                    font-size: 18px;
                    font-style: normal;
                    font-weight: 400;
                    line-height: 23px;
                    text-align: left;
                }
                .paragraph-4 {
                    color: rgba(34, 34, 34, 0.5);
                    font-family: Georgia;
                    font-size: 14px;
                    font-style: italic;
                    font-weight: 400;
                    line-height: 18px;
                    text-align: left;
                }

                .link-1 {
                    text-decoration: none;
                    padding-bottom: 1px;
                    background: none;
                    color: rgba(17, 90, 127, 1);
                }

                .link-1 * {
                    color: rgba(17, 90, 127, 1);
                }

                .link-1 .hover,
                .link-1:hover {
                    text-decoration: none;
                    padding-bottom: 1px;
                    background: none;
                    color: rgba(17, 90, 127, 1) !important;
                }

                .link-1 .hover *,
                .link-1:hover * {
                    color: rgba(17, 90, 127, 1) !important;
                }

                .link-1.current {
                    text-decoration: none;
                    padding-bottom: 1px;
                    background: none;
                    color: rgba(17, 90, 127, 1);
                }

                .link-1.current * {
                    color: rgba(17, 90, 127, 1);
                }

                .link-5a1abc8a-c29e-44ec-8cc1-19095381f694 {
                    text-decoration: none;
                    padding-bottom: 1px;
                    background: linear-gradient(to right, rgba(0, 120, 255, 1) 0%, rgba(0, 120, 255, 1) 100%) 0 100%/1px 1px repeat-x;
                    color: rgba(0, 120, 255, 1);
                }

                .link-5a1abc8a-c29e-44ec-8cc1-19095381f694 * {
                    color: rgba(0, 120, 255, 1);
                }

                .link-5a1abc8a-c29e-44ec-8cc1-19095381f694 .hover,
                .link-5a1abc8a-c29e-44ec-8cc1-19095381f694:hover {
                    text-decoration: none;
                    padding-bottom: 1px;
                    background: none;
                    color: rgba(0, 120, 255, 1) !important;
                }

                .link-5a1abc8a-c29e-44ec-8cc1-19095381f694 .hover *,
                .link-5a1abc8a-c29e-44ec-8cc1-19095381f694:hover * {
                    color: rgba(0, 120, 255, 1) !important;
                }

                .link-5a1abc8a-c29e-44ec-8cc1-19095381f694.current {
                    text-decoration: none;
                    padding-bottom: 1px;
                    background: none;
                    color: rgba(0, 120, 255, 1);
                }

                .link-5a1abc8a-c29e-44ec-8cc1-19095381f694.current * {
                    color: rgba(0, 120, 255, 1);
                }

                .link-style-1b4297b2-2701-485a-8c54-bc9664f9d834 {
                    text-decoration: none;
                    padding-bottom: 1px;
                    background: linear-gradient(to right, rgba(255, 255, 255, 1) 0%, rgba(255, 255, 255, 1) 100%) 0 100%/1px 1px repeat-x;
                    color: rgba(255, 255, 255, 1);
                }

                .link-style-1b4297b2-2701-485a-8c54-bc9664f9d834 * {
                    color: rgba(255, 255, 255, 1);
                }

                .link-style-1b4297b2-2701-485a-8c54-bc9664f9d834 .hover,
                .link-style-1b4297b2-2701-485a-8c54-bc9664f9d834:hover {
                    text-decoration: none;
                    padding-bottom: 1px;
                    background: linear-gradient(to right, rgba(1, 148, 211, 1) 0%, rgba(1, 148, 211, 1) 100%) 0 100%/1px 1px repeat-x;
                    color: rgba(1, 148, 211, 1) !important;
                }

                .link-style-1b4297b2-2701-485a-8c54-bc9664f9d834 .hover *,
                .link-style-1b4297b2-2701-485a-8c54-bc9664f9d834:hover * {
                    color: rgba(1, 148, 211, 1) !important;
                }

                .link-style-1b4297b2-2701-485a-8c54-bc9664f9d834.current {
                    text-decoration: none;
                    padding-bottom: 1px;
                    background: linear-gradient(to right, rgba(0, 0, 0, 1) 0%, rgba(0, 0, 0, 1) 100%) 0 100%/1px 1px repeat-x;
                    color: rgba(0, 0, 0, 1);
                }

                .link-style-1b4297b2-2701-485a-8c54-bc9664f9d834.current * {
                    color: rgba(0, 0, 0, 1);
                }

                .default-list-style.edit-mode .editor-block-wrapper {
                    display: flex;
                }
                .default-list-style.view-mode {
                    display: flex;
                }
                .default-list-style.view-mode:before {
                    display: inline-block;
                }

                .unordered-list-item.default-list-style.edit-mode .editor-block-wrapper:before {
                    content: "•\00a0";
                    display: inline-block;
                }
                .unordered-list-item.default-list-style.edit-mode div[data-offset-key]:before {
                    content: "•\00a0";
                    display: none;
                }

                .ordered-list-item.default-list-style.edit-mode .editor-block-wrapper:before {
                    counter-increment: ordered-key;
                    content: counter(ordered-key) ".";
                    display: inline-block;
                    white-space: nowrap;
                }
                .ordered-list-item.default-list-style.edit-mode div[data-offset-key]:before {
                    counter-increment: ordered-key;
                    content: counter(ordered-key) ".";
                    display: none;
                    white-space: nowrap;
                }

                .unordered-list-item .default-list-style.view-mode:before {
                    content: "•\00a0";
                }
            </style>
        </div>
    </body>
</html>
