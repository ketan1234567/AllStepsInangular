<html>
<head>
<title>PHPMailer - Mail() basic test</title>
</head>
<body>

<?php

require_once('../class.phpmailer.php');


$mail             = new PHPMailer(); // defaults to using php "mail()"

$body             = file_get_contents('contents.html');

$body			  .="vbndhvjbdfhvbd jdnfvjdv nfvjdnfvd";

$body             = eregi_replace("[\]",'',$body);

$mail->AddReplyTo("bsujata17@gmail.com","First Last");

$mail->SetFrom('bsujata17@gmail.com', 'First Last');

$mail->AddReplyTo("bsujata17@gmail.com","First Last");

$address = "bsujata17@gmail.com";

$mail->AddAddress($address, "Sujata");

$mail->Subject    = "PHPMailer Test Subject via mail(), basic";

$mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test

$mail->MsgHTML($body);

$mail->AddAttachment("images/phpmailer.gif");      // attachment
$mail->AddAttachment("images/phpmailer_mini.gif"); // attachment

/*
$ok = @mail($to, $subject, $message, $headers);
		if ($ok)
		{
			$msg.= "Mail sent successfully to ".$to."<br>";
		} 
		else 
		{
			$msg.= "Mail could NOT be sent  to ".$to."<br>";
		}
		//echo $msg;
		
*/
if(!$mail->Send()) {
  echo "Mailer Error: " . $mail->ErrorInfo;
} else {
  echo "Message sent!";
}

?>

</body>
</html>
