<?php
$leadtype = $_GET['name'];
$leadtype;
?>
	<html style="--min-desktop-width:769px;" class="js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths no-retina no-android no-amazonsilk no-mac windows webkit no-opera chrome no-msie no-msie11 no-winphone8 no-safari no-safari5 no-isipad no-ismobile no-firefox no-edge csspositionsticky isdesktop no-istablet no-isphone no-screenshot-mode controls-on-top new-settings page-loaded">

	<head>
		<meta charset="utf-8">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="generator" content="Readymag" data-project="3175138" data-user="u93502920" data-is-exported="false">
		<meta name="robots" content="noindex,nofollow">
		<meta name="referrer" content="always">
		<meta name="viewport" id="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=10,minimal-ui">
		<meta name="mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-title" content="SERVICENOW_Supercharge_Performance_LE">
		<link rel="preload" as="style" href="/api/fonts/webtype/css?domain=biz-tech-insights.dev&amp;md5=zreSQug9EtvuKFhgD_tvqQ" class="">
		<link rel="preload" as="style" href="/api/fonts/typetoday/css?domain=biz-tech-insights.dev&amp;md5=O1PJSTXTtmazAgKU3SeC5Q" class="">
		<link rel="preload" as="style" href="https://fonts.googleapis.com/css?family=Source Sans Pro:200,200italic,300,300italic,400,400italic,600,600italic,700,700italic,900,900italic%7CRoboto:100,100italic,300,300italic,400,400italic,500,500italic,700,700italic,900,900italic%7CInter:100,200,300,400,500,600,700,800,900&amp;subset=latin,vietnamese,khmer,cyrillic-ext,greek-ext,greek,devanagari,latin-ext,cyrillic" class="">
		<link rel="icon" href="https://rm-content.s3.amazonaws.com/56969df1bd02a4a3292a2178/upload-ebda98a0-c134-11e5-9ef1-39f48dd79a10_144.png" type="image/png" class="">
		<link rel="apple-touch-icon-precomposed" sizes="144x144" href="https://rm-content.s3.amazonaws.com/56969df1bd02a4a3292a2178/upload-ebda98a0-c134-11e5-9ef1-39f48dd79a10_144.png" class="">
		<link rel="apple-touch-icon-precomposed" sizes="114x114" href="https://rm-content.s3.amazonaws.com/56969df1bd02a4a3292a2178/upload-ebda98a0-c134-11e5-9ef1-39f48dd79a10_114.png" class="">
		<link rel="apple-touch-icon-precomposed" sizes="72x72" href="https://rm-content.s3.amazonaws.com/56969df1bd02a4a3292a2178/upload-ebda98a0-c134-11e5-9ef1-39f48dd79a10_72.png" class="">
		<link rel="apple-touch-icon-precomposed" href="https://rm-content.s3.amazonaws.com/56969df1bd02a4a3292a2178/upload-ebda98a0-c134-11e5-9ef1-39f48dd79a10_57.png" class="">
		<!--[if IE]><link rel="shortcut icon" href="https://rm-content.s3.amazonaws.com/56969df1bd02a4a3292a2178/upload-ebda98a0-c134-11e5-9ef1-39f48dd79a10_144.png" type="image/x-icon"/><![endif]-->
		<link rel="next" href="http://biz-tech-insights.dev/SERVICENOW-Supercharge-Performance-LE/2/" class="">
		<meta content="955357184504374" property="fb:app_id">
		<meta content="website" property="og:type">
		<meta content="http://biz-tech-insights.dev/3175138/" property="og:url">
		<meta content="summary_large_image" name="twitter:card">
		<meta content="!" name="fragment">
		<meta content="SERVICENOW_Supercharge_Performance_LE" property="og:site_name">
		<meta content="https://d3n32ilufxuvd1.cloudfront.net/56969df1bd02a4a3292a2178/3175138/screenshot-30ce80e6-046f-41bc-b03c-8b0da626e5db_readyscr_1024.jpg" property="og:image">
		<meta content="SERVICENOW_Supercharge_Performance_LE" property="og:title">
		<title>SERVICENOW_Supercharge_Performance_LE — Page 2</title>
		<link href="https://d1id5eheivyv24.cloudfront.net/6a4dcaf3/dist/60.cb37c41859f0368683aa.js" rel="prefetch" class="">
		<link href="https://d1id5eheivyv24.cloudfront.net/6a4dcaf3/dist/61.95a3cf514623b21eb317.js" rel="prefetch" class="">
		<link href="https://d1id5eheivyv24.cloudfront.net/6a4dcaf3/dist/62.42ac0ea761f2993cf0a4.js" rel="prefetch" class="">
		<link href="https://d1id5eheivyv24.cloudfront.net/6a4dcaf3/dist/63.2c15bf3902dc6f2dc7d3.js" rel="prefetch" class="">
		<link href="https://d1id5eheivyv24.cloudfront.net/6a4dcaf3/dist/64.c2a6038bb4e244e2faea.js" rel="prefetch" class="">
		<link href="https://d1id5eheivyv24.cloudfront.net/6a4dcaf3/dist/65.695c8dbc19ee9ab427ff.js" rel="prefetch" class="">
		<link href="https://d1id5eheivyv24.cloudfront.net/6a4dcaf3/dist/viewer/bundle.8fad076e48e40ebe0241.css" rel="stylesheet" class="">
		<script src="https://d1id5eheivyv24.cloudfront.net/6a4dcaf3/dist/viewer/bundle.8fad076e48e40ebe0241.js"></script>
		<style type="text/css" id="text_styles_paragraph_viewer" class="text_styles">
		.used-fonts-test p.paragraph-1,
		.rmwidget.text div p.paragraph-1 {
			font-family: Nobel;
			font-style: normal;
			font-weight: 700;
			font-size: 48px;
			letter-spacing: 0px;
			line-height: 60px;
			text-align: start;
			text-decoration: none;
			text-transform: none;
			color: rgb(34, 34, 34);
			padding-top: 0px;
			padding-right: 0px;
			padding-bottom: 0px;
			padding-left: 0px;
		}
		
		.used-fonts-test p.paragraph-2,
		.rmwidget.text div p.paragraph-2 {
			font-family: Georgia;
			font-style: normal;
			font-weight: 400;
			font-size: 24px;
			letter-spacing: 0px;
			line-height: 30px;
			text-align: start;
			text-decoration: none;
			text-transform: none;
			color: rgb(34, 34, 34);
			padding-top: 0px;
			padding-right: 0px;
			padding-bottom: 0px;
			padding-left: 0px;
		}
		
		.used-fonts-test p.paragraph-3,
		.rmwidget.text div p.paragraph-3 {
			font-family: Georgia;
			font-style: normal;
			font-weight: 400;
			font-size: 18px;
			letter-spacing: 0px;
			line-height: 23px;
			text-align: start;
			text-decoration: none;
			text-transform: none;
			color: rgb(34, 34, 34);
			padding-top: 0px;
			padding-right: 0px;
			padding-bottom: 0px;
			padding-left: 0px;
		}
		
		.used-fonts-test p.paragraph-4,
		.rmwidget.text div p.paragraph-4 {
			font-family: Georgia;
			font-style: italic;
			font-weight: 400;
			font-size: 14px;
			letter-spacing: 0px;
			line-height: 18px;
			text-align: start;
			text-decoration: none;
			text-transform: none;
			color: rgba(34, 34, 34, 0.5);
			padding-top: 0px;
			padding-right: 0px;
			padding-bottom: 0px;
			padding-left: 0px;
		}
		</style>
		<style type="text/css" id="text_styles_link_viewer" class="text_styles">
		.rmwidget.text div a.link-1 {
			text-decoration: none;
			color: rgb(17, 90, 127);
			background: none;
		}
		
		.rmwidget.text div a.hovered.link-1 {
			text-decoration: none;
			color: rgb(17, 90, 127);
			background: none;
		}
		
		.rmwidget.text div a.link-1 * {
			color: inherit !important;
			text-decoration: none !important;
		}
		
		.rmwidget.text div a.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 {
			text-decoration: none;
			color: rgb(0, 120, 255);
			padding-bottom: 1px;
			background: linear-gradient(to right, rgb(0, 120, 255) 0%, rgb(0, 120, 255) 100%);
			background-size: 1px 1px;
			background-position: 0 100%;
			background-repeat: repeat-x;
		}
		
		.rmwidget.text div a.current.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 {
			text-decoration: none;
			color: rgb(0, 120, 255);
			background: none;
		}
		
		.rmwidget.text div a.hovered.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 {
			text-decoration: none;
			color: rgb(0, 120, 255);
			background: none;
		}
		
		.rmwidget.text div a.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 * {
			color: inherit !important;
			text-decoration: none !important;
		}
		</style>
		<link type="text/css" rel="stylesheet" href="//fonts.googleapis.com/css?family=Source+Sans+Pro:200,200italic,300,300italic,400,400italic,600,600italic,700,700italic,900,900italic%7CRoboto:100,100italic,300,300italic,400,400italic,500,500italic,700,700italic,900,900italic%7CInter:100,200,300,400,500,600,700,800,900&amp;subset=latin,vietnamese,khmer,cyrillic-ext,greek-ext,greek,devanagari,latin-ext,cyrillic" class="fonts" data-id="efc78889-7bac-46ec-9de9-5184ce47b655" data-provider="google" data-fonts-and-variations="Source Sans Pro|n2||Source Sans Pro|i2||Source Sans Pro|n3||Source Sans Pro|i3||Source Sans Pro|n4||Source Sans Pro|i4||Source Sans Pro|n6||Source Sans Pro|i6||Source Sans Pro|n7||Source Sans Pro|i7||Source Sans Pro|n9||Source Sans Pro|i9||Roboto|n1||Roboto|i1||Roboto|n3||Roboto|i3||Roboto|n4||Roboto|i4||Roboto|n5||Roboto|i5||Roboto|n7||Roboto|i7||Roboto|n9||Roboto|i9||Inter|n1||Inter|n2||Inter|n3||Inter|n4||Inter|n5||Inter|n6||Inter|n7||Inter|n8||Inter|n9">
		<style type="text/css" id="individual_button_style_616db3302f2a240027ad5c19_viewer" class="button_styles">
		.rmwidget.widget-button .common-button[data-id="616db3302f2a240027ad5c19"] {
			background-color: rgb(21, 71, 99);
			border-radius: 5px;
			border-width: 0px;
			border-color: rgb(0, 0, 0);
			font-family: Roboto;
			font-weight: 400;
			font-style: normal;
			color: rgb(255, 255, 255);
			font-size: 16px;
			letter-spacing: -0.1px;
		}
		
		.rmwidget.widget-button .common-button[data-id="616db3302f2a240027ad5c19"].current {
			background-color: rgb(0, 120, 255);
			border-radius: 5px;
			border-width: 0px;
			border-color: rgb(0, 0, 0);
			font-family: Arial;
			font-weight: 400;
			font-style: normal;
			color: rgb(255, 255, 255);
			font-size: 18px;
			letter-spacing: 0px;
		}
		
		.rmwidget.widget-button .common-button[data-id="616db3302f2a240027ad5c19"].hovered {
			background-color: rgb(245, 130, 32);
			border-radius: 5px;
			border-width: 0px;
			border-color: rgb(0, 0, 0);
			font-family: Roboto;
			font-weight: 400;
			font-style: normal;
			color: rgb(255, 255, 255);
			font-size: 16px;
			letter-spacing: -0.1px;
		}
		</style>
		<style type="text/css" id="individual_button_style_616db3316afaa11cd2c68aaa_viewer" class="button_styles">
		.rmwidget.widget-button .common-button[data-id="616db3316afaa11cd2c68aaa"] {
			background-color: rgb(21, 71, 99);
			border-radius: 5px;
			border-width: 0px;
			border-color: rgb(0, 0, 0);
			font-family: Roboto;
			font-weight: 400;
			font-style: normal;
			color: rgb(255, 255, 255);
			font-size: 16px;
			letter-spacing: -0.1px;
		}
		
		.rmwidget.widget-button .common-button[data-id="616db3316afaa11cd2c68aaa"].current {
			background-color: rgb(0, 120, 255);
			border-radius: 5px;
			border-width: 0px;
			border-color: rgb(0, 0, 0);
			font-family: Arial;
			font-weight: 400;
			font-style: normal;
			color: rgb(255, 255, 255);
			font-size: 18px;
			letter-spacing: 0px;
		}
		
		.rmwidget.widget-button .common-button[data-id="616db3316afaa11cd2c68aaa"].hovered {
			background-color: rgb(245, 130, 32);
			border-radius: 5px;
			border-width: 0px;
			border-color: rgb(0, 0, 0);
			font-family: Roboto;
			font-weight: 400;
			font-style: normal;
			color: rgb(255, 255, 255);
			font-size: 16px;
			letter-spacing: -0.1px;
		}
		</style>
		<style type="text/css" id="individual_button_style_616db335239f1d0014ca1362_viewer" class="button_styles">
		.rmwidget.widget-button .common-button[data-id="616db335239f1d0014ca1362"] {
			background-color: rgb(21, 71, 99);
			border-radius: 5px;
			border-width: 0px;
			border-color: rgb(0, 0, 0);
			font-family: Roboto;
			font-weight: 400;
			font-style: normal;
			color: rgb(255, 255, 255);
			font-size: 16px;
			letter-spacing: -0.1px;
		}
		
		.rmwidget.widget-button .common-button[data-id="616db335239f1d0014ca1362"].current {
			background-color: rgb(0, 120, 255);
			border-radius: 5px;
			border-width: 0px;
			border-color: rgb(0, 0, 0);
			font-family: Arial;
			font-weight: 400;
			font-style: normal;
			color: rgb(255, 255, 255);
			font-size: 18px;
			letter-spacing: 0px;
		}
		
		.rmwidget.widget-button .common-button[data-id="616db335239f1d0014ca1362"].hovered {
			background-color: rgb(245, 130, 32);
			border-radius: 5px;
			border-width: 0px;
			border-color: rgb(0, 0, 0);
			font-family: Roboto;
			font-weight: 400;
			font-style: normal;
			color: rgb(255, 255, 255);
			font-size: 16px;
			letter-spacing: -0.1px;
		}
		</style>
		<style data-styled="active" data-styled-version="5.3.0"></style>
		<style type="text/css" id="individual_button_style_616db2795678b3003adb91cc_viewer" class="button_styles">
		.rmwidget.widget-button .common-button[data-id="616db2795678b3003adb91cc"] {
			background-color: rgb(21, 71, 99);
			border-radius: 7px;
			border-width: 0px;
			border-color: rgb(0, 0, 0);
			font-family: Roboto;
			font-weight: 400;
			font-style: normal;
			color: rgb(255, 255, 255);
			font-size: 18px;
			letter-spacing: 0px;
		}
		
		.rmwidget.widget-button .common-button[data-id="616db2795678b3003adb91cc"] .icon {
			background-image: url("https://d3n32ilufxuvd1.cloudfront.net/56969df1bd02a4a3292a2178/615f028f9d0aae002b2ebebc/upload-df93a6b5-b199-4db7-8feb-622a8e3a13b2.png");
		}
		
		.rmwidget.widget-button .common-button[data-id="616db2795678b3003adb91cc"].current {
			background-color: rgb(0, 120, 255);
			border-radius: 5px;
			border-width: 0px;
			border-color: rgb(0, 0, 0);
			font-family: Arial;
			font-weight: 400;
			font-style: normal;
			color: rgb(255, 255, 255);
			font-size: 18px;
			letter-spacing: 0px;
		}
		
		.rmwidget.widget-button .common-button[data-id="616db2795678b3003adb91cc"].current .icon {
			background-image: url("https://rm-content.s3.amazonaws.com/56969df1bd02a4a3292a2178/1215691/upload-57c95040-e439-11e8-854a-65e6af600376.png");
		}
		
		.maglink.current .widget-button .common-button[data-id="616db2795678b3003adb91cc"] .icon {
			background-image: url("https://rm-content.s3.amazonaws.com/56969df1bd02a4a3292a2178/1215691/upload-57c95040-e439-11e8-854a-65e6af600376.png");
		}
		
		.rmwidget.widget-button .common-button[data-id="616db2795678b3003adb91cc"].hovered {
			background-color: rgb(245, 130, 32);
			border-radius: 7px;
			border-width: 0px;
			border-color: rgb(0, 0, 0);
			font-family: Roboto;
			font-weight: 400;
			font-style: normal;
			color: rgb(255, 255, 255);
			font-size: 18px;
			letter-spacing: 0px;
		}
		
		.rmwidget.widget-button .common-button[data-id="616db2795678b3003adb91cc"].hovered .icon {
			background-image: url("data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjIiIGJhc2VQcm9maWxlPSJ0aW55IiBpZD0iTGF5ZXJfMSIgeD0iMHB4IiB5PSIwcHgiIHZpZXdCb3g9IjAuMjAwMDAwMjg2MTAyMjk0OTIgMC4wOTk5OTc1MjA0NDY3NzczNCAxMjcuNjAwMDA2MTAzNTE1NjIgMTI3LjcwMDAwNDU3NzYzNjcyIiB4bWw6c3BhY2U9InByZXNlcnZlIiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiBzdHlsZT0id2lkdGg6IDEwMCU7IGhlaWdodDogMTAwJTsiIGZpbGw9InJnYigyNTUsMjU1LDI1NSkiIGZpbGwtb3BhY2l0eT0iMSI+CjxwYXRoIGQ9Ik0xMjcuOCwxMjEuNHYtMy4yYzAtNC43LTEuNC02LjQtNi43LTYuNEg2LjljLTUsMC02LjcsMS42LTYuNyw2LjR2My4yYzAsNSwxLjcsNi40LDYuNyw2LjRoMTE0LjIgIEMxMjYuMiwxMjcuOCwxMjcuOCwxMjYuMiwxMjcuOCwxMjEuNHogTTc1LjgsMC4xSDUyYy03LjgsMC05LjQsMS41LTkuNCw5LjN2MzMuM0gxMC45TDY0LDk1LjhsNTMuMS01My4ySDg1LjJWOS40ICBDODUuMiwxLjYsODMuNSwwLjEsNzUuOCwwLjF6Ii8+Cjwvc3ZnPg==");
		}
		/* Fade-in Effect Css Start Here */
		
		@-webkit-keyframes fadeIn {
			from {
				opacity: 0;
				opacity: 1\9;
				* IE9 only *
			}
			to {
				opacity: 1;
			}
		}
		
		@-moz-keyframes fadeIn {
			from {
				opacity: 0;
				opacity: 1\9;
				* IE9 only *
			}
			to {
				opacity: 1;
			}
		}
		
		@keyframes fadeIn {
			from {
				opacity: 0;
				opacity: 1\9;
				* IE9 only *
			}
			to {
				opacity: 1;
			}
		}
		
		.fade-in {
			opacity: 0;
			/* make things invisible upon start */
			-webkit-animation: fadeIn ease-in 1;
			/* call our keyframe named fadeIn, use animattion ease-in and repeat it only 1 time */
			-moz-animation: fadeIn ease-in 1;
			animation: fadeIn ease-in 1;
			-webkit-animation-fill-mode: forwards;
			/* this makes sure that after animation is done we remain at the last keyframe value (opacity: 1)*/
			-moz-animation-fill-mode: forwards;
			animation-fill-mode: forwards;
			-webkit-animation-duration: 1s;
			-moz-animation-duration: 1s;
			animation-duration: 1s;
		}
		
		.fade-in.one {
			-webkit-animation-delay: 1.5s;
			-moz-animation-delay: 1.5s;
			animation-delay: 1.5s;
		}
		
		.fade-in.two {
			-webkit-animation-delay: 2s;
			-moz-animation-delay: 2s;
			animation-delay: 2s;
		}
		
		.fade-in.three {
			-webkit-animation-delay: 3s;
			-moz-animation-delay: 3s;
			animation-delay: 3s;
		}
		
		.fade-in.four {
			-webkit-animation-delay: 3.5s;
			-moz-animation-delay: 3.5s;
			animation-delay: 3.5s;
		}
		
		.fade-in.five {
			-webkit-animation-delay: 4.5s;
			-moz-animation-delay: 4.5s;
			animation-delay: 4.5s;
		}
		
		.fade-in.six {
			-webkit-animation-delay: 5s;
			-moz-animation-delay: 5s;
			animation-delay: 5s;
		}
		
		.fade-in.seven {
			-webkit-animation-delay: 6.5s;
			-moz-animation-delay: 6.5s;
			animation-delay: 6.5s;
		}
		
		.fade-in.eight {
			-webkit-animation-delay: 7.5s;
			-moz-animation-delay: 7.5s;
			animation-delay: 7.5s;
		}
		
		.fade-in.nine {
			-webkit-animation-delay: 8.5s;
			-moz-animation-delay: 8.5s;
			animation-delay: 8.5s;
		}
		/* Fade-in Css End Here */
		
		.text1 {
			border: none;
			background-color: transparent;
			-moz-appearance: none;
			line-height: 1.4;
			text-align: center;
			font-family: Roboto !important;
			text-transform: inherit;
			font-weight: inherit;
			font-style: inherit;
			text-decoration: inherit;
			color: inherit;
			font-size: inherit;
			letter-spacing: inherit;
		}
		#scollbar::-webkit-scrollbar {
  display: none;
   -ms-overflow-style: none;  /* IE and Edge */
  scrollbar-width: none;  /* Firefox */
}

		</style>
		<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
	</head>

	<body>
		<div id="root"></div>
		<div id="mags">
			<div class="mag viewer-type-horizontal pages-pos-overlap" style="overflow-y: visible; scrollbar-width: none; -ms-overflow-style: none; background: #13b1bd;" id="scollbar">
				<div  style="background-color: #13B1BD;">
					<div class="container">
						<div class="blackout"></div>
						<div class="page prev-page neighbour hidden">
							<div id="page-1-password-container" class="polyfill-sticky"></div>
							<div class="page-fixed-bg-container polyfill-sticky">
								<div class="rmwidget widget-background" style="background-color: #13b1bd"> </div>
							</div>
							<div class="fixed-position-container-top polyfill-sticky"></div>
							<div class="fixed-position-container polyfill-sticky"></div>
							<div class="content-scroll-wrapper has-vertical-scroll">
								<div class="content-bounds" style="width: 100%; height: auto;position:absolute">

								<div class="page-content-container" tabindex="-1"
									style="width: 1024px; height: auto; top: 0px; margin: 0 auto;position:relative">
										
										
										
										<div class="page center-page neighbour">
							<div id="page-2-password-container" class="polyfill-sticky"></div>
							<div class="page-fixed-bg-container polyfill-sticky">
								<div class="rmwidget widget-background" style="background-color: #13b1bd"> </div>
							</div>
							<div class="fixed-position-container-top polyfill-sticky"></div>
							<div class="fixed-position-container polyfill-sticky"></div>
							<div class="content-scroll-wrapper " style="width:2000px;">
								<div class="content-bounds" style="width: 1600px; height: 1060px;">
									<div class="page-content-container" tabindex="-1" style="width: 1024px; height: 1067px; top: 0px; left: 475px;">
										<div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 14px; top: 9px; width: 721px; height: 630px; z-index: 310;">
											<style>
											@keyframes animation_13_1 {
												0%,
												50% {
													transform: matrix(1, 0, 0, 1, 0, 0);
													opacity: 0;
													animation-timing-function: ease-out
												}
												100% {
													transform: matrix(1, 0, 0, 1, 0, 0);
													opacity: 1;
												}
											}
											</style>
										 <div class="rmwidget widget-text-v3 fade-in five" data-id="616db2795678b3003adb91c8" style="left: 0px; top: 0px; width: 656px; height: 52px; z-index: 310;">
                                    <div class="Box-sc-n41d2v-0 TextBase___StyledBox-sc-1o28pgm-0 dLcLVH kKESck">
                                       <div class="text-viewer">
                                          <p style="line-height:46px;padding-right:0" class="view-mode unstyled align-left">
                                             <span style="font-size:30px;font-weight:300;font-family:Roboto;font-style:normal;text-decoration:none;text-transform:none;color:rgba(255, 255, 255, 1)">The Hybrid Digital Workplace Is Here to Stay</span>
                                          </p>
                                       </div>
                                    </div>
                                 </div>
											
											
											<div class="rmwidget widget-text-v3 fade-in five" data-id="616db2795678b3003adb91c9" style="left: 3px; top: 95px; width: 344px; height: 470px; z-index: 309;"><div class="Box-sc-n41d2v-0 TextBase___StyledBox-sc-1o28pgm-0 dLcLVH kKESck"><div class="text-viewer">
<p style="line-height:23px;padding-bottom:8px" class="view-mode unstyled">
<span style="font-size:16px;font-weight:300;font-family:Roboto;font-style:normal;text-decoration:none;text-transform:none;color:rgba(255, 255, 255, 1)">It&#8217;s clear what the next normal will look like for many enterprises. Gone are the days of packed cubicles and parking lots, where collaboration could only be done on-site and working from home was a rare occurrence. <br><br> The hybrid digital workplace adds complications to the traditional role of workplace services. Along with managing the assets in the office, they must account for the equipment that employees take home, such as monitors, keyboards, and computers, so that these groups can maintain a complete accounting. The extent of office use will vary dramatically, with some employees coming in a few days a week to focus on essential tasks, while others may prefer a full-time office or home schedule. <br><br> The bottom line: Organizations will need to deliver employees the right digital experience from anywhere so that there is no drop-off between the home and the office. <br><br> In this eBook, &#8220;The Arrival of the Hybrid Digital Workplace,&#8221; you&#8217;ll learn how to leverage a set of products to deliver frictionless workflows to your workplace departments, including security, reception, employee transportation, food service, and IT.
</span>
</p>

</div>
</div>
</div>
											<div class="rmwidget widget-text-v3 fade-in six" data-id="616db2795678b3003adb91cd" style="left: 312px; top: 817px; width: 409px; height: 63px; z-index: 306;"><div class="Box-sc-n41d2v-0 TextBase___StyledBox-sc-1o28pgm-0 dLcLVH kKESck"><div class="text-viewer">
<p style="line-height:24px" class="view-mode unstyled align-center"><span style="font-size:20px;font-weight:700;font-family:Roboto;font-style:normal;text-decoration:none;text-transform:none;color:rgba(255, 255, 255, 1)">Download the eBook, &#8220;The Arrival of the Hybrid Digital Workplace,&#8221; now </span></p></div></div></div>
										</div>
										  <div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 0; left: 437.5px; top: 912px; width: 187px; height: 72px; z-index: 308; animation-name: animation_14_1, animation_14_2; animation-duration: 3.2s, 1.6s; animation-delay: 0s, 3.2s; animation-iteration-count: 1, infinite; animation-direction: alternate, alternate; animation-fill-mode: none, none; animation-play-state: running;">
                                 <style>@keyframes animation_14_1 {	0%, 50% {transform: matrix(1,0,0,1,0,0); opacity: 0; animation-timing-function: ease-out}	100% {transform: matrix(1,0,0,1,0,0); opacity: 1; }}@keyframes animation_14_2 {	0% {transform: matrix(1,0,0,1,0,0); opacity: 1; animation-timing-function: linear}	100% {transform: matrix(0.9,0,0,0.9,0,0); opacity: 1; }}</style>
                                 <a class="maglink" href="form.php?name=<?php echo $leadtype; ?>" target="">
                                    <div class="rmwidget widget-button fade-in six" data-id="616db2795678b3003adb91cc" style="left: 0px; top: 0px; width: 187px; height: 72px; z-index: 308; border-radius: 7px;">
                                       <div class="common-button" data-id="616db2795678b3003adb91cc" style="flex-direction: row;">
                                          <div class="icon" style="display: inline-block; width: 29px; height: 30px; margin-right: 0px; margin-left: 0px;"></div>
                                          <div class="text" style="display: none; width: 16px; padding-left: 0px; text-indent: 0px; height: 72px; line-height: 72px;"></div>
                                       </div>
                                    </div>
                                 </a>
                              </div>
										 <div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 18px; top: 798px; width: 167px; height: 220px; z-index: 307;">
                                 <style>@keyframes animation_15_1 {	0%, 52.63157894736842% {transform: matrix(0.36,0,0,0.36,0,0); opacity: 0; animation-timing-function: ease-out}	100% {transform: matrix(1,0,0,1,0,0); opacity: 1; }}</style>
                                 <div class="rmwidget widget-picture fade-in seven" data-id="616db2795678b3003adb91ce" style="left: 0px; top: 0px; width: 247px; height: 220px; z-index: 307;">
                                    <div class="bgpic" url="eb-the-arrival-of-the-hybrid-digital-workplace.PNG?w=334&amp;e=webp&amp;nll=true" style="background-image: url(&quot;eb-the-arrival-of-the-hybrid-digital-workplace.PNG?w=334&amp;e=webp&amp;nll=true&quot;); background-position: 50% 50%; box-shadow: rgb(68, 68, 68) 0px 0px 0px 1px inset; border-radius: 0px; opacity: 1;"></div>
                                    <img srcset="eb-the-arrival-of-the-hybrid-digital-workplace.PNG?w=334&amp;e=webp&amp;nll=true 2x, eb-the-arrival-of-the-hybrid-digital-workplace.PNG?w=501&amp;e=webp&amp;nll=true 3x" src="eb-the-arrival-of-the-hybrid-digital-workplace.PNG?w=334&amp;e=webp&amp;nll=true" class="viewable saveable" style="opacity: 1;">
                                 </div>
                              </div>
										 <div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 825px; top: 270px; width: 186px; height: 330px; z-index: 321;">
                                 <style>@keyframes animation_16_1 {	0%, 56.75675675675676% {transform: matrix(1,0,0,1,0,0); opacity: 0; animation-timing-function: ease-out}	100% {transform: matrix(1,0,0,1,0,0); opacity: 1; }}</style>
                                 <div class="rmwidget widget-shape fade-in six" data-id="616dbc240d1de5006e95824e" style="left: 69px; top: 2px; width: 50px; height: 51px; z-index: 302;">
                                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="50px" height="51px">
                                       <defs>
                                          <clipPath id="clip_616dbc240d1de5006e95824e_viewer-ce2f414a-bd5c-480b-b95e-54deca8c31a2">
                                             <ellipse cx="25" cy="25.5" rx="25" ry="25.5"></ellipse>
                                          </clipPath>
                                       </defs>
                                       <ellipse mask="url(#mask_616dbc240d1de5006e95824e_viewer-ce2f414a-bd5c-480b-b95e-54deca8c31a2)" cx="25" cy="25.5" rx="25" ry="25.5" style="fill:rgb(255,255,255); stroke:none; stroke-width:0; pointer-events: visiblePainted;"></ellipse>
                                    </svg>
                                 </div>
                                 <div class="rmwidget widget-shape div-instead-of-svg fade-in six" data-id="616db2795678b3003adb91d0" style="left: 0px; top: 57px; width: 186px; height: 273px; z-index: 303; background-color: rgb(21, 71, 99); border-color: rgb(255, 255, 255); border-radius: 20px; border-style: solid; border-width: 0px; box-sizing: border-box;"></div>
                                 <div class="rmwidget widget-shape fade-in six" data-id="616dbcaac92f7d406ba7a0b3" style="left: 17px; top: 237px; width: 153px; height: 24px; z-index: 321;">
                                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="153px" height="24px">
                                       <path d="M0 12.5 L153 12.5" style="fill: none; stroke: rgb(255,255,255); stroke-width: 1" shape-rendering="auto"></path>
                                    </svg>
                                 </div>
                                 <div class="rmwidget widget-shape icon fade-in six" data-id="616db2795678b3003adb91d1" style="left: 65px; top: 0px; width: 57px; height: 57px; z-index: 312;"><img src="https://d3n32ilufxuvd1.cloudfront.net/56969df1bd02a4a3292a2178/616db2785678b3003adb9171/upload-c9c4b6b1-67e2-481b-8b9e-c9ffb0661c66.png"></div>
                                 <div class="rmwidget widget-text-v3 fade-in six" data-id="616db2795678b3003adb91cf" style="left: 19px; top: 74px; width: 152px; height: 83px; z-index: 311;">
                                    <div class="Box-sc-n41d2v-0 TextBase___StyledBox-sc-1o28pgm-0 dLcLVH kKESck">
                                       <div class="text-viewer">
                                          <p style="line-height:20px" class="view-mode unstyled">
                                             <span style="font-size:15px;font-family:Roboto;text-decoration:none;text-transform:none;color:rgba(255, 255, 255, 1);font-style:normal">
                                             <span style="font-weight:400">Employees who prefer to work </span>
                                             <span style="font-weight:400">in the office but are compelled to work </span>
                                             <span style="font-weight:400"> remotely suffer from a 17% reduction </span>
                                             <span style="font-weight:400">in productivity—and have a 24%  </span>
                                             <span style="font-weight:400">higher turnover rate. </span>
                                             </span>
                                          </p>
                                       </div>
                                    </div>
                                 </div>
                                 
                                 <div class="rmwidget widget-text-v3 fade-in six" data-id="616dbc71a71c6b5b522cdcb6" style="left: 18px; top: 265px; width: 152px; height: 39px; z-index: 320;">
                                    <div class="Box-sc-n41d2v-0 TextBase___StyledBox-sc-1o28pgm-0 dLcLVH kKESck">
                                       <div class="text-viewer">
                                          <p style="line-height:12px" class="view-mode unstyled"><span style="font-family:Roboto;text-decoration:none;text-transform:none;color:rgba(255, 255, 255, 1);font-style:normal;font-weight:400;font-size:11px">Source: Gallup, &#8220;Remote Work: Is It a Virtual Threat to Your Culture?&#8221; August 25, 2020</span></p>
                                       </div>
                                    </div>
                                 </div>
                              </div>
										<div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 440px; top: 248px; width: 324px; height: 312.38px; z-index: 316;">
											<style>
											@keyframes animation_17_1 {
												0%,
												29.629629629629626% {
													transform: matrix(1, 0, 0, 1, 0, 0);
													opacity: 0;
													animation-timing-function: ease-out
												}
												100% {
													transform: matrix(1, 0, 0, 1, 0, 0);
													opacity: 1;
												}
											}
											</style>
											<div class="rmwidget widget-picture fade-in three" data-id="616db8c6454bb800333dbccb" style="left: 0px; top: 0px; width: 324px; height: 312.38px; z-index: 314;"><img srcset="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3175138/upload-9143ab58-49e0-4010-9b13-56db30266914.png?w=648&amp;e=webp&amp;nll=true 2x, https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3175138/upload-9143ab58-49e0-4010-9b13-56db30266914.png?w=972&amp;e=webp&amp;nll=true 3x" src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3175138/upload-9143ab58-49e0-4010-9b13-56db30266914.png?w=648&amp;e=webp&amp;nll=true" class="viewable" style="opacity: 1;"></div>
											<div class="rmwidget widget-picture fade-in three" data-id="616dba481ed2d1001d819475" style="left: 140px; top: 76px; width: 143px; height: 90px; z-index: 316; transform: rotate(3deg);"><img srcset="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3175138/upload-d8ec1ee6-1a26-4574-8da1-0642a68d3a86.png?w=287&amp;e=webp&amp;nll=true 2x, https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3175138/upload-d8ec1ee6-1a26-4574-8da1-0642a68d3a86.png?w=430&amp;e=webp&amp;nll=true 3x" src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3175138/upload-d8ec1ee6-1a26-4574-8da1-0642a68d3a86.png?w=287&amp;e=webp&amp;nll=true" class="viewable" style="opacity: 1;"></div>
										</div>
										<div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 0; left: 427px; top: 126px; width: 125px; height: 125px; z-index: 315; animation-name: animation_18_1, animation_18_2; animation-duration: 2.9s, 2s; animation-delay: 0s, 2.9s; animation-iteration-count: 1, infinite; animation-direction: alternate, alternate; animation-fill-mode: none, none; animation-play-state: running;">
											<style>
											@keyframes animation_18_1 {
												0%,
												55.172413793103445% {
													transform: matrix(1, 0, 0, 1, 0, 0);
													opacity: 0;
													animation-timing-function: ease-out
												}
												100% {
													transform: matrix(1, 0, 0, 1, 0, 0);
													opacity: 1;
												}
											}
											
											@keyframes animation_18_2 {
												0% {
													transform: matrix(1, 0, 0, 1, 0, 0);
													opacity: 1;
													animation-timing-function: linear
												}
												100% {
													transform: matrix(1.13, 0, 0, 1.13, 0, 0);
													opacity: 1;
												}
											}
											</style>
											<div class="rmwidget widget-picture fade-in four" data-id="616db8c6d1bc4e00226da7db" style="left: 0px; top: 0px; width: 125px; height: 125px; z-index: 315;"><img srcset="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3175138/upload-06653258-d243-4237-b7d4-090725d19bf7.png?w=283&amp;e=webp&amp;nll=true 2x, https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3175138/upload-06653258-d243-4237-b7d4-090725d19bf7.png?e=webp&amp;nll=true 3x" src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3175138/upload-06653258-d243-4237-b7d4-090725d19bf7.png?w=283&amp;e=webp&amp;nll=true" class="viewable" style="opacity: 1;"></div>
										</div>
										<div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 844px; top: 780px; width: 156px; height: 76px; z-index: 318;">
											<style>
											@keyframes animation_19_1 {
												0% {
													transform: matrix(1, 0, 0, 1, 0, 0);
													opacity: 0;
													animation-timing-function: ease-out
												}
												100% {
													transform: matrix(1, 0, 0, 1, 0, 0);
													opacity: 1;
												}
											}
											</style>
											<div class="rmwidget widget-picture fade-in one" data-id="616dbaea293d24006e224235" style="left: 19px; top: 0px; width: 115px; height: 46px; z-index: 318;"><img srcset="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/1638239/upload-38a090ff-2237-43ca-b2d0-430e69f42f92.png?w=230&amp;e=webp&amp;nll=true 2x, https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/1638239/upload-38a090ff-2237-43ca-b2d0-430e69f42f92.png?e=webp&amp;nll=true 3x" src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/1638239/upload-38a090ff-2237-43ca-b2d0-430e69f42f92.png?w=230&amp;e=webp&amp;nll=true" class="viewable" style="opacity: 1;"></div>
											<div class="rmwidget widget-picture fade-in one" data-id="616dbaeac9403d003200d9e8" style="left: 0px; top: 35px; width: 156px; height: 28px; z-index: 317;"><img srcset="https://advance.biz-tech-insights.com/LP-ServiceNow-ITSM-Lead-Engage/servicenow-logo-1.png?w=312&amp;e=webp&amp;nll=true 2x, https://advance.biz-tech-insights.com/LP-ServiceNow-ITSM-Lead-Engage/servicenow-logo-1.png?e=webp&amp;nll=true 3x" src="https://advance.biz-tech-insights.com/LP-ServiceNow-ITSM-Lead-Engage/servicenow-logo-1.png?w=312&amp;e=webp&amp;nll=true" class="viewable" style="opacity: 1;height: unset; width: 175px;margin-left: -9px;"></div>
										</div>
										<div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 583px; top: 101px; width: 132.86px; height: 360px; z-index: 301;">
											<style>
											@keyframes animation_20_1 {
												0%,
												20% {
													transform: matrix(1, 0, 0, 1, 0, 0);
													opacity: 0;
													animation-timing-function: ease-out
												}
												100% {
													transform: matrix(1, 0, 0, 1, 0, 0);
													opacity: 1;
												}
											}
											</style>
											<div class="rmwidget widget-picture fade-in two" data-id="616dbe196f9c7c004320cee6" style="left: 0px; top: 0px; width: 132.86px; height: 360px; z-index: 301;"><img class="viewable" srcset="" src="https://content.readymag.com/56969df1bd02a4a3292a2178/1757071/upload-400ab93e-d1d0-4d9e-8786-f06aaf87c436.gif" style="opacity: 1;" url="https://content.readymag.com/56969df1bd02a4a3292a2178/1757071/upload-400ab93e-d1d0-4d9e-8786-f06aaf87c436.gif"></div>
										</div>
										<div class="rmwidget widget-picture" data-id="616db90d6693cd31abf07d29" style="left: 365px; top: 233px; width: 230.23px; height: 360px; z-index: 322;"><img src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3175138/upload-ce41946b-0a2c-47ba-b008-bce4f0a7d8e9.png?e=webp&amp;nll=true" class="viewable" style="opacity: 1;"></div>
									</div>
								</div>
							</div>
						</div>
										
										
									
									
									
										
										
										
									
									
										
									</div>
								</div>
							</div>
						</div>
						
						
						
						
						
						<div class="page hidden last next-page neighbour">
							<div id="page-3-password-container" class="polyfill-sticky"></div>
							<div class="page-fixed-bg-container polyfill-sticky"></div>
							<div class="fixed-position-container-top polyfill-sticky"></div>
							<div class="fixed-position-container polyfill-sticky"></div>
							<div class="content-scroll-wrapper has-vertical-scroll">
								<div class="content-bounds">
									<div class="page-content-container" tabindex="-1"></div>
								</div>
							</div>
						</div>
					</div>
					<div class="above-pages-container"></div>
				</div>
				<style id="page-transition-style" type="text/css" class="">
				.mag .mag-pages-container .container .page {
					-webkit-transition: all 550ms cubic-bezier(0.40, 0.24, 0.40, 1);
					transition: all 550ms cubic-bezier(0.40, 0.24, 0.40, 1);
				}
				
				.mag .mag-pages-container .container .page.center-page {
					-webkit-transition: all 545ms cubic-bezier(0.40, 0.24, 0.40, 1);
					transition: all 545ms cubic-bezier(0.40, 0.24, 0.40, 1);
				}
				</style>
				<div class="toolbar for-viewer"> </div>
				<style id="page-position-style" type="text/css" class="">
				.mag .mag-pages-container .container {
					left: 0px;
					width: 1600px;
				}
				
				.mag .mag-pages-container .container .page {
					left: 0px;
					width: 1600px;
				}
				
				.mag .mag-pages-container .container .page.prev-page {
					-webkit-transform: translateX(0px);
					transform: translateX(0px);
				}
				
				.mag .mag-pages-container .container .page.center-page {
					-webkit-transform: translateX(0);
					transform: translateX(0);
				}
				
				.mag .mag-pages-container .container .page.next-page {
					-webkit-transform: translateX(1600px);
					transform: translateX(1600px);
				}
				</style>
			</div>
		</div>
		<div id="service-pages"></div>
		<div class="popups"></div>
		<div id="tmp"></div>
		<div id="fake" style="position: fixed; opacity: 1.0"></div>
		<div id="text-global-styles">
			<style class="">
			.align-left {
				text-align: left !important;
			}
			
			.align-center {
				text-align: center !important;
			}
			
			.align-right {
				text-align: right !important;
			}
			
			.align-justify {
				text-align: justify !important;
			}
			
			.unordered-list-item {
				padding: 0;
				margin: 0;
				list-style-type: none;
			}
			
			.unordered-list-item div[data-offset-key]:before,
			.unordered-list-item > li:before {
				white-space: nowrap;
				content: "•\00a0";
			}
			
			.ordered-list-item {
				padding: 0;
				margin: 0;
				list-style-type: none;
			}
			
			.ordered-list-item div[data-offset-key]:before,
			.ordered-list-item > li:before {
				white-space: nowrap;
				counter-increment: ordered-key;
				content: counter(ordered-key)".";
			}
			
			.paragraph-728601a3-c6ea-4ae9-b905-3d5d7b7cd420 {
				color: rgba(102, 102, 102, 1);
				font-family: Roboto;
				font-size: 10px;
				font-style: normal;
				font-weight: 400;
				letter-spacing: 0px;
				line-height: 22px;
				text-align: center;
			}
			
			.paragraph-1 {
				text-align: left;
				line-height: 60px;
				font-weight: 700;
				font-style: normal;
				font-size: 48px;
				font-family: Nobel;
				color: rgba(34, 34, 34, 1);
			}
			
			.paragraph-2 {
				text-align: left;
				line-height: 30px;
				font-weight: 400;
				font-style: normal;
				font-size: 24px;
				font-family: Georgia;
				color: rgba(34, 34, 34, 1);
			}
			
			.paragraph-3 {
				text-align: left;
				line-height: 23px;
				font-weight: 400;
				font-style: normal;
				font-size: 18px;
				font-family: Georgia;
				color: rgba(34, 34, 34, 1);
			}
			
			.paragraph-4 {
				text-align: left;
				line-height: 18px;
				font-weight: 400;
				font-style: italic;
				font-size: 14px;
				font-family: Georgia;
				color: rgba(34, 34, 34, 0.5);
			}
			
			.link-1 {
				text-decoration: none;
				padding-bottom: 1px;
				background: none;
				color: rgba(17, 90, 127, 1);
			}
			
			.link-1 * {
				color: rgba(17, 90, 127, 1);
			}
			
			.link-1 .hover,
			.link-1:hover {
				text-decoration: none;
				padding-bottom: 1px;
				background: none;
				color: rgba(17, 90, 127, 1) !important;
			}
			
			.link-1 .hover *,
			.link-1:hover * {
				color: rgba(17, 90, 127, 1) !important;
			}
			
			.link-1.current {
				text-decoration: none;
				padding-bottom: 1px;
				background: none;
				color: rgba(17, 90, 127, 1);
			}
			
			.link-1.current * {
				color: rgba(17, 90, 127, 1);
			}
			
			.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 {
				text-decoration: none;
				padding-bottom: 1px;
				background: linear-gradient(to right, rgba(0, 120, 255, 1) 0%, rgba(0, 120, 255, 1) 100%) 0 100%/1px 1px repeat-x;
				color: rgba(0, 120, 255, 1);
			}
			
			.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 * {
				color: rgba(0, 120, 255, 1);
			}
			
			.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 .hover,
			.link-5a1abc8a-c29e-44ec-8cc1-19095381f694:hover {
				text-decoration: none;
				padding-bottom: 1px;
				background: none;
				color: rgba(0, 120, 255, 1) !important;
			}
			
			.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 .hover *,
			.link-5a1abc8a-c29e-44ec-8cc1-19095381f694:hover * {
				color: rgba(0, 120, 255, 1) !important;
			}
			
			.link-5a1abc8a-c29e-44ec-8cc1-19095381f694.current {
				text-decoration: none;
				padding-bottom: 1px;
				background: none;
				color: rgba(0, 120, 255, 1);
			}
			
			.link-5a1abc8a-c29e-44ec-8cc1-19095381f694.current * {
				color: rgba(0, 120, 255, 1);
			}
			
			.default-list-style.edit-mode .editor-block-wrapper {
				display: flex;
			}
			
			.default-list-style.view-mode {
				display: flex;
			}
			
			.default-list-style.view-mode:before {
				display: inline-block;
			}
			
			.unordered-list-item.default-list-style.edit-mode .editor-block-wrapper:before {
				content: "•\00a0";
				display: inline-block;
			}
			
			.unordered-list-item.default-list-style.edit-mode div[data-offset-key]:before {
				content: "•\00a0";
				display: none;
			}
			
			.ordered-list-item.default-list-style.edit-mode .editor-block-wrapper:before {
				counter-increment: ordered-key;
				content: counter(ordered-key)".";
				display: inline-block;
				white-space: nowrap;
			}
			
			.ordered-list-item.default-list-style.edit-mode div[data-offset-key]:before {
				counter-increment: ordered-key;
				content: counter(ordered-key)".";
				display: none;
				white-space: nowrap;
			}
			
			.unordered-list-item .default-list-style.view-mode:before {
				content: "•\00a0";
			}
			</style>
		</div>
	</body>

	</html>