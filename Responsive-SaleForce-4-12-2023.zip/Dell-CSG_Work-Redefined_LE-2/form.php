
<html style="--min-desktop-width:769px;" class="js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths no-retina no-android no-amazonsilk no-mac windows webkit no-opera chrome no-msie no-msie11 no-winphone8 no-safari no-safari5 no-isipad no-ismobile no-firefox no-edge csspositionsticky isdesktop no-istablet no-isphone no-screenshot-mode new-settings wf-flqd-n4-active wf-active page-loaded">

<head>
	<meta charset="utf-8">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta name="generator" content="Readymag" data-project="3300951" data-user="u93502920" data-is-exported="false">
	<meta name="robots" content="noindex,nofollow">
	<meta name="referrer" content="always">
	<meta name="viewport" id="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=10,minimal-ui">
	<meta name="mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-title" content="TRICENTIS_Software_Testing_DevOps_120921_LE">
	<link rel="preload" as="style" href="/api/fonts/webtype/css?domain=biz-tech-insights.dev&amp;md5=zreSQug9EtvuKFhgD_tvqQ" class="">
	<link rel="preload" as="style" href="/api/fonts/typetoday/css?domain=biz-tech-insights.dev&amp;md5=O1PJSTXTtmazAgKU3SeC5Q" class="">
	<link rel="preload" as="style" href="https://fonts.googleapis.com/css?family=Source Sans Pro:200,200italic,300,300italic,400,400italic,600,600italic,700,700italic,900,900italic%7CRoboto:100,100italic,300,300italic,400,400italic,500,500italic,700,700italic,900,900italic%7CInter:100,200,300,400,500,600,700,800,900&amp;subset=latin,vietnamese,khmer,cyrillic-ext,greek-ext,greek,devanagari,latin-ext,cyrillic" class="">
	<link rel="icon" href="https://rm-content.s3.amazonaws.com/56969df1bd02a4a3292a2178/upload-ebda98a0-c134-11e5-9ef1-39f48dd79a10_144.png" type="image/png" class="">
	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="https://rm-content.s3.amazonaws.com/56969df1bd02a4a3292a2178/upload-ebda98a0-c134-11e5-9ef1-39f48dd79a10_144.png" class="">
	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="https://rm-content.s3.amazonaws.com/56969df1bd02a4a3292a2178/upload-ebda98a0-c134-11e5-9ef1-39f48dd79a10_114.png" class="">
	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="https://rm-content.s3.amazonaws.com/56969df1bd02a4a3292a2178/upload-ebda98a0-c134-11e5-9ef1-39f48dd79a10_72.png" class="">
	<link rel="apple-touch-icon-precomposed" href="https://rm-content.s3.amazonaws.com/56969df1bd02a4a3292a2178/upload-ebda98a0-c134-11e5-9ef1-39f48dd79a10_57.png" class="">
	<!--[if IE]><link rel="shortcut icon" href="https://rm-content.s3.amazonaws.com/56969df1bd02a4a3292a2178/upload-ebda98a0-c134-11e5-9ef1-39f48dd79a10_144.png" type="image/x-icon"/><![endif]-->
	<link rel="next" href="http://biz-tech-insights.dev/TRICENTIS-Software-Testing-DevOps-120921-LE/3/" class="">
	<meta content="955357184504374" property="fb:app_id">
	<meta content="website" property="og:type">
	<meta content="http://biz-tech-insights.dev/p14598263/" property="og:url">
	<meta content="summary_large_image" name="twitter:card">
	<meta content="!" name="fragment">
	<meta content="TRICENTIS_Software_Testing_DevOps_120921_LE" property="og:site_name">
	<meta content="https://d3n32ilufxuvd1.cloudfront.net/56969df1bd02a4a3292a2178/3300951/screenshot-7158e1ab-2df7-4514-9ae3-b4f60c6c1b26_readyscr_1024.jpg" property="og:image">
	<meta content="TRICENTIS_Software_Testing_DevOps_120921_LE — Page 2" property="og:title">
	<meta name="viewport" content="width=1400, user-scalable=no">
	<title>Dell-CSG_Work-Redefined_LE-2</title>
	<link href="https://d1id5eheivyv24.cloudfront.net/5c302460/dist/62.67e2bef566652481d627.js" rel="prefetch" class="">
	<link href="https://d1id5eheivyv24.cloudfront.net/5c302460/dist/63.40f2dc9e07206c6c2d43.js" rel="prefetch" class="">
	<link href="https://d1id5eheivyv24.cloudfront.net/5c302460/dist/64.6e4a363af8122c5404bd.js" rel="prefetch" class="">
	<link href="https://d1id5eheivyv24.cloudfront.net/5c302460/dist/65.f42d068ddcf717621b1f.js" rel="prefetch" class="">
	<link href="https://d1id5eheivyv24.cloudfront.net/5c302460/dist/66.7f1fe29d92d52a60ea04.js" rel="prefetch" class="">
	<link href="https://d1id5eheivyv24.cloudfront.net/5c302460/dist/67.49adcddf7784d3432242.js" rel="prefetch" class="">
	<link href="https://d1id5eheivyv24.cloudfront.net/5c302460/dist/viewer/bundle.00b0554064178d9f4b3e.css" rel="stylesheet" class="">
	<script src="https://d1id5eheivyv24.cloudfront.net/5c302460/dist/viewer/bundle.00b0554064178d9f4b3e.js"></script>
	<style type="text/css" id="text_styles_paragraph_viewer" class="text_styles">
	.used-fonts-test p.paragraph-1,
	.rmwidget.text div p.paragraph-1 {
		font-family: Nobel;
		font-style: normal;
		font-weight: 700;
		font-size: 48px;
		letter-spacing: 0px;
		line-height: 60px;
		text-align: start;
		text-decoration: none;
		text-transform: none;
		color: rgb(34, 34, 34);
		padding-top: 0px;
		padding-right: 0px;
		padding-bottom: 0px;
		padding-left: 0px;
	}
	
	.used-fonts-test p.paragraph-2,
	.rmwidget.text div p.paragraph-2 {
		font-family: Georgia;
		font-style: normal;
		font-weight: 400;
		font-size: 24px;
		letter-spacing: 0px;
		line-height: 30px;
		text-align: start;
		text-decoration: none;
		text-transform: none;
		color: rgb(34, 34, 34);
		padding-top: 0px;
		padding-right: 0px;
		padding-bottom: 0px;
		padding-left: 0px;
	}
	
	.used-fonts-test p.paragraph-3,
	.rmwidget.text div p.paragraph-3 {
		font-family: Georgia;
		font-style: normal;
		font-weight: 400;
		font-size: 18px;
		letter-spacing: 0px;
		line-height: 23px;
		text-align: start;
		text-decoration: none;
		text-transform: none;
		color: rgb(34, 34, 34);
		padding-top: 0px;
		padding-right: 0px;
		padding-bottom: 0px;
		padding-left: 0px;
	}
	
	.used-fonts-test p.paragraph-4,
	.rmwidget.text div p.paragraph-4 {
		font-family: Georgia;
		font-style: italic;
		font-weight: 400;
		font-size: 14px;
		letter-spacing: 0px;
		line-height: 18px;
		text-align: start;
		text-decoration: none;
		text-transform: none;
		color: rgba(34, 34, 34, 0.5);
		padding-top: 0px;
		padding-right: 0px;
		padding-bottom: 0px;
		padding-left: 0px;
	}
	</style>
	<style type="text/css" id="text_styles_link_viewer" class="text_styles">
	.rmwidget.text div a.link-1 {
		text-decoration: none;
		color: rgb(17, 90, 127);
		background: none;
	}
	
	.rmwidget.text div a.hovered.link-1 {
		text-decoration: none;
		color: rgb(17, 90, 127);
		background: none;
	}
	
	.rmwidget.text div a.link-1 * {
		color: inherit !important;
		text-decoration: none !important;
	}
	
	.rmwidget.text div a.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 {
		text-decoration: none;
		color: rgb(0, 120, 255);
		padding-bottom: 1px;
		background: linear-gradient(to right, rgb(0, 120, 255) 0%, rgb(0, 120, 255) 100%);
		background-size: 1px 1px;
		background-position: 0 100%;
		background-repeat: repeat-x;
	}
	
	.rmwidget.text div a.current.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 {
		text-decoration: none;
		color: rgb(0, 120, 255);
		background: none;
	}
	
	.rmwidget.text div a.hovered.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 {
		text-decoration: none;
		color: rgb(0, 120, 255);
		background: none;
	}
	
	.rmwidget.text div a.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 * {
		color: inherit !important;
		text-decoration: none !important;
	}
	
	<!-- fadein start -->
	/* Fade-in Effect Css Start Here */
	
	@-webkit-keyframes fadeIn {
		from {
			opacity: 0;
			opacity: 1\9;
			* IE9 only *
		}
		to {
			opacity: 1;
		}
	}
	
	@-moz-keyframes fadeIn {
		from {
			opacity: 0;
			opacity: 1\9;
			* IE9 only *
		}
		to {
			opacity: 1;
		}
	}
	
	@keyframes fadeIn {
		from {
			opacity: 0;
			opacity: 1\9;
			* IE9 only *
		}
		to {
			opacity: 1;
		}
	}
	
	.fade-in {
		opacity: 0;
		/* make things invisible upon start */
		-webkit-animation: fadeIn ease-in 1;
		/* call our keyframe named fadeIn, use animattion ease-in and repeat it only 1 time */
		-moz-animation: fadeIn ease-in 1;
		animation: fadeIn ease-in 1;
		-webkit-animation-fill-mode: forwards;
		/* this makes sure that after animation is done we remain at the last keyframe value (opacity: 1)*/
		-moz-animation-fill-mode: forwards;
		animation-fill-mode: forwards;
		-webkit-animation-duration: 1s;
		-moz-animation-duration: 1s;
		animation-duration: 1s;
	}
	
	.fade-in.one {
		-webkit-animation-delay: 1.5s;
		-moz-animation-delay: 1.5s;
		animation-delay: 1.5s;
	}
	
	.fade-in.two {
		-webkit-animation-delay: 2s;
		-moz-animation-delay: 2s;
		animation-delay: 2s;
	}
	
	.fade-in.three {
		-webkit-animation-delay: 2.5s;
		-moz-animation-delay: 2.5s;
		animation-delay: 2.5s;
	}
	
	.fade-in.four {
		-webkit-animation-delay: 3s;
		-moz-animation-delay: 3s;
		animation-delay: 3s;
	}
	
	.fade-in.five {
		-webkit-animation-delay: 3.8s;
		-moz-animation-delay: 3.8s;
		animation-delay: 3.8s;
	}
	/* Fade-in Css End Here */
	</style>
	<link type="text/css" rel="stylesheet" href="//fonts.googleapis.com/css?family=Source+Sans+Pro:200,200italic,300,300italic,400,400italic,600,600italic,700,700italic,900,900italic%7CRoboto:100,100italic,300,300italic,400,400italic,500,500italic,700,700italic,900,900italic%7CInter:100,200,300,400,500,600,700,800,900&amp;subset=latin,vietnamese,khmer,cyrillic-ext,greek-ext,greek,devanagari,latin-ext,cyrillic" class="fonts" data-id="47e7703f-0b14-4fc4-9530-75a3eb374b1f" data-provider="google" data-fonts-and-variations="Source Sans Pro|n2||Source Sans Pro|i2||Source Sans Pro|n3||Source Sans Pro|i3||Source Sans Pro|n4||Source Sans Pro|i4||Source Sans Pro|n6||Source Sans Pro|i6||Source Sans Pro|n7||Source Sans Pro|i7||Source Sans Pro|n9||Source Sans Pro|i9||Roboto|n1||Roboto|i1||Roboto|n3||Roboto|i3||Roboto|n4||Roboto|i4||Roboto|n5||Roboto|i5||Roboto|n7||Roboto|i7||Roboto|n9||Roboto|i9||Inter|n1||Inter|n2||Inter|n3||Inter|n4||Inter|n5||Inter|n6||Inter|n7||Inter|n8||Inter|n9">
	<style type="text/css" id="individual_button_style_61b28f107babaf00210912cc_viewer" class="button_styles">
	.rmwidget.widget-button .common-button[data-id="61b28f107babaf00210912cc"] {
		background-color: rgb(51, 102, 153);
		border-radius: 7px;
		border-width: 0px;
		border-color: rgb(0, 0, 0);
		font-family: Roboto;
		font-weight: 400;
		font-style: normal;
		color: rgb(255, 255, 255);
		font-size: 18px;
		letter-spacing: 0px;
	}
	
	.rmwidget.widget-button .common-button[data-id="61b28f107babaf00210912cc"] .icon {
		background-image: url("https://d3n32ilufxuvd1.cloudfront.net/56969df1bd02a4a3292a2178/61b28f107babaf0021091253/upload-5ae5fa8d-a97c-494f-844a-0de38655d652.png");
	}
	
	.rmwidget.widget-button .common-button[data-id="61b28f107babaf00210912cc"].current {
		background-color: rgb(0, 120, 255);
		border-radius: 5px;
		border-width: 0px;
		border-color: rgb(0, 0, 0);
		font-family: Arial;
		font-weight: 400;
		font-style: normal;
		color: rgb(255, 255, 255);
		font-size: 18px;
		letter-spacing: 0px;
	}
	
	.rmwidget.widget-button .common-button[data-id="61b28f107babaf00210912cc"].current .icon {
		background-image: url("https://rm-content.s3.amazonaws.com/56969df1bd02a4a3292a2178/1215691/upload-57c95040-e439-11e8-854a-65e6af600376.png");
	}
	
	.maglink.current .widget-button .common-button[data-id="61b28f107babaf00210912cc"] .icon {
		background-image: url("https://rm-content.s3.amazonaws.com/56969df1bd02a4a3292a2178/1215691/upload-57c95040-e439-11e8-854a-65e6af600376.png");
	}
	
	.rmwidget.widget-button .common-button[data-id="61b28f107babaf00210912cc"].hovered {
		background-color: rgb(255, 153, 102);
		border-radius: 7px;
		border-width: 0px;
		border-color: rgb(255, 255, 255);
		font-family: Roboto;
		font-weight: 400;
		font-style: normal;
		color: rgb(255, 255, 255);
		font-size: 18px;
		letter-spacing: 0px;
	}
	
	.rmwidget.widget-button .common-button[data-id="61b28f107babaf00210912cc"].hovered .icon {
		background-image: url("https://d3n32ilufxuvd1.cloudfront.net/56969df1bd02a4a3292a2178/1436526/upload-b5bf4442-b734-41e7-be90-a3528c445a55.png");
	}
	
	.btn-responsive {
		color: white;
		background-color: rgb(0, 118, 206);
		font-family: 'Roboto', sans-serif script=all rev=1;
		font-size: 18px;
		padding-left: 7px;
		padding-right: 7px;
		white-space: normal !important;
		word-wrap: break-word;
	}
	
	.btn-responsive:hover {
		color: white;
		background-color: rgb(230, 173, 59);
	}
	#scollbar::-webkit-scrollbar {
  display: none;
   -ms-overflow-style: none;  /* IE and Edge */
  scrollbar-width: none;  /* Firefox */
}

	</style>
	<style type="text/css" class="typekit-kit fonts" data-id="8d1ca34a-a66f-4b78-bdc7-cb2919dab36f" data-provider="typekit" data-fonts-and-variations="flqd|n3||flqd|i3||flqd|n4||flqd|i4||flqd|n7||flqd|i7">
	@font-face {
		font-family: flqd;
		src: url(https://use.typekit.net/af/ea559d/00000000000000007735a08d/30/l?subset_id=1&fvd=n4&v=3) format("woff2"), url(https://use.typekit.net/af/ea559d/00000000000000007735a08d/30/d?subset_id=1&fvd=n4&v=3) format("woff"), url(https://use.typekit.net/af/ea559d/00000000000000007735a08d/30/a?subset_id=1&fvd=n4&v=3) format("opentype");
		font-weight: 400;
		font-style: normal;
		font-display: auto;
	}
	</style>
	<style data-styled="active" data-styled-version="5.3.0"></style>
</head>

<body>
	<div id="root"></div>
	<div id="mags">
		<div class="mag viewer-type-horizontal pages-pos-overlap" style="overflow-y: visible; scrollbar-width: none; -ms-overflow-style: none; background: #E8F9F8;" id="scollbar">

			<div class="" style="background: #E8F9F8;">
				<div class="container">
					<div class="blackout"></div>
					<div class="page hidden prev-page">
						<div id="page-1-password-container" class="polyfill-sticky"></div>
						<div class="page-fixed-bg-container polyfill-sticky"></div>
						<div class="fixed-position-container-top polyfill-sticky"></div>
						<div class="fixed-position-container polyfill-sticky"></div>
						<div class="content-scroll-wrapper has-vertical-scroll">
							<div class="content-bounds">
								<div class="page-content-container" tabindex="-1"></div>
							</div>
						</div>
					</div>
					<div class="page prev-page neighbour hidden">
						<div id="page-2-password-container" class="polyfill-sticky"></div>
						<div class="page-fixed-bg-container polyfill-sticky">
							<div class="rmwidget widget-background" style="background-color: #E8F9F8"> </div>
						</div>
						<div class="fixed-position-container-top polyfill-sticky"></div>
						<div class="fixed-position-container polyfill-sticky"></div>
						<div class="content-scroll-wrapper " style="width:2000px">
						<div class="content-bounds" style="width: 100%; height: auto;position:absolute">

								<div class="page-content-container" tabindex="-1" style="width: 1024px; height: auto; top: 0px; margin: 0 auto;position:relative">

									
									
									
									<div class="page last center-page neighbour">
						<div id="page-3-password-container" class="polyfill-sticky"></div>
						<div class="page-fixed-bg-container polyfill-sticky">
							<div class="rmwidget widget-background" style="background-color: #E8F9F8"> </div>
						</div>
						<div class="fixed-position-container-top polyfill-sticky"></div>
						<div class="fixed-position-container polyfill-sticky"></div>
						<div class="content-scroll-wrapper has-vertical-scroll accelerated-scroll" style="width:2000px">
							<div class="content-bounds" style="width: 1600px; height: 1633px;">
								<div class="page-content-container" tabindex="-1" style="width: 1024px; height: 1633px; top: 0px; left: 230px;">
									<div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 65px; top: 484px; width: 895px; height: 761px; z-index: 301;">
										<style>
										@keyframes animation_15_1 {
											0%,
											60.97560975609757% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 0;
												animation-timing-function: ease-out
											}
											100% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 1;
											}
										}
										</style>
										<div class="rmwidget widget-form fade-in four" data-id="61b28f107babaf00210912b4" style="left: 0px; top: -90px; width: 895px; height: 761px; z-index: 301;">
											<div class="form-wrapper common-form" data-layout="vertical" data-style="colored">
												<form action="form1-sendmail.php" method="POST" target="form_submit_iframe">
													<!--XXX ... DON'T CHANGE THIS CODE ... XXX-->
													<input type="hidden" name="action" id="action" value="insert" />
													<input type="hidden" name="camp_id" id="camp_id" value="LP-ServiceNow-ITSM-Upsell-Pro-CS-Lead-Engage" />
													<input type="hidden" name="firstform" id="firstform" value="" />
													<!--XXX ... DON'T CHANGE THIS CODE ... XXX-->
													<div class="input-wrapper js-input-wrapper" style="height: 52px; width: 895px; margin-bottom: 8px; background-color: rgb(255, 255, 255); border-radius: 0px; box-shadow: rgb(0, 0, 0) 0px 0px 0px 0px inset;">
														<input class="js-input" type="text" autocapitalize="on" autocomplete="off" autocorrect="off" name="fname" required placeholder="First Name" spellcheck="false" data-sort="0" style="font-family: Roboto; font-style: normal; font-weight: 400; color: rgb(0, 0, 0); font-size: 14px; letter-spacing: 0px; margin-bottom: 0px;">
														<div class="overlay"></div>
													</div>
													
													<div class="input-wrapper js-input-wrapper" style="height: 52px; width: 895px; margin-bottom: 8px; background-color: rgb(255, 255, 255); border-radius: 0px; box-shadow: rgb(0, 0, 0) 0px 0px 0px 0px inset;">
														<input class="js-input" type="text" autocapitalize="on" autocomplete="off" autocorrect="off" name="data[]" required placeholder="Last Name" spellcheck="false" data-sort="0" style="font-family: Roboto; font-style: normal; font-weight: 400; color: rgb(0, 0, 0); font-size: 14px; letter-spacing: 0px; margin-bottom: 0px;">
														<div class="overlay"></div>
													</div>
													
													<div class="input-wrapper js-input-wrapper" style="height: 52px; width: 895px; margin-bottom: 8px; background-color: rgb(255, 255, 255); border-radius: 0px; box-shadow: rgb(0, 0, 0) 0px 0px 0px 0px inset;">
														<input class="js-input" type="text" autocapitalize="off" autocomplete="off" autocorrect="off" name="data[1]" required placeholder="Email" spellcheck="false" data-sort="1" inputmode="email" style="font-family: Roboto; font-style: normal; font-weight: 400; color: rgb(0, 0, 0); font-size: 14px; letter-spacing: 0px; margin-bottom: 0px;">
														<div class="overlay"></div>
													</div>
													<div class="input-wrapper js-input-wrapper" style="height: 51px; width: 895px; margin-bottom: 8px; background-color: rgb(255, 255, 255); border-radius: 0px; box-shadow: rgb(0, 0, 0) 0px 0px 0px 0px inset;">
														<input class="js-input" type="text" autocapitalize="off" autocomplete="off" autocorrect="off" name="data[2]" required placeholder="Phone number" spellcheck="false" data-sort="2" inputmode="tel" style="font-family: Roboto; font-style: normal; font-weight: 400; color: rgb(0, 0, 0); font-size: 14px; letter-spacing: 0px; margin-bottom: 0px;">
														<div class="overlay"></div>
													</div>
													<div class="input-wrapper js-input-wrapper" style="height: 51px; width: 895px; margin-bottom: 8px; background-color: rgb(255, 255, 255); border-radius: 0px; box-shadow: rgb(0, 0, 0) 0px 0px 0px 0px inset;">
														<textarea class="js-input" type="text" autocapitalize="off" autocomplete="off" autocorrect="off" name="data[3]" required placeholder="Title" spellcheck="false" data-sort="3" rows="1" style="top: 16px; bottom: 18px; font-family: Roboto; font-style: normal; font-weight: 400; color: rgb(0, 0, 0); font-size: 14px; letter-spacing: 0px; margin-bottom: 0px;"></textarea>
														<div class="overlay"></div>
													</div>
													<div class="input-wrapper js-input-wrapper" style="height: 51px; width: 895px; margin-bottom: 8px; background-color: rgb(255, 255, 255); border-radius: 0px; box-shadow: rgb(0, 0, 0) 0px 0px 0px 0px inset;">
														<textarea class="js-input" type="text" autocapitalize="off" autocomplete="off" autocorrect="off" name="data[4]" required placeholder="Company" spellcheck="false" data-sort="4" rows="1" style="top: 16px; bottom: 18px; font-family: Roboto; font-style: normal; font-weight: 400; color: rgb(0, 0, 0); font-size: 14px; letter-spacing: 0px; margin-bottom: 0px;"></textarea>
														<div class="overlay"></div>
													</div>
													<div class="input-wrapper js-input-wrapper" style="height: 51px; width: 895px; margin-bottom: 8px; background-color: rgb(255, 255, 255); border-radius: 0px; box-shadow: rgb(0, 0, 0) 0px 0px 0px 0px inset;">
														<textarea class="js-input" type="text" autocapitalize="off" autocomplete="off" autocorrect="off" name="data[5]" required placeholder="Street address" spellcheck="false" data-sort="5" rows="1" style="top: 16px; bottom: 18px; font-family: Roboto; font-style: normal; font-weight: 400; color: rgb(0, 0, 0); font-size: 14px; letter-spacing: 0px; margin-bottom: 0px;"></textarea>
														<div class="overlay"></div>
													</div>
													<div class="input-wrapper js-input-wrapper" style="height: 51px; width: 895px; margin-bottom: 8px; background-color: rgb(255, 255, 255); border-radius: 0px; box-shadow: rgb(0, 0, 0) 0px 0px 0px 0px inset;">
														<textarea class="js-input" type="text" autocapitalize="off" autocomplete="off" autocorrect="off" name="data[6]" required placeholder="City" spellcheck="false" data-sort="6" rows="1" style="top: 16px; bottom: 18px; font-family: Roboto; font-style: normal; font-weight: 400; color: rgb(0, 0, 0); font-size: 14px; letter-spacing: 0px; margin-bottom: 0px;"></textarea>
														<div class="overlay"></div>
													</div>
													<div class="input-wrapper js-input-wrapper" style="height: 51px; width: 895px; margin-bottom: 8px; background-color: rgb(255, 255, 255); border-radius: 0px; box-shadow: rgb(0, 0, 0) 0px 0px 0px 0px inset;">
														<textarea class="js-input" type="text" autocapitalize="off" autocomplete="off" autocorrect="off" required name="data[7]" placeholder="ZIP Code" spellcheck="false" data-sort="7" rows="1" style="top: 16px; bottom: 18px; font-family: Roboto; font-style: normal; font-weight: 400; color: rgb(0, 0, 0); font-size: 14px; letter-spacing: 0px; margin-bottom: 0px;"></textarea>
														<div class="overlay"></div>
													</div>
													<div class="input-wrapper js-input-wrapper" style="height: 51px; width: 895px; margin-bottom: 8px; background-color: rgb(255, 255, 255); border-radius: 0px; box-shadow: rgb(0, 0, 0) 0px 0px 0px 0px inset;">
														<textarea class="js-input" type="text" autocapitalize="off" autocomplete="off" autocorrect="off" name="data[8]" required placeholder="State" spellcheck="false" data-sort="8" rows="1" style="top: 16px; bottom: 18px; font-family: Roboto; font-style: normal; font-weight: 400; color: rgb(0, 0, 0); font-size: 14px; letter-spacing: 0px; margin-bottom: 0px;"></textarea>
														<div class="overlay"></div>
													</div>
													<select name="Company size" style="height: 51px; width: 895px; margin-bottom: 8px; background-color: rgb(255, 255, 255); font-family: Roboto; font-style: normal; font-weight: 400; color: rgb(174 165 165); font-size: 14px;text-indent: 15px; border: none; ">
														<option value="" disabled="" selected="" style=""> Country</option>
														<option id="form_046a_fld_11-0" value="US">Afghanistan</option>
														<option id="form_046a_fld_11-1" value="US">Albania</option>
														<option id="form_046a_fld_11-2" value="US">Algeria</option>
														<option id="form_046a_fld_11-3" value="US">American Samoa</option>
														<option id="form_046a_fld_11-4" value="US">Andorra</option>
														<option id="form_046a_fld_11-5" value="US">Angola</option>
														<option id="form_046a_fld_11-6" value="US">Anguilla</option>
														<option id="form_046a_fld_11-7" value="US">Antarctica</option>
														<option id="form_046a_fld_11-8" value="US">Antigua and Barbuda</option>
														<option id="form_046a_fld_11-9" value="US">Argentina</option>
														<option id="form_046a_fld_11-10" value="US">Armenia</option>
														<option id="form_046a_fld_11-11" value="US">Aruba</option>
														<option id="Australia" value="US">Australia</option>
														<option id="form_046a_fld_11-14" value="US">Azerbaijan</option>
														<option id="form_046a_fld_11-15" value="US">Bahamas</option>
														<option id="form_046a_fld_11-16" value="US">Bahrain</option>
														<option id="form_046a_fld_11-17" value="US">Bangladesh</option>
														<option id="form_046a_fld_11-18" value="US">Barbados</option>
														<option id="form_046a_fld_11-19" value="US">Belarus</option>
														<option id="form_046a_fld_11-20" value="US">Belgium</option>
														<option id="form_046a_fld_11-21" value="US">Belize</option>
														<option id="form_046a_fld_11-22" value="US">Benin</option>
														<option id="form_046a_fld_11-23" value="US">Bermuda</option>
														<option id="form_046a_fld_11-24" value="US">Bhutan</option>
														<option id="form_046a_fld_11-25" value="US">Bolivia</option>
														<option id="form_046a_fld_11-26" value="US">Bonaire</option>
														<option id="form_046a_fld_11-27" value="US">Bosnia</option>
														<option id="form_046a_fld_11-28" value="US">Botswana</option>
														<option id="form_046a_fld_11-29" value="US">Bouvet Island</option>
														<option id="form_046a_fld_11-30" value="US">Brazil</option>
														<option id="form_046a_fld_11-31" value="US">British Indian Ocean Territory</option>
														<option id="form_046a_fld_11-32" value="US">Brunei</option>
														<option id="form_046a_fld_11-34" value="US">Burkina Faso</option>
														<option id="form_046a_fld_11-35" value="US">Burundi</option>
														<option id="form_046a_fld_11-36" value="US">Cambodia</option>
														<option id="form_046a_fld_11-37" value="US">Cameroon</option>
														<option id="form_046a_fld_11-38" value="US">Canada</option>
														<option id="form_046a_fld_11-39" value="US">Cape Verde</option>
														<option id="form_046a_fld_11-40" value="US">Cayman Islands</option>
														<option id="form_046a_fld_11-41" value="US">Central African Republic</option>
														<option id="form_046a_fld_11-42" value="US">Chad</option>
														<option id="form_046a_fld_11-43" value="US">Chile</option>
														<option id="form_046a_fld_11-44" value="US">China</option>
														<option id="form_046a_fld_11-45" value="US">Christmas Island</option>
														<option id="form_046a_fld_11-46" value="US">Cocos Islands</option>
														<option id="form_046a_fld_11-47" value="US">Colombia</option>
														<option id="form_046a_fld_11-48" value="US">Comoros</option>
														<option id="form_046a_fld_11-49" value="US">Congo</option>
														<option id="form_046a_fld_11-50" value="US">Congo, Dem. Rep.</option>
														<option id="form_046a_fld_11-51" value="US">Cook Islands</option>
														<option id="form_046a_fld_11-52" value="US">Costa Rica</option>
														<option id="form_046a_fld_11-54" value="US">Cuba</option>
														<option id="form_046a_fld_11-55" value="US">CuraÃ§ao</option>
														<option id="form_046a_fld_11-59" value="US">Djibouti</option>
														<option id="form_046a_fld_11-60" value="US">Dominica</option>
														<option id="form_046a_fld_11-61" value="US">Dominican Republic</option>
														<option id="form_046a_fld_11-62" value="US">Ecuador</option>
														<option id="form_046a_fld_11-63" value="US">Egypt</option>
														<option id="form_046a_fld_11-64" value="US">El Salvador</option>
														<option id="form_046a_fld_11-65" value="US">Equatorial Guinea</option>
														<option id="form_046a_fld_11-66" value="US">Eritrea</option>
														<option id="form_046a_fld_11-68" value="US">Ethiopia</option>
														<option id="form_046a_fld_11-69" value="US">Falkland Islands (Malvinas)</option>
														<option id="form_046a_fld_11-70" value="US">Faroe Islands</option>
														<option id="form_046a_fld_11-71" value="US">Fiji</option>
														<option id="form_046a_fld_11-74" value="US">French Guiana</option>
														<option id="form_046a_fld_11-75" value="US">French Polynesia</option>
														<option id="form_046a_fld_11-76" value="US">French Southern Territories</option>
														<option id="form_046a_fld_11-77" value="US">Gabon</option>
														<option id="form_046a_fld_11-78" value="US">Gambia</option>
														<option id="form_046a_fld_11-79" value="US">Georgia</option>
														<option id="form_046a_fld_11-81" value="US">Ghana</option>
														<option id="form_046a_fld_11-82" value="US">Gibraltar</option>
														<option id="form_046a_fld_11-84" value="US">Greenland</option>
														<option id="form_046a_fld_11-85" value="US">Grenada</option>
														<option id="form_046a_fld_11-86" value="US">Guadeloupe</option>
														<option id="form_046a_fld_11-87" value="US">Guam</option>
														<option id="form_046a_fld_11-88" value="US">Guatemala</option>
														<option id="form_046a_fld_11-89" value="US">Guernsey</option>
														<option id="form_046a_fld_11-90" value="US">Guinea</option>
														<option id="form_046a_fld_11-91" value="US">Guinea-Bissau</option>
														<option id="form_046a_fld_11-92" value="US">Guyana</option>
														<option id="form_046a_fld_11-93" value="US">Haiti</option>
														<option id="form_046a_fld_11-94" value="US">Heard Island</option>
														<option id="form_046a_fld_11-95" value="US">Honduras</option>
														<option id="form_046a_fld_11-96" value="US">Hong Kong</option>
														<option id="form_046a_fld_11-98" value="US">Iceland</option>
														<option id="form_046a_fld_11-99" value="US">India</option>
														<option id="form_046a_fld_11-100" value="US">Indonesia</option>
														<option id="form_046a_fld_11-101" value="US">Iran</option>
														<option id="form_046a_fld_11-102" value="US">Iraq</option>
														<option id="form_046a_fld_11-104" value="US">Isle of Man</option>
														<option id="form_046a_fld_11-105" value="US">Israel</option>
														<option id="form_046a_fld_11-107" value="US">Ivory Coast</option>
														<option id="form_046a_fld_11-108" value="US">Jamaica</option>
														<option id="form_046a_fld_11-109" value="US">Japan</option>
														<option id="form_046a_fld_11-110" value="US">Jersey</option>
														<option id="form_046a_fld_11-111" value="US">Jordan</option>
														<option id="form_046a_fld_11-112" value="US">Kazakhstan</option>
														<option id="form_046a_fld_11-113" value="US">Kenya</option>
														<option id="form_046a_fld_11-114" value="US">Kiribati</option>
														<option id="form_046a_fld_11-115" value="US">Korea</option>
														<option id="form_046a_fld_11-116" value="US">Korea, DPRK</option>
														<option id="form_046a_fld_11-117" value="US">Kuwait</option>
														<option id="form_046a_fld_11-118" value="US">Kyrgyzstan</option>
														<option id="form_046a_fld_11-119" value="US">Laos</option>
														<option id="form_046a_fld_11-121" value="LB">Lebanon</option>
														<option id="form_046a_fld_11-122" value="US">Lesotho</option>
														<option id="form_046a_fld_11-123" value="US">Liberia</option>
														<option id="form_046a_fld_11-124" value="US">Libya</option>
														<option id="form_046a_fld_11-125" value="US">Liechtenstein</option>
														<option id="form_046a_fld_11-128" value="US">Macao</option>
														<option id="form_046a_fld_11-129" value="US">Macedonia</option>
														<option id="form_046a_fld_11-130" value="US">Madagascar</option>
														<option id="form_046a_fld_11-131" value="US">Malawi</option>
														<option id="form_046a_fld_11-132" value="US">Malaysia</option>
														<option id="form_046a_fld_11-133" value="US">Maldives</option>
														<option id="form_046a_fld_11-134" value="US">Mali</option>
														<option id="form_046a_fld_11-136" value="US">Marshall Islands</option>
														<option id="form_046a_fld_11-137" value="US">Martinique</option>
														<option id="form_046a_fld_11-138" value="US">Mauritania</option>
														<option id="form_046a_fld_11-139" value="US">Mauritius</option>
														<option id="form_046a_fld_11-140" value="US">Mayotte</option>
														<option id="form_046a_fld_11-141" value="US">Mexico</option>
														<option id="form_046a_fld_11-142" value="US">Micronesia, Fed.</option>
														<option id="form_046a_fld_11-143" value="US">Moldova</option>
														<option id="form_046a_fld_11-144" value="US">Monaco</option>
														<option id="form_046a_fld_11-145" value="US">Mongolia</option>
														<option id="form_046a_fld_11-146" value="US">Montenegro</option>
														<option id="form_046a_fld_11-147" value="US">Montserrat</option>
														<option id="form_046a_fld_11-148" value="US">Morocco</option>
														<option id="form_046a_fld_11-149" value="US">Mozambique</option>
														<option id="form_046a_fld_11-150" value="US">Myanmar</option>
														<option id="form_046a_fld_11-151" value="US">Namibia</option>
														<option id="form_046a_fld_11-152" value="US">Nauru</option>
														<option id="form_046a_fld_11-153" value="US">Nepal</option>
														<option id="form_046a_fld_11-154" value="US">Netherlands</option>
														<option id="form_046a_fld_11-155" value="US">New Caledonia</option>
														<option id="form_046a_fld_11-156" value="US">New Zealand</option>
														<option id="form_046a_fld_11-157" value="US">Nicaragua</option>
														<option id="form_046a_fld_11-158" value="US">Niger</option>
														<option id="form_046a_fld_11-159" value="US">Nigeria</option>
														<option id="form_046a_fld_11-160" value="US">Niue</option>
														<option id="form_046a_fld_11-161" value="US">Norfolk Island</option>
														<option id="form_046a_fld_11-162" value="US">Northern Marianas</option>
														<option id="form_046a_fld_11-163" value="US">Norway</option>
														<option id="form_046a_fld_11-164" value="US">Oman</option>
														<option id="form_046a_fld_11-165" value="US">Pakistan</option>
														<option id="form_046a_fld_11-166" value="US">Palau</option>
														<option id="form_046a_fld_11-167" value="US">Palestinian Terr.</option>
														<option id="form_046a_fld_11-168" value="US">Panama</option>
														<option id="form_046a_fld_11-169" value="US">Papua New Guinea</option>
														<option id="form_046a_fld_11-170" value="US">Paraguay</option>
														<option id="form_046a_fld_11-171" value="US">Peru</option>
														<option id="form_046a_fld_11-172" value="US">Philippines</option>
														<option id="form_046a_fld_11-173" value="US">Pitcairn</option>
														<option id="form_046a_fld_11-176" value="US">Puerto Rico</option>
														<option id="form_046a_fld_11-177" value="US">Qatar</option>
														<option id="form_046a_fld_11-179" value="US">Russia</option>
														<option id="form_046a_fld_11-180" value="US">Rwanda</option>
														<option id="form_046a_fld_11-181" value="US">RÃ©union</option>
														<option id="form_046a_fld_11-182" value="US">Saint BarthÃ©lemy</option>
														<option id="form_046a_fld_11-183" value="US">Saint Helena</option>
														<option id="form_046a_fld_11-184" value="US">Saint Kitts and Nevis</option>
														<option id="form_046a_fld_11-185" value="US">Saint Lucia</option>
														<option id="form_046a_fld_11-186" value="US">Saint Martin (French)</option>
														<option id="form_046a_fld_11-187" value="US">Saint Pierre and Miquelon</option>
														<option id="form_046a_fld_11-188" value="US">Saint Vincent</option>
														<option id="form_046a_fld_11-189" value="US">Samoa</option>
														<option id="form_046a_fld_11-190" value="US">San Marino</option>
														<option id="form_046a_fld_11-191" value="US">Sao Tome &amp; Principe</option>
														<option id="form_046a_fld_11-192" value="US">Saudi Arabia</option>
														<option id="form_046a_fld_11-193" value="US">Senegal</option>
														<option id="form_046a_fld_11-194" value="US">Serbia</option>
														<option id="form_046a_fld_11-195" value="US">Seychelles</option>
														<option id="form_046a_fld_11-196" value="US">Sierra Leone</option>
														<option id="form_046a_fld_11-197" value="US">Singapore</option>
														<option id="form_046a_fld_11-198" value="US">Sint Maarten (Dutch)</option>
														<option id="form_046a_fld_11-201" value="US">Solomon Islands</option>
														<option id="form_046a_fld_11-202" value="US">Somalia</option>
														<option id="form_046a_fld_11-203" value="US">South Africa</option>
														<option id="form_046a_fld_11-204" value="US">South Georgia and the South Sandwich Islands</option>
														<option id="form_046a_fld_11-205" value="US">South Sudan</option>
														<option id="form_046a_fld_11-208" value="US">Sudan</option>
														<option id="form_046a_fld_11-209" value="US">Suriname</option>
														<option id="form_046a_fld_11-210" value="US">Svalbard</option>
														<option id="form_046a_fld_11-211" value="US">Swaziland</option>
														<option id="form_046a_fld_11-213" value="US">Switzerland</option>
														<option id="form_046a_fld_11-214" value="US">Syria</option>
														<option id="form_046a_fld_11-215" value="US">Taiwan</option>
														<option id="form_046a_fld_11-216" value="US">Tajikistan</option>
														<option id="form_046a_fld_11-217" value="US">Tanzania</option>
														<option id="form_046a_fld_11-218" value="US">Thailand</option>
														<option id="form_046a_fld_11-219" value="US">Timor-Leste</option>
														<option id="form_046a_fld_11-220" value="US">Togo</option>
														<option id="form_046a_fld_11-221" value="US">Tokelau</option>
														<option id="form_046a_fld_11-222" value="US">Tonga</option>
														<option id="form_046a_fld_11-223" value="US">Trinidad and Tobago</option>
														<option id="form_046a_fld_11-224" value="US">Tunisia</option>
														<option id="form_046a_fld_11-225" value="US">Turkey</option>
														<option id="form_046a_fld_11-226" value="US">Turkmenistan</option>
														<option id="form_046a_fld_11-227" value="US">Turks and Caicos</option>
														<option id="form_046a_fld_11-228" value="US">Tuvalu</option>
														<option id="form_046a_fld_11-229" value="US">U.A.E.</option>
														<option id="form_046a_fld_11-230" value="US">Uganda</option>
														<option id="form_046a_fld_11-231" value="US">Ukraine</option>
														<option id="form_046a_fld_11-232" value="US">United Kingdom</option>
														<option id="form_046a_fld_11-233" value="US">United States</option>
														<option id="form_046a_fld_11-234" value="US">United States Minor Outlying Islands</option>
														<option id="form_046a_fld_11-235" value="US">Uruguay</option>
														<option id="form_046a_fld_11-236" value="US">Uzbekistan</option>
														<option id="form_046a_fld_11-237" value="US">Vanuatu</option>
														<option id="form_046a_fld_11-238" value="US">Vatican City</option>
														<option id="form_046a_fld_11-239" value="US">Venezuela</option>
														<option id="form_046a_fld_11-240" value="US">Viet Nam</option>
														<option id="form_046a_fld_11-241" value="US">Virgin Islands, British</option>
														<option id="form_046a_fld_11-242" value="US">Virgin Islands, U.S.</option>
														<option id="form_046a_fld_11-243" value="US">Wallis and Futuna</option>
														<option id="form_046a_fld_11-244" value="US">Western Sahara</option>
														<option id="form_046a_fld_11-245" value="US">Yemen</option>
														<option id="form_046a_fld_11-246" value="US">Zambia</option>
														<option id="form_046a_fld_11-247" value="US">Zimbabwe</option>
														<option id="form_046a_fld_11-248" value="US">Åland Islands</option>
													</select>
													<div class="input-wrapper js-input-wrapper" style="height: 51px; width: 895px; margin-bottom: 8px; background-color: rgb(255, 255, 255); border-radius: 0px; box-shadow: rgb(0, 0, 0) 0px 0px 0px 0px inset;">
														<textarea class="js-input" type="text" autocapitalize="off" autocomplete="off" autocorrect="off" name="data[9]" placeholder="Industry" spellcheck="false" data-sort="8" rows="1" style="top: 16px; bottom: 18px; font-family: Roboto; font-style: normal; font-weight: 400; color: rgb(0, 0, 0); font-size: 14px; letter-spacing: 0px; margin-bottom: 0px;"></textarea>
														<div class="overlay"></div>
													</div>
													<select name="Company size" style="height: 51px; width: 895px; margin-bottom: 8px; background-color: rgb(255, 255, 255); font-family: Roboto; font-style: normal; font-weight: 400; color: rgb(174 165 165); font-size: 14px;text-indent: 15px; border: none; ">
														<option value="" disabled="" selected="" style=""> Company Size</option>
														<option value="1-25">1-25</option>
														<option value="26-99">26-99</option>
														<option value="100-499">100-499</option>
														<option value="500-999">500-999</option>
														<option value="1000-4999">1000-4999</option>
														<option value="5000+">5000+</option>
													</select>
													
													<select name="Purchase Timeframe" style="height: 51px; width: 895px; margin-bottom: 8px; background-color: rgb(255, 255, 255); font-family: Roboto; font-style: normal; font-weight: 400; color: rgb(174 165 165); font-size: 14px;text-indent: 15px; border: none; ">
														<option value="" disabled="" selected="" style=""> Purchase Timeframe</option>
														<option value="Immediately">Immediately</option>
<option value="1-6 months">1-6 months</option>
<option value="7-12 months">7-12 months</option>
<option value="13-24+ months">13-24+ months</option>
<option value="Undecided">Undecided</option>

													</select>
													<select name="cust1" style="height: 51px; width: 895px; margin-bottom: 8px; background-color: rgb(255, 255, 255); font-family: Roboto; font-style: normal; font-weight: 400; color: rgb(174 165 165); font-size: 14px;text-indent: 15px; border: none; ">
														<option value="" disabled="" selected="" style=""> Which of the following topics are you interested in learning more about from a Dell Technologies  expert?</option>
														<option value="Solutions for desk-centric and in-office workers">Solutions for desk-centric and in-office workers</option>
														<option value="Solutions for on-the-go professionals and executives">Solutions for on-the-go professionals and executives</option>
														<option value="Solutions for remote workers">Solutions for remote workers</option>
														<option value="Solutions for specialty workers, like field workers, creatives, and engineers">Solutions for specialty workers, like field workers, creatives, and engineers</option>
														<option value="Solutions with security, software, and services">Solutions with security, software, and services</option>
														<option value="Dell Technologies infrastructure solutions (server, storage, HCI, data protection)">Dell Technologies infrastructure solutions (server, storage, HCI, data protection)</option>
														<option value="None at this time">None at this time</option>
													</select>
													<div class="checkbox">
														<div style="margin-left:25px;">
															<input type="checkbox" name="std6" style="top: 21px; position: relative; left: -20px;color:#444444;">
															<p style="line-height: 25px;padding-bottom:0;text-align: inherit;" class="view-mode unstyled align-center"><span style="font-family:Roboto;font-weight:400;font-style:normal;font-size:14px;color:rgba(97, 74, 90, 1)">	Yes, please stay in touch by email, phone and post. <a href="https://i.dell.com/sites/doccontent/legal/terms-conditions/en/Documents/Dell-Technologies-List-for-Privacy-Statement-May-2018.pdf">Dell Technologies and its group of companies</a> would love to keep you updated on products, services, solutions, exclusive offers and special events. For information on how Dell Technologies' uses and protections your personal data, see our <a href="https://www.dell.com/learn/us/en/uscorp1/policies-privacy">Privacy Statement</a>. You can unsubscribe at any time.</span></p>	</span> </div>
													</div>
													<input class="btn btn-block btn-responsive" style="position: relative;top: 5px;width: 896px;left: 14px;height: 54px;font-family: Roboto;font-style: normal;font-weight: 400;font-size: 18px;margin-left: -13px;padding: 0 20px; text-align: inherit;border: none;" id="formSubmit" name="commit" type="submit" value="DOWNLOAD NOW"> </form>
											</div>
										</div>
									</div>
									<div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 383px; top: 89px; width: 705px; height: 453px; z-index: 302;">
										<style>
										@keyframes animation_16_1 {
											0%,
											55.55555555555556% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 0;
												animation-timing-function: ease-out
											}
											100% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 1;
											}
										}
										</style>
										<div class="rmwidget widget-text-v3 fade-in two" data-id="61b28f107babaf00210912b5" style="left: 0px; top: 0px; width: 609px; height: 453px; z-index: 302;">
											<div class="Box-sc-n41d2v-0 TextBase___StyledBox-sc-1o28pgm-0 jXOqqG kKESck">
												<div class="text-viewer">
													<p style="line-height:24px;padding-left:0;padding-bottom:0" class="view-mode unstyled align-left"><span style="font-size:16px;font-weight:400;font-family:Roboto;font-style:normal;text-decoration:none;text-transform:none;color:rgba(97, 74, 90, 1)">With a more flexible and productive workforce, Digital Workplace Accelerators say they 2.1 more likely to exceed their customer satisfaction goals. IT organizations must take a long-term view of remote user enablement and invest in foundational technologies that will maximize the effectiveness of remote users. <br><br> In this whitepaper, research shows why Digital Workplace Accelerators have:</span></p>
													
													<p style="line-height:24px;padding-left:9px;padding-top:0;padding-bottom:0" class="view-mode unstyled align-left"><span style="font-size:16px;font-weight:300;font-family:Roboto;font-style:normal;text-decoration:none;text-transform:none;color:rgba(97, 74, 90, 1)">•	6.4X higher user satisfaction scores</span></p>
													<p style="line-height:24px;padding-left:9px;padding-top:0;padding-bottom:0" class="view-mode unstyled align-left"><span style="font-size:16px;font-weight:300;font-family:Roboto;font-style:normal;text-decoration:none;text-transform:none;color:rgba(97, 74, 90, 1)">• 42% reduction in costs via tool consolidation</span></p>
													<p style="line-height:24px;padding-left:9px;padding-top:0;padding-bottom:0" class="view-mode unstyled align-left"><span style="font-size:16px;font-weight:300;font-family:Roboto;font-style:normal;text-decoration:none;text-transform:none;color:rgba(97, 74, 90, 1)">• 2.6 larger increase in productivity </span></p>
													
													<br>
													<p style="line-height:24px;padding-left:0;padding-right:112px;padding-top:2px;padding-bottom:0;font-size:24px;" class="view-mode unstyled align-left"><span style="font-size:16px;font-weight:400;font-family:Roboto;font-style:normal;text-decoration:none;text-transform:none;color:rgba(97, 74, 90, 1)">Download this whitepaper provided by Dell Technologies and Intel&#174; to learn more.</span></p>
												</div>
											</div>
										</div>
									</div>
									<div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 36px; top: 16px; width: 786px; height: 50px; z-index: 303;">
										<style>
										@keyframes animation_17_1 {
											0%,
											33.33333333333333% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 0;
												animation-timing-function: ease-out
											}
											100% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 1;
											}
										}
										</style>
										<div class="rmwidget widget-text-v3 fade-in one" data-id="61b28f107babaf00210912b6" style="left: 0px; top: 0px; width: 786px; height: 50px; z-index: 303;">
											<div class="Box-sc-n41d2v-0 TextBase___StyledBox-sc-1o28pgm-0 jXOqqG kKESck">
												<div class="text-viewer">
													<p style="line-height:45px" class="view-mode unstyled align-left"><span style="font-size:31px;font-weight:300;font-family:Roboto;font-style:normal;text-decoration:none;text-transform:none;color:rgba(97, 74, 90, 1);">Innovation Fuels Higher Customer Satisfaction </span></p>
												</div>
											</div>
										</div>
									</div>
									<div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 38px; top: 93px; width: 198.28px; height: 257.38px; z-index: 305;">
										<style>
										@keyframes animation_18_1 {
											0%,
											52.63157894736842% {
												transform: matrix(0.36, 0, 0, 0.36, 0, 0);
												opacity: 0;
												animation-timing-function: ease-out
											}
											100% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 1;
											}
										}
										</style>
										<div class="rmwidget widget-picture fade-in three" data-id="61b28f107babaf00210912b8" style="left: 0px; top: 0px; width: 323.28px; height: 257.38px; z-index: 305;">
											<div class="bgpic" url="https://advance.biz-tech-insights.com/Dell-CSG_Work-Redefined_LE-2/1-Organizations-Accelerating-their-Digital-Workplace.png" style="background-image: url(&quot;https://advance.biz-tech-insights.com/Dell-CSG_Work-Redefined_LE-2/1-Organizations-Accelerating-their-Digital-Workplace.png&quot;); background-position: 50% 50%; box-shadow: rgb(255, 255, 255) 0px 0px 0px 1px inset; border-radius: 0px; opacity: 1;"></div><img srcset="https://advance.biz-tech-insights.com/Dell-CSG_Work-Redefined_LE-2/1-Organizations-Accelerating-their-Digital-Workplace.png 2x, https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3300951/upload-3295a4b7-9656-4302-9253-157db89d7175.png?w=595&amp;e=webp&amp;nll=true&amp;cX=0&amp;cY=34&amp;cW=684&amp;cH=886 3x" src="https://advance.biz-tech-insights.com/Dell-CSG_Work-Redefined_LE-2/1-Organizations-Accelerating-their-Digital-Workplace.png" class="viewable saveable" style="opacity: 1;"></div>
									</div>
									<div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: -3px; top: 1373px; width: 1027px; height: 56px; z-index: 306;">
										<style>
										@keyframes animation_19_1 {
											0%,
											61.904761904761905% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 0;
												animation-timing-function: ease-out
											}
											100% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 1;
											}
										}
										</style>
										<div class="rmwidget widget-text-v3" data-id="61b28f107babaf00210912b9" style="left: 0px; top: 0px; width: 1027px; height: 56px; z-index: 306;">
											<div class="Box-sc-n41d2v-0 TextBase___StyledBox-sc-1o28pgm-0 jXOqqG kKESck">
												<div class="text-viewer">
													<p style="line-height:13px;padding-left:0;padding-bottom:0" class="view-mode unstyled align-center">
														<br>
													</p>
												</div>
											</div>
										</div>
									</div>
									<div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 439px; top: 1380px; width: 137px; height: 83px; z-index: 309;">
										<style>
										@keyframes animation_20_1 {
											0%,
											42.85714285714286% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 0;
												animation-timing-function: ease-out
											}
											100% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 1;
											}
										}
										</style>
										
										
									</div>
									<div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 0px; top: 1465px; width: 1024px; height: 228px; z-index: 305;"><style>@keyframes animation_20_1 {
	0%, 42.85714285714286% {transform: matrix(1,0,0,1,0,0); opacity: 0; animation-timing-function: ease-out}
	100% {transform: matrix(1,0,0,1,0,0); opacity: 1; }
}
</style><div class="rmwidget widget-text-v3" data-id="6204595ca6a4ac0031369492" style="left: 0px; top: 0px; width: 1024px; height: 14px; z-index: 304;"><div class="Box-sc-n41d2v-0 TextBase___StyledBox-sc-1o28pgm-0 jBjUfz fxqkJG"><div class="text-viewer"><p style="line-height:11px;padding-top:0;padding-bottom:0" class="view-mode unstyled align-center"><span style="font-family:Roboto;font-weight:400;font-style:normal;font-size:11px"><span style="color:rgba(255, 255, 255, 1)"><a class="link-5a1abc8a-c29e-44ec-8cc1-19095381f694 external-link" rel="noopener noreferrer" target="_self" href="https://www.dell.com/learn/us/en/22/campaigns/privacy-usdfh">Dell Privacy Policy</a>  </span><span style="color:rgba(97, 74, 90, 1)">I</span><span style="color:rgba(255, 255, 255, 1)">   <a class="link-5a1abc8a-c29e-44ec-8cc1-19095381f694 external-link" rel="noopener noreferrer" target="_self" href="https://www.activatems.com/privacy-policy/">Biz-Tech-Insights Privacy Policy</a></span></span></p></div></div></div>
<div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 426px; top: 37px; width: 171px; height: 57px; z-index: 311;"><style>@keyframes animation_23_1 {
	0%, 42.85714285714286% {transform: matrix(1,0,0,1,0,0); opacity: 0; animation-timing-function: ease-out}
	100% {transform: matrix(1,0,0,1,0,0); opacity: 1; }
}
</style><div class="rmwidget widget-picture" data-id="62052e9edfba5b0030fe4e98" style="left: 0px; top: 0px; width: 171px; height: 22px; z-index: 308;"><img srcset="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3421547/upload-0d0b0100-a286-4cd8-b1e8-ea5e37806ab8.png?w=342&amp;e=webp&amp;nll=true 2x, https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3421547/upload-0d0b0100-a286-4cd8-b1e8-ea5e37806ab8.png?w=513&amp;e=webp&amp;nll=true 3x" src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3421547/upload-0d0b0100-a286-4cd8-b1e8-ea5e37806ab8.png?w=342&amp;e=webp&amp;nll=true" class="viewable" style="opacity: 1;"></div>

<div class="rmwidget widget-picture svg" data-id="62052e9f52ca06002787ee8b" style="left: 54px; top: 40px; width: 63px; height: 26px; z-index: 311;">
<img srcset="https://advance.biz-tech-insights.com/Dell-CSG_Work-Redefined_LE-2/intel-logo.png?w=342&amp;e=webp&amp;nll=true 2x, https://advance.biz-tech-insights.com/Dell-CSG_Work-Redefined_LE-2/intel-logo.png?w=513&amp;e=webp&amp;nll=true 3x" src="https://advance.biz-tech-insights.com/Dell-CSG_Work-Redefined_LE-2/intel-logo.png?w=342&amp;e=webp&amp;nll=true" class="viewable" style="opacity: 1;">


</div></div>

<div class="rmwidget widget-text-v3" data-id="6204595ca6a4ac0031369493" style="left: 446px; top: 125px; width: 130px; height: 18px; z-index: 305;"><div class="Box-sc-n41d2v-0 TextBase___StyledBox-sc-1o28pgm-0 jXOqqG kKESck"><div class="text-viewer"><p style="line-height:13px;padding-left:0;padding-top:1px;padding-bottom:0" class="view-mode unstyled align-center"><span style="font-size:11px;font-weight:400;font-family:Roboto;font-style:normal;text-decoration:none;text-transform:none;color:rgba(97, 74, 90, 1)">© 2022 Biz-Tech-Insights</span></p></div></div></div></div>
								</div>
							</div>
						</div>
						<div class="lightbox-wrapper"></div>
					</div>
									
									
									
								
									
								
								
									
								
								
								
								</div>
							</div>
						</div>
						<div class="lightbox-wrapper"></div>
					</div>
					
				</div>
				<div class="above-pages-container"></div>
			</div>
			<style id="page-transition-style" type="text/css" class="">
			.mag .mag-pages-container .container .page {
				-webkit-transition: all 550ms cubic-bezier(0.40, 0.24, 0.40, 1);
				transition: all 550ms cubic-bezier(0.40, 0.24, 0.40, 1);
			}
			
			.mag .mag-pages-container .container .page.center-page {
				-webkit-transition: all 545ms cubic-bezier(0.40, 0.24, 0.40, 1);
				transition: all 545ms cubic-bezier(0.40, 0.24, 0.40, 1);
			}
			</style>
			<div class="toolbar for-viewer default"> </div>
			<style id="page-position-style" type="text/css" class="">
			.mag .mag-pages-container .container {
				left: 0px;
				width: 1600px;
			}
			
			.mag .mag-pages-container .container .page {
				left: 0px;
				width: 1600px;
			}
			
			.mag .mag-pages-container .container .page.prev-page {
				-webkit-transform: translateX(0px);
				transform: translateX(0px);
			}
			
			.mag .mag-pages-container .container .page.center-page {
				-webkit-transform: translateX(0);
				transform: translateX(0);
			}
			
			.mag .mag-pages-container .container .page.next-page {
				-webkit-transform: translateX(1600px);
				transform: translateX(1600px);
			}
			</style>
		</div>
	</div>
	<div id="service-pages"></div>
	<div class="popups"></div>
	<div id="tmp"></div>
	<div id="fake" style="position: fixed; opacity: 1.0"></div>
	<div id="text-global-styles">
		<style class="">
		.align-left {
			text-align: left !important;
		}
		
		.align-center {
			text-align: center;
		}
		
		.align-right {
			text-align: right !important;
		}
		
		.align-justify {
			text-align: justify !important;
		}
		
		.unordered-list-item {
			padding: 0;
			margin: 0;
			list-style-type: none;
		}
		
		.unordered-list-item div[data-offset-key]:before,
		.unordered-list-item > li:before {
			white-space: nowrap;
			content: "•\00a0";
		}
		
		.ordered-list-item {
			padding: 0;
			margin: 0;
			list-style-type: none;
		}
		
		.ordered-list-item div[data-offset-key]:before,
		.ordered-list-item > li:before {
			white-space: nowrap;
			counter-increment: ordered-key;
			content: counter(ordered-key)".";
		}
		
		.paragraph-728601a3-c6ea-4ae9-b905-3d5d7b7cd420 {
			color: rgba(102, 102, 102, 1);
			font-family: Roboto;
			font-size: 10px;
			font-style: normal;
			font-weight: 400;
			letter-spacing: 0px;
			line-height: 22px;
			text-align: center;
		}
		
		.paragraph-1 {
			color: rgba(34, 34, 34, 1);
			font-family: Nobel;
			font-size: 48px;
			font-style: normal;
			font-weight: 700;
			line-height: 60px;
			text-align: left;
		}
		
		.paragraph-2 {
			color: rgba(34, 34, 34, 1);
			font-family: Georgia;
			font-size: 24px;
			font-style: normal;
			font-weight: 400;
			line-height: 30px;
			text-align: left;
		}
		
		.paragraph-3 {
			color: rgba(34, 34, 34, 1);
			font-family: Georgia;
			font-size: 18px;
			font-style: normal;
			font-weight: 400;
			line-height: 23px;
			text-align: left;
		}
		
		.paragraph-4 {
			color: rgba(34, 34, 34, 0.5);
			font-family: Georgia;
			font-size: 14px;
			font-style: italic;
			font-weight: 400;
			line-height: 18px;
			text-align: left;
		}
		
		.link-1 {
			text-decoration: none;
			padding-bottom: 1px;
			background: none;
			color: rgba(17, 90, 127, 1);
		}
		
		.link-1 * {
			color: rgba(17, 90, 127, 1);
		}
		
		.link-1 .hover,
		.link-1:hover {
			text-decoration: none;
			padding-bottom: 1px;
			background: none;
			color: rgba(17, 90, 127, 1) !important;
		}
		
		.link-1 .hover *,
		.link-1:hover * {
			color: rgba(17, 90, 127, 1) !important;
		}
		
		.link-1.current {
			text-decoration: none;
			padding-bottom: 1px;
			background: none;
			color: rgba(17, 90, 127, 1);
		}
		
		.link-1.current * {
			color: rgba(17, 90, 127, 1);
		}
		
		.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 {
			text-decoration: none;
			padding-bottom: 1px;
			background: linear-gradient(to right, rgba(0, 120, 255, 1) 0%, rgba(0, 120, 255, 1) 100%) 0 100%/1px 1px repeat-x;
			color: rgba(0, 120, 255, 1);
		}
		
		.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 * {
			color: rgba(0, 120, 255, 1);
		}
		
		.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 .hover,
		.link-5a1abc8a-c29e-44ec-8cc1-19095381f694:hover {
			text-decoration: none;
			padding-bottom: 1px;
			background: none;
			color: rgba(0, 120, 255, 1) !important;
		}
		
		.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 .hover *,
		.link-5a1abc8a-c29e-44ec-8cc1-19095381f694:hover * {
			color: rgba(0, 120, 255, 1) !important;
		}
		
		.link-5a1abc8a-c29e-44ec-8cc1-19095381f694.current {
			text-decoration: none;
			padding-bottom: 1px;
			background: none;
			color: rgba(0, 120, 255, 1);
		}
		
		.link-5a1abc8a-c29e-44ec-8cc1-19095381f694.current * {
			color: rgba(0, 120, 255, 1);
		}
		
		.link-style-1b4297b2-2701-485a-8c54-bc9664f9d834 {
			text-decoration: none;
			padding-bottom: 1px;
			background: linear-gradient(to right, rgba(255, 255, 255, 1) 0%, rgba(255, 255, 255, 1) 100%) 0 100%/1px 1px repeat-x;
			color: rgba(255, 255, 255, 1);
		}
		
		.link-style-1b4297b2-2701-485a-8c54-bc9664f9d834 * {
			color: rgba(255, 255, 255, 1);
		}
		
		.link-style-1b4297b2-2701-485a-8c54-bc9664f9d834 .hover,
		.link-style-1b4297b2-2701-485a-8c54-bc9664f9d834:hover {
			text-decoration: none;
			padding-bottom: 1px;
			background: linear-gradient(to right, rgba(1, 148, 211, 1) 0%, rgba(1, 148, 211, 1) 100%) 0 100%/1px 1px repeat-x;
			color: rgba(1, 148, 211, 1) !important;
		}
		
		.link-style-1b4297b2-2701-485a-8c54-bc9664f9d834 .hover *,
		.link-style-1b4297b2-2701-485a-8c54-bc9664f9d834:hover * {
			color: rgba(1, 148, 211, 1) !important;
		}
		
		.link-style-1b4297b2-2701-485a-8c54-bc9664f9d834.current {
			text-decoration: none;
			padding-bottom: 1px;
			background: linear-gradient(to right, rgba(0, 0, 0, 1) 0%, rgba(0, 0, 0, 1) 100%) 0 100%/1px 1px repeat-x;
			color: rgba(0, 0, 0, 1);
		}
		
		.link-style-1b4297b2-2701-485a-8c54-bc9664f9d834.current * {
			color: rgba(0, 0, 0, 1);
		}
		
		.default-list-style.edit-mode .editor-block-wrapper {
			display: flex;
		}
		
		.default-list-style.view-mode {
			display: flex;
		}
		
		.default-list-style.view-mode:before {
			display: inline-block;
		}
		
		.unordered-list-item.default-list-style.edit-mode .editor-block-wrapper:before {
			content: "•\00a0";
			display: inline-block;
		}
		
		.unordered-list-item.default-list-style.edit-mode div[data-offset-key]:before {
			content: "•\00a0";
			display: none;
		}
		
		.ordered-list-item.default-list-style.edit-mode .editor-block-wrapper:before {
			counter-increment: ordered-key;
			content: counter(ordered-key)".";
			display: inline-block;
			white-space: nowrap;
		}
		
		.ordered-list-item.default-list-style.edit-mode div[data-offset-key]:before {
			counter-increment: ordered-key;
			content: counter(ordered-key)".";
			display: none;
			white-space: nowrap;
		}
		
		.unordered-list-item .default-list-style.view-mode:before {
			content: "•\00a0";
		}
		</style>
	</div>
	
</body>

</html>