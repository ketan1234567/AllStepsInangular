<?php

$PDF_URL = $_GET["link"];
//echo $PDF_URL;

$temp = $_GET["data"];
//echo $temp;


//for fetching client's IP Address
if (getenv('HTTP_CLIENT_IP'))
    $ipaddress = getenv('HTTP_CLIENT_IP');
else if(getenv('HTTP_X_FORWARDED_FOR'))
    $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
else if(getenv('HTTP_X_FORWARDED'))
    $ipaddress = getenv('HTTP_X_FORWARDED');
else if(getenv('HTTP_FORWARDED_FOR'))
    $ipaddress = getenv('HTTP_FORWARDED_FOR');
else if(getenv('HTTP_FORWARDED'))
   $ipaddress = getenv('HTTP_FORWARDED');
else if(getenv('REMOTE_ADDR'))
    $ipaddress = getenv('REMOTE_ADDR');
else
    $ipaddress = 'UNKNOWN';

//for Capturing FORM Data
//$temp = $_GET["data"];//implode(" / ", $_POST["data"]);

//Get Campaign URL
$URL = $_GET["URL"];

if(isset($_GET["action"]))
{
	if($_GET["action"] == 'insert')
	{
		$form_data = array(
			
			'campaign' 		=>  $_GET['camp_id'],
			'ip'			=>	$ipaddress,
			'allfields'		=>	$temp,
			'url'			=>  $URL
		);

		$api_url = "https://advance.biz-tech-insights.com/Enterprise-Guide-to-Migrating-LE/test_api.php?action=insert";  //change this url as per your folder path for api folder
		$client = curl_init($api_url);
		curl_setopt($client, CURLOPT_POST, true);
		curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
		curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
		$response = curl_exec($client);
		curl_close($client);
		$result = json_decode($response, true);

		foreach($result as $keys => $values)
		{
			if($result[$keys]['success'] == '1')
			{
				header('Location:'.$PDF_URL);
			}
			else
			{
				header('Location: https://advance.biz-tech-insights.com/Enterprise-Guide-to-Migrating-LE/page-not-found/');
			}
		}
	}

}


?>