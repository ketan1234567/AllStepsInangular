<html style="--min-desktop-width:769px;" class="js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths retina no-android no-amazonsilk no-mac windows webkit no-opera chrome no-msie no-msie11 no-winphone8 no-safari no-safari5 no-isipad no-ismobile no-firefox no-edge csspositionsticky isdesktop no-istablet no-isphone no-screenshot-mode controls-on-top new-settings mobile-screenshots page-loaded">

<head>
	<meta charset="utf-8">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta name="generator" content="Readymag" data-project="3175138" data-user="u93502920" data-is-exported="false">
	<meta name="robots" content="noindex,nofollow">
	<meta name="referrer" content="always">
	<meta name="viewport" id="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=10,minimal-ui">
	<meta name="mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-title" content="SERVICENOW_Supercharge_Performance_LE">
	<link rel="preload" as="style" href="/api/fonts/webtype/css?domain=biz-tech-insights.dev&amp;md5=zreSQug9EtvuKFhgD_tvqQ" class="">
	<link rel="preload" as="style" href="/api/fonts/typetoday/css?domain=biz-tech-insights.dev&amp;md5=O1PJSTXTtmazAgKU3SeC5Q" class="">
	<link rel="preload" as="style" href="https://fonts.googleapis.com/css?family=Source Sans Pro:200,200italic,300,300italic,400,400italic,600,600italic,700,700italic,900,900italic%7CRoboto:100,100italic,300,300italic,400,400italic,500,500italic,700,700italic,900,900italic%7CInter:100,200,300,400,500,600,700,800,900&amp;subset=latin,vietnamese,khmer,cyrillic-ext,greek-ext,greek,devanagari,latin-ext,cyrillic" class="">
	<link rel="icon" href="https://rm-content.s3.amazonaws.com/56969df1bd02a4a3292a2178/upload-ebda98a0-c134-11e5-9ef1-39f48dd79a10_144.png" type="image/png" class="">
	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="https://rm-content.s3.amazonaws.com/56969df1bd02a4a3292a2178/upload-ebda98a0-c134-11e5-9ef1-39f48dd79a10_144.png" class="">
	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="https://rm-content.s3.amazonaws.com/56969df1bd02a4a3292a2178/upload-ebda98a0-c134-11e5-9ef1-39f48dd79a10_114.png" class="">
	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="https://rm-content.s3.amazonaws.com/56969df1bd02a4a3292a2178/upload-ebda98a0-c134-11e5-9ef1-39f48dd79a10_72.png" class="">
	<link rel="apple-touch-icon-precomposed" href="https://rm-content.s3.amazonaws.com/56969df1bd02a4a3292a2178/upload-ebda98a0-c134-11e5-9ef1-39f48dd79a10_57.png" class="">
	<!--[if IE]><link rel="shortcut icon" href="https://rm-content.s3.amazonaws.com/56969df1bd02a4a3292a2178/upload-ebda98a0-c134-11e5-9ef1-39f48dd79a10_144.png" type="image/x-icon"/><![endif]-->
	<link rel="next" href="http://biz-tech-insights.dev/SERVICENOW-Supercharge-Performance-LE/2/" class="">
	<meta content="955357184504374" property="fb:app_id">
	<meta content="website" property="og:type">
	<meta content="http://biz-tech-insights.dev/3175138/" property="og:url">
	<meta content="summary_large_image" name="twitter:card">
	<meta content="!" name="fragment">
	<meta content="SERVICENOW_Supercharge_Performance_LE" property="og:site_name">
	<meta content="https://d3n32ilufxuvd1.cloudfront.net/56969df1bd02a4a3292a2178/3175138/screenshot-30ce80e6-046f-41bc-b03c-8b0da626e5db_readyscr_1024.jpg" property="og:image">
	<meta content="SERVICENOW_Supercharge_Performance_LE" property="og:title">
	<title>SERVICENOW_Supercharge_Performance_LE</title>
	<script>
	var RM = window.RM = window.RM || {};
	try {
		if(document.domain) document.domain = document.domain;
	} catch(e) {}
	window.ServerData = {
		"mags": {
			"mag": {
				"opts": {
					"arrows": false,
					"menubutton": false,
					"sharebutton": false,
					"pagecounter": false,
					"endpage": false,
					"endpagetype": "empty",
					"viewertype": "horizontal",
					"slidein": true,
					"scalewidth": 3600,
					"projectinfo": false,
					"allowindex": false,
					"scalableviewer": false,
					"lqip": false,
					"hidden": true,
					"ssl": false,
					"sslState": "success",
					"useCustomCursor": false,
					"controlsontop": true,
					"phoneVerticalAlign": "center",
					"branding": false
				},
				"textStyles": {
					"global": [{
						"_id": "5fada5f19fe9df00b13267de",
						"name": "paragraph-728601a3-c6ea-4ae9-b905-3d5d7b7cd420",
						"label": "New\x20style",
						"tag": "p",
						"cssProperties": {
							"color": "66666664",
							"fontFamily": "Roboto",
							"fontSize": 10,
							"fontStyle": "normal",
							"fontWeight": "400",
							"letterSpacing": "0",
							"lineHeight": 22,
							"textAlign": "center",
							"paddingTop": 0,
							"paddingRight": 0,
							"paddingBottom": 0,
							"paddingLeft": 0
						}
					}],
					"project": [{
						"_id": "613bbcdd9b77e80021d24447",
						"name": "paragraph-1",
						"label": "H1",
						"tag": "p",
						"cssProperties": {
							"textAlign": "left",
							"lineHeight": 60,
							"fontWeight": 700,
							"fontStyle": "normal",
							"fontSize": 48,
							"fontFamily": "Nobel",
							"color": "22222264",
							"paddingLeft": 0,
							"paddingRight": 0,
							"paddingTop": 0,
							"paddingBottom": 0
						}
					}, {
						"_id": "613bbcdd9b77e80021d24448",
						"name": "paragraph-2",
						"label": "H2",
						"tag": "p",
						"cssProperties": {
							"textAlign": "left",
							"lineHeight": 30,
							"fontWeight": 400,
							"fontStyle": "normal",
							"fontSize": 24,
							"fontFamily": "Georgia",
							"color": "22222264",
							"paddingLeft": 0,
							"paddingRight": 0,
							"paddingTop": 0,
							"paddingBottom": 0
						}
					}, {
						"_id": "613bbcdd9b77e80021d24449",
						"name": "paragraph-3",
						"label": "Text",
						"tag": "p",
						"cssProperties": {
							"textAlign": "left",
							"lineHeight": 23,
							"fontWeight": 400,
							"fontStyle": "normal",
							"fontSize": 18,
							"fontFamily": "Georgia",
							"color": "22222264",
							"paddingLeft": 0,
							"paddingRight": 0,
							"paddingTop": 0,
							"paddingBottom": 0
						}
					}, {
						"_id": "613bbcdd9b77e80021d2444a",
						"name": "paragraph-4",
						"label": "Caption",
						"tag": "p",
						"cssProperties": {
							"textAlign": "left",
							"lineHeight": 18,
							"fontWeight": 400,
							"fontStyle": "italic",
							"fontSize": 14,
							"fontFamily": "Georgia",
							"color": "22222232",
							"paddingLeft": 0,
							"paddingRight": 0,
							"paddingTop": 0,
							"paddingBottom": 0
						}
					}]
				},
				"listStyles": {
					"global": [],
					"project": []
				},
				"linkStyles": {
					"global": [],
					"project": [{
						"style": {
							"link": {
								"textColor": "115a7f64",
								"color": "115a7f64",
								"size": 1,
								"padding": 0,
								"type": "None"
							},
							"hover": {
								"textColor": "115a7f64",
								"color": "115a7f64",
								"size": 1,
								"padding": 0,
								"type": "None"
							},
							"current": {
								"textColor": "115a7f64",
								"color": "115a7f64",
								"size": 1,
								"padding": 0,
								"type": "None"
							}
						},
						"_id": "613bbcddf121020021c328ab",
						"name": "link-1",
						"label": "Default\x20Link\x20Style"
					}, {
						"style": {
							"link": {
								"textColor": "0078ff64",
								"color": "0078ff64",
								"size": 1,
								"padding": 0,
								"type": "Solid"
							},
							"hover": {
								"textColor": "0078ff64",
								"color": "0078ff64",
								"size": 1,
								"padding": 0,
								"type": "None"
							},
							"current": {
								"textColor": "0078ff64",
								"color": "0078ff64",
								"size": 1,
								"padding": 0,
								"type": "None"
							}
						},
						"_id": "613bbcddf121020021c328ac",
						"name": "link-5a1abc8a-c29e-44ec-8cc1-19095381f694",
						"label": "New\x20style"
					}]
				},
				"likers": [],
				"isPrivatePages": false,
				"pass_last_changed": "2021-10-18T17:44:24.793Z",
				"desktopWidth": 1024,
				"phoneWidth": 320,
				"used_typekit_fonts": [],
				"submitted_for_featured": 0,
				"selected_for_featured": 0,
				"version": 2,
				"hasSummary": true,
				"globalWidgets": [],
				"aboveAllWidgets": [],
				"hasWidgetsWithVerticalOnscrollAnimation": false,
				"hasTextWidgetsV3": true,
				"hasYoutube": false,
				"usedWidgetTypes": ["background", "text", "picture", "button", "shape", "form"],
				"_id": "616db3e44641814215b103f1",
				"num_id": 3175138,
				"__v": 0,
				"categories": [],
				"changed": false,
				"ci_body_bottom": null,
				"ci_body_top": null,
				"ci_css": null,
				"ci_head": null,
				"copyStatus": "finished",
				"coverPid": "616db2785678b3003adb9176",
				"creation_date": "2021-10-18T17:44:24.793Z",
				"description": "",
				"edit_params": {
					"guides": true,
					"grid": false,
					"sizes": false,
					"blocks": false,
					"snap": true,
					"swatches": [],
					"fav_colors": [],
					"fav_fonts": [],
					"fonts_tab": "all",
					"fonts": [{
						"variations": ["n4", "i4", "n7", "i7"],
						"name": "Arial",
						"css_name": "Arial",
						"provider": "system"
					}, {
						"variations": ["n4", "i4", "n7", "i7"],
						"name": "Courier\x20New",
						"css_name": "Courier\x20New",
						"provider": "system"
					}, {
						"variations": ["n4", "i4", "n7", "i7"],
						"name": "Georgia",
						"css_name": "Georgia",
						"provider": "system"
					}, {
						"variations": ["n4", "i4", "n7", "i7"],
						"name": "Times\x20New\x20Roman",
						"css_name": "Times\x20New\x20Roman",
						"provider": "system"
					}, {
						"variations": ["n4", "i4", "n7", "i7"],
						"name": "Trebuchet\x20MS",
						"css_name": "Trebuchet\x20MS",
						"provider": "system"
					}, {
						"variations": ["n4", "i4", "n7", "i7"],
						"name": "Verdana",
						"css_name": "Verdana",
						"provider": "system"
					}, {
						"variations": ["n4", "n7"],
						"name": "Tahoma",
						"css_name": "Tahoma",
						"provider": "system"
					}, {
						"variations": ["n2", "i2", "n3", "i3", "n4", "i4", "n6", "i6", "n7", "i7", "n9", "i9"],
						"name": "Source\x20Sans\x20Pro",
						"css_name": "Source\x20Sans\x20Pro",
						"provider": "google"
					}, {
						"hidden": false,
						"variations": ["n1", "i1", "n3", "i3", "n4", "i4", "n5", "i5", "n7", "i7", "n9", "i9"],
						"name": "Roboto",
						"css_name": "Roboto",
						"provider": "google"
					}, {
						"provider": "google",
						"css_name": "Inter",
						"name": "Inter",
						"variations": ["n1", "n2", "n3", "n4", "n5", "n6", "n7", "n8", "n9"]
					}],
					"paragraph_styles": [{
						"padding-left": 0,
						"padding-bottom": 0,
						"padding-right": 0,
						"padding-top": 0,
						"vertical-align": "baseline",
						"text-transform": "none",
						"text-decoration": "none",
						"text-align": "start",
						"line-height": 60,
						"letter-spacing": 0,
						"font-weight": 700,
						"font-style": "normal",
						"font-size": 48,
						"font-family": "Nobel",
						"opacity": 100,
						"color": "222222",
						"_sort": 0,
						"_name": "paragraph-1",
						"_caption": "H1"
					}, {
						"padding-left": 0,
						"padding-bottom": 0,
						"padding-right": 0,
						"padding-top": 0,
						"vertical-align": "baseline",
						"text-transform": "none",
						"text-decoration": "none",
						"text-align": "start",
						"line-height": 30,
						"letter-spacing": 0,
						"font-weight": 400,
						"font-style": "normal",
						"font-size": 24,
						"font-family": "Georgia",
						"opacity": 100,
						"color": "222222",
						"_sort": 1,
						"_name": "paragraph-2",
						"_caption": "H2"
					}, {
						"padding-left": 0,
						"padding-bottom": 0,
						"padding-right": 0,
						"padding-top": 0,
						"vertical-align": "baseline",
						"text-transform": "none",
						"text-decoration": "none",
						"text-align": "start",
						"line-height": 23,
						"letter-spacing": 0,
						"font-weight": 400,
						"font-style": "normal",
						"font-size": 18,
						"font-family": "Georgia",
						"opacity": 100,
						"color": "222222",
						"_sort": 2,
						"_name": "paragraph-3",
						"_caption": "Text"
					}, {
						"padding-left": 0,
						"padding-bottom": 0,
						"padding-right": 0,
						"padding-top": 0,
						"vertical-align": "baseline",
						"text-transform": "none",
						"text-decoration": "none",
						"text-align": "start",
						"line-height": 18,
						"letter-spacing": 0,
						"font-weight": 400,
						"font-style": "italic",
						"font-size": 14,
						"font-family": "Georgia",
						"opacity": 50,
						"color": "222222",
						"_sort": 3,
						"_name": "paragraph-4",
						"_caption": "Caption"
					}],
					"link_styles": [{
						"hover-u-offset": "inherit",
						"hover-u-size": "inherit",
						"hover-u-opacity": "inherit",
						"hover-u-color": "inherit",
						"hover-u-style": "none",
						"hover-opacity": "inherit",
						"hover-color": "inherit",
						"u-offset": 0,
						"u-size": 1,
						"u-opacity": 100,
						"u-color": "115a7f",
						"u-style": "none",
						"opacity": 100,
						"color": "115a7f",
						"_sort": 0,
						"_name": "link-1",
						"_caption": "Default\x20Link\x20Style"
					}, {
						"current-u-offset": "inherit",
						"current-u-size": "inherit",
						"current-u-opacity": "inherit",
						"current-u-color": "inherit",
						"current-u-style": "none",
						"current-opacity": "inherit",
						"current-color": "inherit",
						"hover-u-offset": "inherit",
						"hover-u-size": "inherit",
						"hover-u-opacity": "inherit",
						"hover-u-color": "inherit",
						"hover-u-style": "none",
						"hover-opacity": "inherit",
						"hover-color": "inherit",
						"u-offset": 0,
						"u-size": 1,
						"u-opacity": 100,
						"u-color": "0078ff",
						"u-style": "solid",
						"opacity": 100,
						"color": "0078ff",
						"_sort": 1,
						"_name": "link-5a1abc8a-c29e-44ec-8cc1-19095381f694",
						"_caption": "New\x20style"
					}],
					"_id": "61e9bee36b7330a237469549"
				},
				"folder": "56a2cea73b36caee22ba3a64",
				"isArchived": false,
				"is_mag_use_minimal_viewport": false,
				"is_mag_use_page_order": true,
				"is_private": false,
				"is_published": true,
				"last_changed": "2021-10-19T14:42:22.383Z",
				"master_share_pid": null,
				"pages": [{
					"wids": ["616db2795678b3003adb917f", "616db2795678b3003adb9180", "616db2795678b3003adb9182", "616db2795678b3003adb9183", "616db30b239f1d0014ca0db4", "616db30b76d32430b285b636", "616db3302f2a240027ad5c19", "616db3316afaa11cd2c68aaa", "616db335239f1d0014ca1362", "616db365454bb800333d0773", "616db36635f5fe00356f3a6a", "616db3661ed2d1001d80c262", "616db37157133b003c7f306e", "616db7960cf3bf00133b8aa0", "616db7fcee0ca20027eb7133"],
					"order": {
						"default": {
							"aboveAll": [],
							"frontFixed": [],
							"normal": ["616db7fcee0ca20027eb7133", "616db3661ed2d1001d80c262", "616db365454bb800333d0773", "616db335239f1d0014ca1362", "616db3316afaa11cd2c68aaa", "616db3302f2a240027ad5c19", "616db30b76d32430b285b636", "616db30b239f1d0014ca0db4", "616db2795678b3003adb9183", "616db2795678b3003adb9182", "616db2795678b3003adb9184", "616db2795678b3003adb9180", "616db2795678b3003adb9185", "616db36635f5fe00356f3a6a", "616db37157133b003c7f306e", "616db7960cf3bf00133b8aa0"],
							"backFixed": []
						},
						"phone_portrait": {
							"aboveAll": [],
							"frontFixed": [],
							"normal": ["616db7fcee0ca20027eb7133", "616db7960cf3bf00133b8aa0", "616db37157133b003c7f306e", "616db3661ed2d1001d80c262", "616db36635f5fe00356f3a6a", "616db365454bb800333d0773", "616db335239f1d0014ca1362", "616db3316afaa11cd2c68aaa", "616db3302f2a240027ad5c19", "616db30b76d32430b285b636", "616db30b239f1d0014ca0db4", "616db2795678b3003adb9180", "616db2795678b3003adb9183", "616db2795678b3003adb9182", "616db2795678b3003adb9185", "616db2795678b3003adb9184"],
							"backFixed": []
						}
					},
					"type": "scroll",
					"height": 996,
					"hidden": false,
					"isPrivate": false,
					"sectionscroll": false,
					"used_autolayout": false,
					"arrows_color": "white",
					"_id": "616db2785678b3003adb9176",
					"num": 1,
					"viewport_phone_portrait": {
						"height": 1381,
						"enabled": false,
						"type": "scroll"
					},
					"title": "Thycotic-Centrify-Incident-Response",
					"mid": "616db2785678b3003adb9171",
					"num_id": 13959562,
					"parentPage": null,
					"screenshot": "https:\x2F\x2Fd3n32ilufxuvd1.cloudfront.net\x2F56969df1bd02a4a3292a2178\x2F3175138\x2Fscreenshot-30ce80e6-046f-41bc-b03c-8b0da626e5db_readyscr.jpg",
					"children": [],
					"pagePath": "1",
					"pageNestedNum": "1",
					"htmlUrl": "https:\x2F\x2Fd3n32ilufxuvd1.cloudfront.net\x2F56969df1bd02a4a3292a2178\x2F3175138\x2Fbody-d2a0931c-9911-4f4b-b311-1713fc13db58.html"
				}, {
					"wids": ["616db2795678b3003adb91c7", "616db2795678b3003adb91c8", "616db2795678b3003adb91c9", "616db2795678b3003adb91cc", "616db2795678b3003adb91cd", "616db2795678b3003adb91ce", "616db2795678b3003adb91cf", "616db2795678b3003adb91d0", "616db2795678b3003adb91d1", "616db2795678b3003adb91d8", "616db8c6454bb800333dbccb", "616db8c6d1bc4e00226da7db", "616db90d6693cd31abf07d29", "616dba481ed2d1001d819475", "616dbaeac9403d003200d9e8", "616dbaea293d24006e224235", "616dbbfc0d1de5006e958069", "616dbc240d1de5006e95824e", "616dbc71a71c6b5b522cdcb6", "616dbcaac92f7d406ba7a0b3", "616dbe196f9c7c004320cee6"],
					"order": {
						"default": {
							"aboveAll": [],
							"frontFixed": [],
							"normal": ["616db90d6693cd31abf07d29", "616dbcaac92f7d406ba7a0b3", "616dbc71a71c6b5b522cdcb6", "616dbbfc0d1de5006e958069", "616dbaea293d24006e224235", "616dbaeac9403d003200d9e8", "616dba481ed2d1001d819475", "616db8c6d1bc4e00226da7db", "616db8c6454bb800333dbccb", "616db2795678b3003adb91d8", "616db2795678b3003adb91d1", "616db2795678b3003adb91cf", "616db2795678b3003adb91c8", "616db2795678b3003adb91c9", "616db2795678b3003adb91cc", "616db2795678b3003adb91ce", "616db2795678b3003adb91cd", "616db2795678b3003adb91ca", "616db2795678b3003adb91cb", "616db2795678b3003adb91d0", "616dbc240d1de5006e95824e", "616dbe196f9c7c004320cee6"],
							"backFixed": []
						},
						"phone_portrait": {
							"aboveAll": [],
							"frontFixed": [],
							"normal": ["616dbe196f9c7c004320cee6", "616dbcaac92f7d406ba7a0b3", "616dbc71a71c6b5b522cdcb6", "616dbc240d1de5006e95824e", "616dbbfc0d1de5006e958069", "616dbaea293d24006e224235", "616dbaeac9403d003200d9e8", "616dba481ed2d1001d819475", "616db90d6693cd31abf07d29", "616db8c6d1bc4e00226da7db", "616db8c6454bb800333dbccb", "616db2795678b3003adb91d8", "616db2795678b3003adb91d1", "616db2795678b3003adb91d0", "616db2795678b3003adb91cf", "616db2795678b3003adb91ce", "616db2795678b3003adb91c9", "616db2795678b3003adb91c8", "616db2795678b3003adb91cd", "616db2795678b3003adb91cc", "616db2795678b3003adb91cb", "616db2795678b3003adb91ca"],
							"backFixed": []
						}
					},
					"type": "scroll",
					"height": 767,
					"hidden": false,
					"isPrivate": false,
					"sectionscroll": false,
					"used_autolayout": false,
					"arrows_color": "white",
					"_id": "616db2795678b3003adb9178",
					"num": 2,
					"viewport_phone_portrait": {
						"type": "scroll",
						"enabled": false,
						"height": 1443
					},
					"title": "Page\x202",
					"mid": "616db2785678b3003adb9171",
					"num_id": 13959564,
					"parentPage": null,
					"screenshot": "https:\x2F\x2Fd3n32ilufxuvd1.cloudfront.net\x2F56969df1bd02a4a3292a2178\x2F3175138\x2Fscreenshot-a6395404-81ab-40fc-ba76-30af898dad0d_readyscr.jpg",
					"children": [],
					"pagePath": "2",
					"pageNestedNum": "2",
					"htmlUrl": "https:\x2F\x2Fd3n32ilufxuvd1.cloudfront.net\x2F56969df1bd02a4a3292a2178\x2F3175138\x2Fbody-0a98db29-ce15-4e7e-b6d1-8f142a082af5.html"
				}, {
					"wids": ["616db2795678b3003adb91af", "616db2795678b3003adb91b1", "616db2795678b3003adb91b2", "616db2795678b3003adb91b3", "616db2795678b3003adb91b4", "616dbe416afaa11cd2c74386", "616dbe71454bb800333e5f97", "616dbe71454bb800333e5f9a", "616dbe82ba9d3000756e0906", "616dbf79d1bc4e00226e6ffa"],
					"order": {
						"default": {
							"aboveAll": [],
							"frontFixed": [],
							"normal": ["616dbf79d1bc4e00226e6ffa", "616dbe82ba9d3000756e0906", "616dbe71454bb800333e5f9a", "616dbe71454bb800333e5f97", "616dbe416afaa11cd2c74386", "616db2795678b3003adb91b4", "616db2795678b3003adb91b1", "616db2795678b3003adb91b3", "616db2795678b3003adb91b2"],
							"backFixed": []
						},
						"phone_portrait": {
							"aboveAll": [],
							"frontFixed": [],
							"normal": ["616dbf79d1bc4e00226e6ffa", "616dbe82ba9d3000756e0906", "616dbe71454bb800333e5f9a", "616dbe71454bb800333e5f97", "616dbe416afaa11cd2c74386", "616db2795678b3003adb91b4", "616db2795678b3003adb91b3", "616db2795678b3003adb91b2", "616db2795678b3003adb91b1"],
							"backFixed": []
						}
					},
					"type": "scroll",
					"height": 1609,
					"hidden": false,
					"isPrivate": false,
					"sectionscroll": false,
					"used_autolayout": false,
					"arrows_color": "white",
					"_id": "616db2785678b3003adb9177",
					"num": 3,
					"viewport_phone_portrait": {
						"type": "scroll",
						"height": 1910,
						"enabled": false
					},
					"title": "Asset\x2FForm",
					"uri": "",
					"mid": "616db2785678b3003adb9171",
					"num_id": 13959563,
					"parentPage": null,
					"screenshot": "https:\x2F\x2Fd3n32ilufxuvd1.cloudfront.net\x2F56969df1bd02a4a3292a2178\x2F3175138\x2Fscreenshot-81d0c335-e285-45c9-b2eb-9571294f6402_readyscr.jpg",
					"children": [],
					"pagePath": "3",
					"pageNestedNum": "3",
					"htmlUrl": "https:\x2F\x2Fd3n32ilufxuvd1.cloudfront.net\x2F56969df1bd02a4a3292a2178\x2F3175138\x2Fbody-083d008b-944c-4417-a00a-6594a233ac79.html"
				}],
				"pages_count": 3,
				"prevPubVersionId": "616dc1a676d32430b2869d23",
				"published": "2021-10-18T17:50:28.520Z",
				"showAsNew": false,
				"tags": [],
				"title": "SERVICENOW_Supercharge_Performance_LE",
				"typekit_url": null,
				"updated": "2021-10-19T14:42:23.144Z",
				"uri": "SERVICENOW-Supercharge-Performance-LE",
				"used_custom_fonts": [],
				"used_google_fonts": [],
				"used_typetoday_fonts": [],
				"used_webtype_fonts": [],
				"user": {
					"opts": {
						"favicon": "https:\x2F\x2Frm-content.s3.amazonaws.com\x2F56969df1bd02a4a3292a2178\x2Fupload-ebda98a0-c134-11e5-9ef1-39f48dd79a10.png"
					},
					"specials": {
						"pricing_visited": "2018-12-12T17:27:02.891Z"
					},
					"_id": "56969df1bd02a4a3292a2178",
					"name": "Game6Media",
					"num_id": 93502920,
					"uri": "u93502920",
					"mags_count": 392,
					"desc": "",
					"twitter": "https:\x2F\x2Ftwitter.com\x2FGame6MediaNY",
					"ua": "",
					"pic": "https:\x2F\x2Fd3n32ilufxuvd1.cloudfront.net\x2F56969df1bd02a4a3292a2178\x2Fupload-0b7863b0-c02d-11e7-8ec4-87dff4b50f33.png",
					"permissions": {
						"can_use_analytics": true,
						"must_show_branding": false,
						"can_use_gtm": true,
						"white_label": true,
						"can_use_custom_analytics": false,
						"can_use_beta_testing": false,
						"can_use_e_commerce": true,
						"can_use_forms_file_upload": true,
						"forms_file_upload_limit": 31457280,
						"forms_file_upload_count": 10,
						"can_use_iframe": true
					}
				},
				"cover": "https:\x2F\x2Fd3n32ilufxuvd1.cloudfront.net\x2F56969df1bd02a4a3292a2178\x2F3175138\x2Fscreenshot-30ce80e6-046f-41bc-b03c-8b0da626e5db_readyscr.jpg"
			},
			"user": {
				"opts": {
					"favicon": "https:\x2F\x2Frm-content.s3.amazonaws.com\x2F56969df1bd02a4a3292a2178\x2Fupload-ebda98a0-c134-11e5-9ef1-39f48dd79a10.png",
					"sslState": "success",
					"ssl": true
				},
				"specials": {
					"pricing_visited": "2018-12-12T17:27:02.891Z"
				},
				"_id": "56969df1bd02a4a3292a2178",
				"name": "Game6Media",
				"num_id": 93502920,
				"uri": "u93502920",
				"mags_count": 392,
				"desc": "",
				"twitter": "https:\x2F\x2Ftwitter.com\x2FGame6MediaNY",
				"ua": "",
				"pic": "https:\x2F\x2Fd3n32ilufxuvd1.cloudfront.net\x2F56969df1bd02a4a3292a2178\x2Fupload-0b7863b0-c02d-11e7-8ec4-87dff4b50f33.png"
			},
			"domainForUser": true
		},
		"userPermissions": {
			"can_use_analytics": true,
			"must_show_branding": false,
			"can_use_gtm": true,
			"white_label": true,
			"can_use_custom_analytics": false,
			"can_use_beta_testing": false,
			"can_use_e_commerce": true,
			"can_use_forms_file_upload": true,
			"forms_file_upload_limit": 31457280,
			"forms_file_upload_count": 10,
			"can_use_iframe": true
		},
		"stripe_live": true,
		"fonts": {
			"webtype": "\x2Fapi\x2Ffonts\x2Fwebtype\x2Fcss\x3Fdomain\x3Dbiz-tech-insights.dev\x26md5\x3DzreSQug9EtvuKFhgD_tvqQ",
			"typetoday": "\x2Fapi\x2Ffonts\x2Ftypetoday\x2Fcss\x3Fdomain\x3Dbiz-tech-insights.dev\x26md5\x3DO1PJSTXTtmazAgKU3SeC5Q",
			"google": ["https:\x2F\x2Ffonts.googleapis.com\x2Fcss\x3Ffamily\x3DSource\x20Sans\x20Pro:200,200italic,300,300italic,400,400italic,600,600italic,700,700italic,900,900italic\x257CRoboto:100,100italic,300,300italic,400,400italic,500,500italic,700,700italic,900,900italic\x257CInter:100,200,300,400,500,600,700,800,900\x26subset\x3Dlatin,vietnamese,khmer,cyrillic-ext,greek-ext,greek,devanagari,latin-ext,cyrillic"]
		},
		"featureFlags": {
			"constructor.shotsTemplates": true,
			"experiment.interactiveHelpTour": false,
			"experiment.newMainPage": false,
			"constructor.virtualSandboxProjects": false,
			"constructor.newExport": false,
			"constructor.disconnectPages": true,
			"constructor.projectCustomCursor": true,
			"constructor.viewportMagOverrides": true,
			"constructor.contactSupportForm": false,
			"constructor.replacePictureWithoutResize": true,
			"constructor.previewSettings": false,
			"constructor.connectPages": true,
			"constructor.blocksHighlight3": true,
			"viewer.transformNotZoom": false,
			"constructor.shotsDecode": false,
			"constructor.editorRole": false,
			"experiment.plusTooltip": false,
			"constructor.helpInAccordion": false,
			"analytics.v2": false,
			"authorization.denyEmailDomains": false,
			"viewer.reactScreenshoterEntrypoint": true,
			"constructor.viewportMinimal": false,
			"viewer.reactEntrypoint": false,
			"constructor.mobileScreenshots": true,
			"viewer.monitorForLoopBlocks": false,
			"constructor.zIndex_backup": true,
			"constructor.restBulkUpdate": true,
			"constructor.blocksHighlight": true,
			"widget.modifiers": false,
			"constructor.snapClean": true,
			"constructor.equalColumns": true,
			"viewer.scaleScreenshots": true,
			"constructor.videoHelpTourAB": false,
			"constructor.preciseGuides": true,
			"constructor.blocksHighlight2": true,
			"constructor.controlsDivider": true
		},
		"isCountryInEU": false,
		"xForwardedFor": "114.143.216.246,\x20172.31.41.133,\x2010.99.55.101",
		"config": {
			"isProd": true,
			"isProdBuild": true,
			"stripe_live": true,
			"STRIPE_TEST_PUBLIC_KEY": "pk_test_jUUcZjJTPacN2s7Bs6j2F0Va",
			"STRIPE_LIVE_PUBLIC_KEY": "pk_live_4WmkUqmpy589CuOX7zOhAnU3",
			"fontslist_short": "\x2F\x2Fd1id5eheivyv24.cloudfront.net\x2Ffonts\x2Ffontslist_short.json",
			"fontslist": "\x2F\x2Fd1id5eheivyv24.cloudfront.net\x2Ffonts\x2Ffontslist.json",
			"fontsimgs": "\x2F\x2Fd1id5eheivyv24.cloudfront.net\x2Ffonts\x2F",
			"SENTRY_DSN": "https:\x2F\x2Fbc077ba97b6f4543974ef4f38e05eff1\x40sentry.readymag.net\x2F5",
			"readymag_host": "https:\x2F\x2Freadymag.com",
			"readymag_auth_host": "https:\x2F\x2Fmy.readymag.com",
			"readymag_embed_host": "https:\x2F\x2Fembed.readymag.com",
			"readymag_lambda_host": "https:\x2F\x2Fd2kq0urxkarztv.cloudfront.net",
			"favicon": {
				"default": "\x2Fdist\x2Fimg\x2Ffavicons\x2Ffavicon.ico",
				"touch": "\x2Fdist\x2Fimg\x2Ffavicons\x2Fapple-touch-icon-precomposed.png",
				"touch_144": "\x2Fdist\x2Fimg\x2Ffavicons\x2Fapple-touch-icon-144x144-precomposed.png",
				"touch_114": "\x2Fdist\x2Fimg\x2Ffavicons\x2Fapple-touch-icon-114x114-precomposed.png",
				"touch_72": "\x2Fdist\x2Fimg\x2Ffavicons\x2Fapple-touch-icon-72x72-precomposed.png"
			},
			"GA_ID": "UA-110571495-2",
			"GTM_ID": "GTM-NPR9HT7",
			"YANDEX_COUNTER": 71528560,
			"hotjar": {
				"id": 2740585,
				"version": 6
			},
			"amplitudeApiKey": "bef553e84dfb01a0da595c3a636436f6",
			"productVisitZones": ["profile", "public", "editor"],
			"FACEBOOK_APP_ID": "955357184504374",
			"FACEBOOK_API_VERSION": "2.3",
			"FACEBOOK_PIXEL_ID": "166690417336028",
			"YOUTUBE_API": "AIzaSyCKhzDj2szWSOHNYEdBH1obPUBkOC4op5g",
			"SOUNDCLOUD_API": "73d56f812402c7229878245f61a366fb",
			"TYPEKIT_ID": "rm",
			"TYPEKIT_TOKEN": "3bb2a6e53c9684ffdc9a99f4125b2a62feb024cf1a83fd2619b27014091e9d9dd9dec1d5d94c24ace6c645bbbcd4a16329d802df6e31a707e226d4e5fc49b837d131bc940117891228784d5dee8538bed9544b581bdaf57e0dc7ab9b5f7e316bc8efa22d7ff8caa28133e3986f4b7afe9c354ffff7eec9b0d8e5c160eb5e8936da76e0b37a964407ae231f6b6432b0a7f3ee7ae5dc05fe30cd7e1a05e920af9e1c728a4bb01d4d1ba694183e778c9c90f9f9bc91cbc3528ac7d6395973ec6d559ccd254df729ec3ea23a13bfb3f6c5d433ba9875c268acf548fea9b1817f39a9eee90bdb7a6f9644c98882fd8472ebced24f76010aee15c68f7c00125c7f625a1f7cc07cee9a66637ca636014f736631fec4c8793b7d0cd941f236a2ea2d66956123f0b404249dbfc797e70508e4c8511e1238be74722e5386b8475f6a0ae0ca4c39288206c38e57",
			"PINGDOM_ID_AUTH": "57ebf19d254226f0c0df7f98",
			"PINGDOM_ID_VIEWER": "585a8854e629a5eb9048a348",
			"SUPPORT_MAIL": "support\x40readymag.com",
			"HELLO_MAIL": "hello\x40readymag.com",
			"EDU_MAIL": "edu\x40readymag.com",
			"NOREPLY_MAIL": "no-reply\x40readymag.com",
			"FORMS_ACCEPTED_MIMES": ["image\x2F\x2A", "video\x2F\x2A", "audio\x2F\x2A", "application\x2Fpdf", "application\x2Fmsword", "application\x2Fvnd.openxmlformats-officedocument.wordprocessingml.document", "application\x2Fvnd.oasis.opendocument.text", "application\x2Fvnd.oasis.opendocument.presentation", "application\x2Fvnd.oasis.opendocument.spreadsheet", "application\x2Fvnd.ms-powerpoint", "application\x2Fvnd.openxmlformats-officedocument.presentationml.presentation", "application\x2Fvnd.openxmlformats-officedocument.spreadsheetml.sheet", "application\x2Fvnd.ms-excel", "application\x2Fx-iwork-keynote-sffkey", "application\x2Fx-iwork-pages-sffpages", "application\x2Fx-iwork-numbers-sffnumbers"],
			"RECAPTCHA_SITEKEY": "6Ld0r_cZAAAAAFKkweesCokUIuWgfYUIORFV0Xfj",
			"RELEASE": "228d0b36",
			"featureFlags": {
				"constructor.shotsTemplates": true,
				"experiment.interactiveHelpTour": false,
				"experiment.newMainPage": false,
				"constructor.virtualSandboxProjects": false,
				"constructor.newExport": false,
				"constructor.disconnectPages": true,
				"constructor.projectCustomCursor": true,
				"constructor.viewportMagOverrides": true,
				"constructor.contactSupportForm": false,
				"constructor.replacePictureWithoutResize": true,
				"constructor.previewSettings": false,
				"constructor.connectPages": true,
				"constructor.blocksHighlight3": true,
				"viewer.transformNotZoom": false,
				"constructor.shotsDecode": false,
				"constructor.editorRole": false,
				"experiment.plusTooltip": false,
				"constructor.helpInAccordion": false,
				"analytics.v2": false,
				"authorization.denyEmailDomains": false,
				"viewer.reactScreenshoterEntrypoint": true,
				"constructor.viewportMinimal": false,
				"viewer.reactEntrypoint": false,
				"constructor.mobileScreenshots": true,
				"viewer.monitorForLoopBlocks": false,
				"constructor.zIndex_backup": true,
				"constructor.restBulkUpdate": true,
				"constructor.blocksHighlight": true,
				"widget.modifiers": false,
				"constructor.snapClean": true,
				"constructor.equalColumns": true,
				"viewer.scaleScreenshots": true,
				"constructor.videoHelpTourAB": false,
				"constructor.preciseGuides": true,
				"constructor.blocksHighlight2": true,
				"constructor.controlsDivider": true
			}
		}
	};
	</script>
	<script>
	window.viewerConfig = {};
	viewerConfig.readymagTracker = false;
	viewerConfig.userTracker = false;
	viewerConfig.isDomainViewer = true;
	viewerConfig.customDomainProfile = window.ServerData.mags.domainForUser;
	viewerConfig.isDownloadedSource = false;
	</script>
	<style class="">
	/* Prevent page to flash white background on load */
	
	body.black {
		background-color: black;
	}
	</style>
	<script>
	RM.customAnalyticsHandlers = {
		track: [],
		event: []
	};
	</script>
	<link href="https://d1id5eheivyv24.cloudfront.net/228d0b36/dist/62.eb7037cffeb918d86f8a.js" rel="prefetch" class="">
	<link href="https://d1id5eheivyv24.cloudfront.net/228d0b36/dist/63.54ef1afd00da5f096d0a.js" rel="prefetch" class="">
	<link href="https://d1id5eheivyv24.cloudfront.net/228d0b36/dist/64.0a24ce7a57ff285f9245.js" rel="prefetch" class="">
	<link href="https://d1id5eheivyv24.cloudfront.net/228d0b36/dist/65.85bc68b1d24c51dae7ee.js" rel="prefetch" class="">
	<link href="https://d1id5eheivyv24.cloudfront.net/228d0b36/dist/66.568803f9535cff27c24e.js" rel="prefetch" class="">
	<link href="https://d1id5eheivyv24.cloudfront.net/228d0b36/dist/67.941ef892de0cf66a89f7.js" rel="prefetch" class="">
	<link href="https://d1id5eheivyv24.cloudfront.net/228d0b36/dist/viewer/bundle.95a1c920fcbded991521.css" rel="stylesheet" class="">
	<script src="https://d1id5eheivyv24.cloudfront.net/228d0b36/dist/viewer/bundle.95a1c920fcbded991521.js"></script>
	<style type="text/css" id="text_styles_paragraph_viewer" class="text_styles">
	.used-fonts-test p.paragraph-1,
	.rmwidget.text div p.paragraph-1 {
		font-family: Nobel;
		font-style: normal;
		font-weight: 700;
		font-size: 48px;
		letter-spacing: 0px;
		line-height: 60px;
		text-align: start;
		text-decoration: none;
		text-transform: none;
		color: rgb(34, 34, 34);
		padding-top: 0px;
		padding-right: 0px;
		padding-bottom: 0px;
		padding-left: 0px;
	}
	
	.used-fonts-test p.paragraph-2,
	.rmwidget.text div p.paragraph-2 {
		font-family: Georgia;
		font-style: normal;
		font-weight: 400;
		font-size: 24px;
		letter-spacing: 0px;
		line-height: 30px;
		text-align: start;
		text-decoration: none;
		text-transform: none;
		color: rgb(34, 34, 34);
		padding-top: 0px;
		padding-right: 0px;
		padding-bottom: 0px;
		padding-left: 0px;
	}
	
	.used-fonts-test p.paragraph-3,
	.rmwidget.text div p.paragraph-3 {
		font-family: Georgia;
		font-style: normal;
		font-weight: 400;
		font-size: 18px;
		letter-spacing: 0px;
		line-height: 23px;
		text-align: start;
		text-decoration: none;
		text-transform: none;
		color: rgb(34, 34, 34);
		padding-top: 0px;
		padding-right: 0px;
		padding-bottom: 0px;
		padding-left: 0px;
	}
	
	.used-fonts-test p.paragraph-4,
	.rmwidget.text div p.paragraph-4 {
		font-family: Georgia;
		font-style: italic;
		font-weight: 400;
		font-size: 14px;
		letter-spacing: 0px;
		line-height: 18px;
		text-align: start;
		text-decoration: none;
		text-transform: none;
		color: rgba(34, 34, 34, 0.5);
		padding-top: 0px;
		padding-right: 0px;
		padding-bottom: 0px;
		padding-left: 0px;
	}
	</style>
	<style type="text/css" id="text_styles_link_viewer" class="text_styles">
	.rmwidget.text div a.link-1 {
		text-decoration: none;
		color: rgb(17, 90, 127);
		background: none;
	}
	
	.rmwidget.text div a.hovered.link-1 {
		text-decoration: none;
		color: rgb(17, 90, 127);
		background: none;
	}
	
	.rmwidget.text div a.link-1 * {
		color: inherit !important;
		text-decoration: none !important;
	}
	
	.rmwidget.text div a.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 {
		text-decoration: none;
		color: rgb(0, 120, 255);
		padding-bottom: 1px;
		background: linear-gradient(to right, rgb(0, 120, 255) 0%, rgb(0, 120, 255) 100%);
		background-size: 1px 1px;
		background-position: 0 100%;
		background-repeat: repeat-x;
	}
	
	.rmwidget.text div a.current.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 {
		text-decoration: none;
		color: rgb(0, 120, 255);
		background: none;
	}
	
	.rmwidget.text div a.hovered.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 {
		text-decoration: none;
		color: rgb(0, 120, 255);
		background: none;
	}
	
	.rmwidget.text div a.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 * {
		color: inherit !important;
		text-decoration: none !important;
	}
	</style>
	<link type="text/css" rel="stylesheet" href="//fonts.googleapis.com/css?family=Source+Sans+Pro:200,200italic,300,300italic,400,400italic,600,600italic,700,700italic,900,900italic%7CRoboto:100,100italic,300,300italic,400,400italic,500,500italic,700,700italic,900,900italic%7CInter:100,200,300,400,500,600,700,800,900&amp;subset=latin,vietnamese,khmer,cyrillic-ext,greek-ext,greek,devanagari,latin-ext,cyrillic" class="fonts" data-id="20e5d120-f7c5-4913-8862-513f3a66ca27" data-provider="google" data-fonts-and-variations="Source Sans Pro|n2||Source Sans Pro|i2||Source Sans Pro|n3||Source Sans Pro|i3||Source Sans Pro|n4||Source Sans Pro|i4||Source Sans Pro|n6||Source Sans Pro|i6||Source Sans Pro|n7||Source Sans Pro|i7||Source Sans Pro|n9||Source Sans Pro|i9||Roboto|n1||Roboto|i1||Roboto|n3||Roboto|i3||Roboto|n4||Roboto|i4||Roboto|n5||Roboto|i5||Roboto|n7||Roboto|i7||Roboto|n9||Roboto|i9||Inter|n1||Inter|n2||Inter|n3||Inter|n4||Inter|n5||Inter|n6||Inter|n7||Inter|n8||Inter|n9">
	<style type="text/css" id="individual_button_style_616db3302f2a240027ad5c19_viewer" class="button_styles">
	.rmwidget.widget-button .common-button[data-id="616db3302f2a240027ad5c19"] {
		background-color: rgb(21, 71, 99);
		border-radius: 5px;
		border-width: 0px;
		border-color: rgb(0, 0, 0);
		font-family: Roboto;
		font-weight: 400;
		font-style: normal;
		color: rgb(255, 255, 255);
		font-size: 16px;
		letter-spacing: -0.1px;
	}
	
	.rmwidget.widget-button .common-button[data-id="616db3302f2a240027ad5c19"].current {
		background-color: rgb(0, 120, 255);
		border-radius: 5px;
		border-width: 0px;
		border-color: rgb(0, 0, 0);
		font-family: Arial;
		font-weight: 400;
		font-style: normal;
		color: rgb(255, 255, 255);
		font-size: 18px;
		letter-spacing: 0px;
	}
	
	.rmwidget.widget-button .common-button[data-id="616db3302f2a240027ad5c19"].hovered {
		background-color: rgb(245, 130, 32);
		border-radius: 5px;
		border-width: 0px;
		border-color: rgb(0, 0, 0);
		font-family: Roboto;
		font-weight: 400;
		font-style: normal;
		color: rgb(255, 255, 255);
		font-size: 16px;
		letter-spacing: -0.1px;
	}
	</style>
	<style type="text/css" id="individual_button_style_616db3316afaa11cd2c68aaa_viewer" class="button_styles">
	.rmwidget.widget-button .common-button[data-id="616db3316afaa11cd2c68aaa"] {
		background-color: rgb(21, 71, 99);
		border-radius: 5px;
		border-width: 0px;
		border-color: rgb(0, 0, 0);
		font-family: Roboto;
		font-weight: 400;
		font-style: normal;
		color: rgb(255, 255, 255);
		font-size: 16px;
		letter-spacing: -0.1px;
	}
	
	.rmwidget.widget-button .common-button[data-id="616db3316afaa11cd2c68aaa"].current {
		background-color: rgb(0, 120, 255);
		border-radius: 5px;
		border-width: 0px;
		border-color: rgb(0, 0, 0);
		font-family: Arial;
		font-weight: 400;
		font-style: normal;
		color: rgb(255, 255, 255);
		font-size: 18px;
		letter-spacing: 0px;
	}
	
	.rmwidget.widget-button .common-button[data-id="616db3316afaa11cd2c68aaa"].hovered {
		background-color: rgb(245, 130, 32);
		border-radius: 5px;
		border-width: 0px;
		border-color: rgb(0, 0, 0);
		font-family: Roboto;
		font-weight: 400;
		font-style: normal;
		color: rgb(255, 255, 255);
		font-size: 16px;
		letter-spacing: -0.1px;
	}
	</style>
	<style type="text/css" id="individual_button_style_616db335239f1d0014ca1362_viewer" class="button_styles">
	.rmwidget.widget-button .common-button[data-id="616db335239f1d0014ca1362"] {
		background-color: rgb(21, 71, 99);
		border-radius: 5px;
		border-width: 0px;
		border-color: rgb(0, 0, 0);
		font-family: Roboto;
		font-weight: 400;
		font-style: normal;
		color: rgb(255, 255, 255);
		font-size: 16px;
		letter-spacing: -0.1px;
	}
	
	.rmwidget.widget-button .common-button[data-id="616db335239f1d0014ca1362"].current {
		background-color: rgb(0, 120, 255);
		border-radius: 5px;
		border-width: 0px;
		border-color: rgb(0, 0, 0);
		font-family: Arial;
		font-weight: 400;
		font-style: normal;
		color: rgb(255, 255, 255);
		font-size: 18px;
		letter-spacing: 0px;
	}
	
	.rmwidget.widget-button .common-button[data-id="616db335239f1d0014ca1362"].hovered {
		background-color: rgb(245, 130, 32);
		border-radius: 5px;
		border-width: 0px;
		border-color: rgb(0, 0, 0);
		font-family: Roboto;
		font-weight: 400;
		font-style: normal;
		color: rgb(255, 255, 255);
		font-size: 16px;
		letter-spacing: -0.1px;
	}
	</style>
	<style data-styled="active" data-styled-version="5.3.0"></style>
</head>

<body>
	<div id="root"></div>
	<div id="mags">
		<div class="mag viewer-type-horizontal pages-pos-overlap">
			<div class="mag-pages-container">
				<div class="container disable-transitions">
					<div class="blackout"></div>
					<div class="page center-page neighbour">
						<div id="page-1-password-container" class="polyfill-sticky"></div>
						<div class="page-fixed-bg-container polyfill-sticky">
							<div class="rmwidget widget-background" style="background-color: #13b1bd"> </div>
						</div>
						<div class="fixed-position-container-top polyfill-sticky"></div>
						<div class="fixed-position-container polyfill-sticky"></div>
						<div class="content-scroll-wrapper has-vertical-scroll accelerated-scroll">
							<div class="content-bounds" style="width: 1280px; height: 996px;">
								<div class="page-content-container" tabindex="-1" style="width: 1024px; height: 996px; top: 0px; left: 128px;">
									<div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 25px; top: 49px; width: 951px; height: 79.5px; z-index: 305;">
										<style>
										@keyframes animation_1_1 {
											0%,
											50% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 0;
												animation-timing-function: ease-out
											}
											100% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 1;
											}
										}
										</style>
										<div class="rmwidget widget-text-v3" data-id="616db2795678b3003adb9180" style="left: 0px; top: 0px; width: 951px; height: 79.5px; z-index: 305;">
											<div class="Box-sc-n41d2v-0 TextBase___StyledBox-sc-1o28pgm-0 jXOqqG kKESck">
												<div class="text-viewer">
													<p style="line-height:53px" class="view-mode unstyled align-left"><span style="font-size:42px;font-weight:300;font-family:Roboto;font-style:normal;text-decoration:none;text-transform:none;color:rgba(255, 255, 255, 1)">Supercharge Your IT Performance and Productivity</span></p>
												</div>
											</div>
										</div>
									</div>
									<div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 25px; top: 125px; width: 248px; height: 473px; z-index: 307;">
										<style>
										@keyframes animation_2_1 {
											0%,
											39.024390243902445% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 0;
												animation-timing-function: ease-out
											}
											100% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 1;
											}
										}
										</style>
										<div class="rmwidget widget-text-v3" data-id="616db2795678b3003adb9182" style="left: 0px; top: 0px; width: 248px; height: 473px; z-index: 307;">
											<div class="Box-sc-n41d2v-0 TextBase___StyledBox-sc-1o28pgm-0 jXOqqG kKESck">
												<div class="text-viewer">
													<p style="line-height:22px" class="view-mode unstyled"><span style="font-weight:300;font-family:Roboto;font-style:normal;text-decoration:none;text-transform:none;font-size:16px;color:rgba(255, 255, 255, 1)">Every IT team knows that managing outdated on-premises systems slows down the delivery of services and drives up costs. Poor integration between data sources, processes, and tools, combined with a lack of visibility into the IT infrastructure, affects decision-making and costs. And it can harm the employee experience.
</span></p>
													<p style="line-height:22px;padding-top:10px" class="view-mode unstyled"><span style="font-weight:300;font-family:Roboto;font-style:normal;text-decoration:none;text-transform:none;font-size:16px;color:rgba(255, 255, 255, 1)">Solve these problems and create best-in-class employee experiences with a single IT platform that enables you to deliver reliable IT services, boost IT productivity, and improve decision-making in your organization.</span></p>
												</div>
											</div>
										</div>
									</div>
									<div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 1px; top: 650px; width: 1023px; height: 48px; z-index: 308;">
										<style>
										@keyframes animation_3_1 {
											0%,
											75.3846153846154% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 0;
												animation-timing-function: ease-out
											}
											100% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 1;
											}
										}
										</style>
										<div class="rmwidget widget-text-v3" data-id="616db2795678b3003adb9183" style="left: 0px; top: 0px; width: 1023px; height: 48px; z-index: 308;">
											<div class="Box-sc-n41d2v-0 TextBase___StyledBox-sc-1o28pgm-0 jXOqqG kKESck">
												<div class="text-viewer">
													<p style="line-height:25px" class="view-mode unstyled align-center"><span style="font-size:20px;font-weight:700;font-family:Roboto;font-style:normal;text-decoration:none;text-transform:none;color:rgba(255, 255, 255, 1)">With my IT service management solution, I need to:</span></p>
												</div>
											</div>
										</div>
									</div>
									<div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 844px; top: 643px; width: 156px; height: 76px; z-index: 310;">
										<style>
										@keyframes animation_4_1 {
											0% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 0;
												animation-timing-function: ease-out
											}
											100% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 1;
											}
										}
										</style>
										<div class="rmwidget widget-picture" data-id="616db30b76d32430b285b636" style="left: 19px; top: 0px; width: 115px; height: 46px; z-index: 310;"><img srcset="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/1638239/upload-38a090ff-2237-43ca-b2d0-430e69f42f92.png?w=230&amp;e=webp&amp;nll=true 2x, https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/1638239/upload-38a090ff-2237-43ca-b2d0-430e69f42f92.png?e=webp&amp;nll=true 3x" src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/1638239/upload-38a090ff-2237-43ca-b2d0-430e69f42f92.png?w=230&amp;e=webp&amp;nll=true" class="viewable" style="opacity: 1;"></div>
										<div class="rmwidget widget-picture" data-id="616db30b239f1d0014ca0db4" style="left: 0px; top: 48px; width: 156px; height: 28px; z-index: 309;"><img srcset="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/1638239/upload-fa4e5053-4e92-4890-981f-1117eb863e64.png?w=312&amp;e=webp&amp;nll=true 2x, https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/1638239/upload-fa4e5053-4e92-4890-981f-1117eb863e64.png?e=webp&amp;nll=true 3x" src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/1638239/upload-fa4e5053-4e92-4890-981f-1117eb863e64.png?w=312&amp;e=webp&amp;nll=true" class="viewable" style="opacity: 1;"></div>
									</div>
									<div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 266px; top: 704px; width: 512px; height: 48px; z-index: 311;">
										<style>
										@keyframes animation_5_1 {
											0%,
											74.19354838709677% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 0;
												animation-timing-function: ease-out
											}
											100% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 1;
											}
										}
										</style>
										<a class="maglink" href="/SERVICENOW-Supercharge-Performance-LE/2/" target="_self">
											<div class="rmwidget widget-button" data-id="616db3302f2a240027ad5c19" style="left: 0px; top: 0px; width: 512px; height: 48px; z-index: 311; border-radius: 5px;">
												<div class="common-button" data-id="616db3302f2a240027ad5c19" style="flex-direction: row;">
													<div class="icon" style="display: none; width: 18px; height: 18px; margin-right: 0px; margin-left: 0px;"></div>
													<div class="text" style="display: inline-block; width: 344px; padding-left: 0px; text-indent: -0.1px; height: 48px; line-height: 48px;">Expand technology services while reducing costs</div>
												</div>
											</div>
										</a>
									</div>
									<div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 266px; top: 772px; width: 512px; height: 50px; z-index: 312;">
										<style>
										@keyframes animation_6_1 {
											0%,
											74.19354838709677% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 0;
												animation-timing-function: ease-out
											}
											100% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 1;
											}
										}
										</style>
										<a class="maglink" href="/SERVICENOW-Supercharge-Performance-LE/2/" target="_self">
											<div class="rmwidget widget-button" data-id="616db3316afaa11cd2c68aaa" style="left: 0px; top: 0px; width: 512px; height: 50px; z-index: 312; border-radius: 5px;">
												<div class="common-button" data-id="616db3316afaa11cd2c68aaa" style="flex-direction: row;">
													<div class="icon" style="display: none; width: 18px; height: 18px; margin-right: 0px; margin-left: 0px;"></div>
													<div class="text" style="display: inline-block; width: 456px; padding-left: 0px; text-indent: -0.1px; height: 50px; line-height: 50px;">Deliver high-quality employee experiences with always-on service</div>
												</div>
											</div>
										</a>
									</div>
									<div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 265px; top: 840px; width: 512px; height: 50px; z-index: 313;">
										<style>
										@keyframes animation_7_1 {
											0%,
											74.19354838709677% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 0;
												animation-timing-function: ease-out
											}
											100% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 1;
											}
										}
										</style>
										<a class="maglink" href="/SERVICENOW-Supercharge-Performance-LE/2/" target="_self">
											<div class="rmwidget widget-button" data-id="616db335239f1d0014ca1362" style="left: 0px; top: 0px; width: 512px; height: 50px; z-index: 313; border-radius: 5px;">
												<div class="common-button" data-id="616db335239f1d0014ca1362" style="flex-direction: row;">
													<div class="icon" style="display: none; width: 18px; height: 18px; margin-right: 0px; margin-left: 0px;"></div>
													<div class="text" style="display: inline-block; width: 440px; padding-left: 0px; text-indent: -0.1px; height: 50px; line-height: 50px;">Drive operational resilience with AI-powered service operations</div>
												</div>
											</div>
										</a>
									</div>
									<div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 570px; top: 264px; width: 324px; height: 347px; z-index: 303;">
										<style>
										@keyframes animation_8_1 {
											0%,
											29.629629629629626% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 0;
												animation-timing-function: ease-out
											}
											100% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 1;
											}
										}
										</style>
										<div class="rmwidget widget-picture" data-id="616db36635f5fe00356f3a6a" style="left: 0px; top: 0px; width: 324px; height: 347px; z-index: 303;"><img srcset="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3175138/upload-e4e322d9-dc4b-425f-8a4b-d0d0eb511c97.png?w=648&amp;e=webp&amp;nll=true 2x, https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3175138/upload-e4e322d9-dc4b-425f-8a4b-d0d0eb511c97.png?e=webp&amp;nll=true 3x" src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3175138/upload-e4e322d9-dc4b-425f-8a4b-d0d0eb511c97.png?w=648&amp;e=webp&amp;nll=true" class="viewable" style="opacity: 1;"></div>
									</div>
									<div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 438px; top: 292px; width: 217px; height: 285px; z-index: 315;">
										<style>
										@keyframes animation_9_1 {
											0%,
											38.46153846153846% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 0;
												animation-timing-function: ease-out
											}
											100% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 1;
											}
										}
										</style>
										<div class="rmwidget widget-picture" data-id="616db3661ed2d1001d80c262" style="left: 0px; top: 0px; width: 217px; height: 285px; z-index: 315;"><img src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3175138/upload-1d5aea3a-c62d-43e1-9add-088824efc83f.png?e=webp&amp;nll=true" class="viewable" style="opacity: 1;"></div>
									</div>
									<div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 683px; top: 160px; width: 132.86px; height: 360px; z-index: 302;">
										<style>
										@keyframes animation_10_1 {
											0%,
											20% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 0;
												animation-timing-function: ease-out
											}
											100% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 1;
											}
										}
										</style>
										<div class="rmwidget widget-picture" data-id="616db37157133b003c7f306e" style="left: 0px; top: 0px; width: 132.86px; height: 360px; z-index: 302;"><img class="viewable" srcset="" src="https://content.readymag.com/56969df1bd02a4a3292a2178/1757071/upload-400ab93e-d1d0-4d9e-8786-f06aaf87c436.gif" style="opacity: 1;" url="https://content.readymag.com/56969df1bd02a4a3292a2178/1757071/upload-400ab93e-d1d0-4d9e-8786-f06aaf87c436.gif"></div>
									</div>
									<div class="animation-container" style="transform: matrix(0.707107, 0.707107, -0.707107, 0.707107, 0, 0); opacity: 1; left: 369.352px; top: 204.352px; width: 307.296px; height: 307.296px; z-index: 301;">
										<style>
										@keyframes animation_11_1 {
											0%,
											19.607843137254903% {
												transform: translate(0px, 0px) rotate(0deg) scale(1);
												opacity: 0;
												animation-timing-function: ease-out
											}
											50.980392156862756% {
												transform: translate(0px, 0px) rotate(0deg) scale(1);
												opacity: 1;
												animation-timing-function: linear
											}
											100% {
												transform: translate(0px, 0px) rotate(45deg) scale(1);
												opacity: 1;
											}
										}
										</style>
										<div class="rmwidget widget-picture" data-id="616db7960cf3bf00133b8aa0" style="left: 43.6482px; top: 43.6482px; width: 220px; height: 220px; z-index: 301; transform: rotate(-36deg);"><img src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3175138/upload-8e99c7f8-51d1-4993-af55-266a6da4e95c.png?e=webp&amp;nll=true" class="viewable" style="opacity: 1;"></div>
									</div>
									<div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 300px; top: 149px; width: 177px; height: 177px; z-index: 316;">
										<style>
										@keyframes animation_12_1 {
											0%,
											79.36507936507937% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 0;
												animation-timing-function: ease-out
											}
											100% {
												transform: matrix(1, 0, 0, 1, 0, 0);
												opacity: 1;
											}
										}
										</style>
										<div class="rmwidget widget-picture" data-id="616db7fcee0ca20027eb7133" style="left: 0px; top: 0px; width: 177px; height: 177px; z-index: 316;"><img srcset="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3175138/upload-06653258-d243-4237-b7d4-090725d19bf7.png?w=354&amp;e=webp&amp;nll=true 2x, https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3175138/upload-06653258-d243-4237-b7d4-090725d19bf7.png?e=webp&amp;nll=true 3x" src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3175138/upload-06653258-d243-4237-b7d4-090725d19bf7.png?w=354&amp;e=webp&amp;nll=true" class="viewable" style="opacity: 1;"></div>
									</div>
									<div class="rmwidget widget-picture" data-id="616db365454bb800333d0773" style="left: 414px; top: 243px; width: 315px; height: 329px; z-index: 314;"><img class="viewable" srcset="" src="https://content.readymag.com/56969df1bd02a4a3292a2178/1757071/upload-34f05f4f-c108-42f3-9e99-af76387f345c.gif" style="opacity: 1;" url="https://content.readymag.com/56969df1bd02a4a3292a2178/1757071/upload-34f05f4f-c108-42f3-9e99-af76387f345c.gif"></div>
								</div>
							</div>
						</div>
					</div>
					<div class="page hidden next-page neighbour">
						<div id="page-2-password-container" class="polyfill-sticky"></div>
						<div class="page-fixed-bg-container polyfill-sticky"></div>
						<div class="fixed-position-container-top polyfill-sticky"></div>
						<div class="fixed-position-container polyfill-sticky"></div>
						<div class="content-scroll-wrapper has-vertical-scroll">
							<div class="content-bounds">
								<div class="page-content-container" tabindex="-1"></div>
							</div>
						</div>
					</div>
					<div class="page hidden last next-page">
						<div id="page-3-password-container" class="polyfill-sticky"></div>
						<div class="page-fixed-bg-container polyfill-sticky"></div>
						<div class="fixed-position-container-top polyfill-sticky"></div>
						<div class="fixed-position-container polyfill-sticky"></div>
						<div class="content-scroll-wrapper has-vertical-scroll">
							<div class="content-bounds">
								<div class="page-content-container" tabindex="-1"></div>
							</div>
						</div>
					</div>
				</div>
				<div class="above-pages-container"></div>
			</div>
			<style id="page-transition-style" type="text/css" class="">
			.mag .mag-pages-container .container .page {
				-webkit-transition: all 550ms cubic-bezier(0.40, 0.24, 0.40, 1);
				transition: all 550ms cubic-bezier(0.40, 0.24, 0.40, 1);
			}
			
			.mag .mag-pages-container .container .page.center-page {
				-webkit-transition: all 545ms cubic-bezier(0.40, 0.24, 0.40, 1);
				transition: all 545ms cubic-bezier(0.40, 0.24, 0.40, 1);
			}
			</style>
			<div class="toolbar for-viewer default"> </div>
			<style id="page-position-style" type="text/css" class="">
			.mag .mag-pages-container .container {
				left: 0px;
				width: 1280px;
			}
			
			.mag .mag-pages-container .container .page {
				left: 0px;
				width: 1280px;
			}
			
			.mag .mag-pages-container .container .page.prev-page {
				-webkit-transform: translateX(0px);
				transform: translateX(0px);
			}
			
			.mag .mag-pages-container .container .page.center-page {
				-webkit-transform: translateX(0);
				transform: translateX(0);
			}
			
			.mag .mag-pages-container .container .page.next-page {
				-webkit-transform: translateX(1280px);
				transform: translateX(1280px);
			}
			</style>
		</div>
	</div>
	<div id="service-pages"></div>
	<div class="popups"></div>
	<div id="tmp"></div>
	<div id="fake" style="position: fixed; opacity: 1.0"></div>
	<div id="text-global-styles">
		<style class="">
		.align-left {
			text-align: left !important;
		}
		
		.align-center {
			text-align: center !important;
		}
		
		.align-right {
			text-align: right !important;
		}
		
		.align-justify {
			text-align: justify !important;
		}
		
		.unordered-list-item {
			padding: 0;
			margin: 0;
			list-style-type: none;
		}
		
		.unordered-list-item div[data-offset-key]:before,
		.unordered-list-item > li:before {
			white-space: nowrap;
			content: "•\00a0";
		}
		
		.ordered-list-item {
			padding: 0;
			margin: 0;
			list-style-type: none;
		}
		
		.ordered-list-item div[data-offset-key]:before,
		.ordered-list-item > li:before {
			white-space: nowrap;
			counter-increment: ordered-key;
			content: counter(ordered-key)".";
		}
		
		.paragraph-728601a3-c6ea-4ae9-b905-3d5d7b7cd420 {
			color: rgba(102, 102, 102, 1);
			font-family: Roboto;
			font-size: 10px;
			font-style: normal;
			font-weight: 400;
			letter-spacing: 0px;
			line-height: 22px;
			text-align: center;
		}
		
		.paragraph-1 {
			text-align: left;
			line-height: 60px;
			font-weight: 700;
			font-style: normal;
			font-size: 48px;
			font-family: Nobel;
			color: rgba(34, 34, 34, 1);
		}
		
		.paragraph-2 {
			text-align: left;
			line-height: 30px;
			font-weight: 400;
			font-style: normal;
			font-size: 24px;
			font-family: Georgia;
			color: rgba(34, 34, 34, 1);
		}
		
		.paragraph-3 {
			text-align: left;
			line-height: 23px;
			font-weight: 400;
			font-style: normal;
			font-size: 18px;
			font-family: Georgia;
			color: rgba(34, 34, 34, 1);
		}
		
		.paragraph-4 {
			text-align: left;
			line-height: 18px;
			font-weight: 400;
			font-style: italic;
			font-size: 14px;
			font-family: Georgia;
			color: rgba(34, 34, 34, 0.5);
		}
		
		.link-1 {
			text-decoration: none;
			padding-bottom: 1px;
			background: none;
			color: rgba(17, 90, 127, 1);
		}
		
		.link-1 * {
			color: rgba(17, 90, 127, 1);
		}
		
		.link-1 .hover,
		.link-1:hover {
			text-decoration: none;
			padding-bottom: 1px;
			background: none;
			color: rgba(17, 90, 127, 1) !important;
		}
		
		.link-1 .hover *,
		.link-1:hover * {
			color: rgba(17, 90, 127, 1) !important;
		}
		
		.link-1.current {
			text-decoration: none;
			padding-bottom: 1px;
			background: none;
			color: rgba(17, 90, 127, 1);
		}
		
		.link-1.current * {
			color: rgba(17, 90, 127, 1);
		}
		
		.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 {
			text-decoration: none;
			padding-bottom: 1px;
			background: linear-gradient(to right, rgba(0, 120, 255, 1) 0%, rgba(0, 120, 255, 1) 100%) 0 100%/1px 1px repeat-x;
			color: rgba(0, 120, 255, 1);
		}
		
		.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 * {
			color: rgba(0, 120, 255, 1);
		}
		
		.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 .hover,
		.link-5a1abc8a-c29e-44ec-8cc1-19095381f694:hover {
			text-decoration: none;
			padding-bottom: 1px;
			background: none;
			color: rgba(0, 120, 255, 1) !important;
		}
		
		.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 .hover *,
		.link-5a1abc8a-c29e-44ec-8cc1-19095381f694:hover * {
			color: rgba(0, 120, 255, 1) !important;
		}
		
		.link-5a1abc8a-c29e-44ec-8cc1-19095381f694.current {
			text-decoration: none;
			padding-bottom: 1px;
			background: none;
			color: rgba(0, 120, 255, 1);
		}
		
		.link-5a1abc8a-c29e-44ec-8cc1-19095381f694.current * {
			color: rgba(0, 120, 255, 1);
		}
		
		.default-list-style.edit-mode .editor-block-wrapper {
			display: flex;
		}
		
		.default-list-style.view-mode {
			display: flex;
		}
		
		.default-list-style.view-mode:before {
			display: inline-block;
		}
		
		.unordered-list-item.default-list-style.edit-mode .editor-block-wrapper:before {
			content: "•\00a0";
			display: inline-block;
		}
		
		.unordered-list-item.default-list-style.edit-mode div[data-offset-key]:before {
			content: "•\00a0";
			display: none;
		}
		
		.ordered-list-item.default-list-style.edit-mode .editor-block-wrapper:before {
			counter-increment: ordered-key;
			content: counter(ordered-key)".";
			display: inline-block;
			white-space: nowrap;
		}
		
		.ordered-list-item.default-list-style.edit-mode div[data-offset-key]:before {
			counter-increment: ordered-key;
			content: counter(ordered-key)".";
			display: none;
			white-space: nowrap;
		}
		
		.unordered-list-item .default-list-style.view-mode:before {
			content: "•\00a0";
		}
		</style>
	</div>
</body>

</html>