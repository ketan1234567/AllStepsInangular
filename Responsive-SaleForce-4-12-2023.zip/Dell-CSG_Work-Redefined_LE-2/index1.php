<?php
$leadtype = $_GET['name'];
$leadtype;
?>
	<html >
	
	<head>
	<meta charset="utf-8">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	
	<meta name="generator" content="Readymag" data-project="3422974" data-user="u93502920" data-is-exported="false">  
	<meta name="robots" content="noindex,nofollow">  
	
	
	
	<!--[if IE]><link rel="shortcut icon" href="https://rm-content.s3.amazonaws.com/56969df1bd02a4a3292a2178/upload-ebda98a0-c134-11e5-9ef1-39f48dd79a10_144.png" type="image/x-icon"/><![endif]-->    
	<link rel="next" href="http://biz-tech-insights.dev/DELL-CSG-Modern-Digital-Workplace-Lead-Engage/3/" class="">  
	<meta content="955357184504374" property="fb:app_id">  <meta content="website" property="og:type">  <meta content="http://biz-tech-insights.dev/p15218798/" property="og:url">  <meta content="summary_large_image" name="twitter:card">  <meta content="!" name="fragment">  <meta content="DELL_CSG_Modern-Digital-Workplace_Lead_Engage" property="og:site_name">  <meta content="https://d3n32ilufxuvd1.cloudfront.net/56969df1bd02a4a3292a2178/3422974/screenshot-36da2306-d478-4a17-a305-43b4bc857496_readyscr_1024.jpg" property="og:image">  
	<meta content="DELL_CSG_Modern-Digital-Workplace_Lead_Engage — Response" property="og:title"> 
	<title>DELL_CSG_Modern-Digital-Workplace_Lead_Engage — Response</title>     
 

 

  <link href="https://d1id5eheivyv24.cloudfront.net/9d1d07bf/dist/64.f9a05119fd603773437e.js" rel="prefetch" class=""><link href="https://d1id5eheivyv24.cloudfront.net/9d1d07bf/dist/65.c63fe19a080239ef06da.js" rel="prefetch" class=""><link href="https://d1id5eheivyv24.cloudfront.net/9d1d07bf/dist/66.aa49b2d5f98d1b1ce1dd.js" rel="prefetch" class=""><link href="https://d1id5eheivyv24.cloudfront.net/9d1d07bf/dist/67.ea8bebbecff686a02e08.js" rel="prefetch" class=""><link href="https://d1id5eheivyv24.cloudfront.net/9d1d07bf/dist/68.be669bbc13c5462cae24.js" rel="prefetch" class=""><link href="https://d1id5eheivyv24.cloudfront.net/9d1d07bf/dist/69.57c7b0f2f71f2777b66d.js" rel="prefetch" class=""><link href="https://d1id5eheivyv24.cloudfront.net/9d1d07bf/dist/viewer/bundle.610969da31bbf06df624.css" rel="stylesheet" class=""><script src="https://d1id5eheivyv24.cloudfront.net/9d1d07bf/dist/viewer/bundle.610969da31bbf06df624.js"></script><style type="text/css" id="text_styles_paragraph_viewer" class="text_styles">.used-fonts-test p.paragraph-1,
.rmwidget.text div p.paragraph-1 {
	font-family: Nobel;
	font-style: normal;
	font-weight: 700;
	font-size: 48px;
	letter-spacing: 0px;
	line-height: 60px;
	text-align: start;
	text-decoration: none;
	text-transform: none;
	color: rgb(34,34,34);
	padding-top: 0px;
	padding-right: 0px;
	padding-bottom: 0px;
	padding-left: 0px;
}

.used-fonts-test p.paragraph-2,
.rmwidget.text div p.paragraph-2 {
	font-family: Georgia;
	font-style: normal;
	font-weight: 400;
	font-size: 24px;
	letter-spacing: 0px;
	line-height: 30px;
	text-align: start;
	text-decoration: none;
	text-transform: none;
	color: rgb(34,34,34);
	padding-top: 0px;
	padding-right: 0px;
	padding-bottom: 0px;
	padding-left: 0px;
}

.used-fonts-test p.paragraph-3,
.rmwidget.text div p.paragraph-3 {
	font-family: Georgia;
	font-style: normal;
	font-weight: 400;
	font-size: 18px;
	letter-spacing: 0px;
	line-height: 23px;
	text-align: start;
	text-decoration: none;
	text-transform: none;
	color: rgb(34,34,34);
	padding-top: 0px;
	padding-right: 0px;
	padding-bottom: 0px;
	padding-left: 0px;
}

.used-fonts-test p.paragraph-4,
.rmwidget.text div p.paragraph-4 {
	font-family: Georgia;
	font-style: italic;
	font-weight: 400;
	font-size: 14px;
	letter-spacing: 0px;
	line-height: 18px;
	text-align: start;
	text-decoration: none;
	text-transform: none;
	color: rgba(34,34,34, 0.5);
	padding-top: 0px;
	padding-right: 0px;
	padding-bottom: 0px;
	padding-left: 0px;
}

</style><style type="text/css" id="text_styles_link_viewer" class="text_styles">.rmwidget.text div a.link-1 {
	text-decoration: none;
	color: rgb(17,90,127);
	background: none;
}

.rmwidget.text div a.hovered.link-1 {
	text-decoration: none;
	color: rgb(17,90,127);
	background: none;
}

.rmwidget.text div a.link-1 * {
	color: inherit !important;
	text-decoration: none !important;
}

.rmwidget.text div a.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 {
	text-decoration: none;
	color: rgb(0,120,255);
	padding-bottom: 1px;
	background: linear-gradient(to right, rgb(0,120,255) 0%, rgb(0,120,255) 100%);
	background-size: 1px 1px;
	background-position: 0 100%;
	background-repeat: repeat-x;
}

.rmwidget.text div a.current.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 {
	text-decoration: none;
	color: rgb(0,120,255);
	background: none;
}

.rmwidget.text div a.hovered.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 {
	text-decoration: none;
	color: rgb(0,120,255);
	background: none;
}

.rmwidget.text div a.link-5a1abc8a-c29e-44ec-8cc1-19095381f694 * {
	color: inherit !important;
	text-decoration: none !important;
}

</style><style type="text/css" class="typekit-kit fonts" data-id="1ba6e9af-fd03-47aa-a684-fa3172104c0d" data-provider="typekit" data-fonts-and-variations="flqd|n3||flqd|i3||flqd|n4||flqd|i4||flqd|n7||flqd|i7">@font-face{font-family:flqd;src:url(https://use.typekit.net/af/ea559d/00000000000000007735a08d/30/l?subset_id=1&fvd=n4&v=3) format("woff2"),url(https://use.typekit.net/af/ea559d/00000000000000007735a08d/30/d?subset_id=1&fvd=n4&v=3) format("woff"),url(https://use.typekit.net/af/ea559d/00000000000000007735a08d/30/a?subset_id=1&fvd=n4&v=3) format("opentype");font-weight:400;font-style:normal;font-display:auto;}</style><link type="text/css" rel="stylesheet" href="//fonts.googleapis.com/css?family=Source+Sans+Pro:200,200italic,300,300italic,400,400italic,600,600italic,700,700italic,900,900italic%7CRoboto:100,100italic,300,300italic,400,400italic,500,500italic,700,700italic,900,900italic%7CInter:100,200,300,400,500,600,700,800,900&amp;subset=latin,vietnamese,khmer,cyrillic-ext,greek-ext,greek,devanagari,latin-ext,cyrillic" class="fonts" data-id="675cea40-28d4-4945-b7bb-c88e930f2f16" data-provider="google" data-fonts-and-variations="Source Sans Pro|n2||Source Sans Pro|i2||Source Sans Pro|n3||Source Sans Pro|i3||Source Sans Pro|n4||Source Sans Pro|i4||Source Sans Pro|n6||Source Sans Pro|i6||Source Sans Pro|n7||Source Sans Pro|i7||Source Sans Pro|n9||Source Sans Pro|i9||Roboto|n1||Roboto|i1||Roboto|n3||Roboto|i3||Roboto|n4||Roboto|i4||Roboto|n5||Roboto|i5||Roboto|n7||Roboto|i7||Roboto|n9||Roboto|i9||Inter|n1||Inter|n2||Inter|n3||Inter|n4||Inter|n5||Inter|n6||Inter|n7||Inter|n8||Inter|n9"><style type="text/css" id="individual_button_style_6205389b0ba0080035ab2161_viewer" class="button_styles">.rmwidget.widget-button .common-button[data-id="6205389b0ba0080035ab2161"] {
	background-color: rgb(0,118,206);
	border-radius: 7px;
	border-width: 0px;
	border-color: rgb(0,0,0);
	font-family: Roboto;
	font-weight: 400;
	font-style: normal;
	color: rgb(255,255,255);
	font-size: 18px;
	letter-spacing: 0px;
}

.rmwidget.widget-button .common-button[data-id="6205389b0ba0080035ab2161"] .icon {
	 background-image: url("https://d3n32ilufxuvd1.cloudfront.net/56969df1bd02a4a3292a2178/61fac32ca9f5300023ce0c57/upload-d8b9775d-b02a-4e76-bebe-148bed64bf66.png");
}

.rmwidget.widget-button .common-button[data-id="6205389b0ba0080035ab2161"].current {
	background-color: rgb(0,120,255);
	border-radius: 5px;
	border-width: 0px;
	border-color: rgb(0,0,0);
	font-family: Arial;
	font-weight: 400;
	font-style: normal;
	color: rgb(255,255,255);
	font-size: 18px;
	letter-spacing: 0px;
}

.rmwidget.widget-button .common-button[data-id="6205389b0ba0080035ab2161"].current .icon {
	 background-image: url("https://rm-content.s3.amazonaws.com/56969df1bd02a4a3292a2178/1215691/upload-57c95040-e439-11e8-854a-65e6af600376.png");
}

.maglink.current .widget-button .common-button[data-id="6205389b0ba0080035ab2161"] .icon {
	 background-image: url("https://rm-content.s3.amazonaws.com/56969df1bd02a4a3292a2178/1215691/upload-57c95040-e439-11e8-854a-65e6af600376.png");
}

.rmwidget.widget-button .common-button[data-id="6205389b0ba0080035ab2161"]:hover {
	background-color: rgb(230,173,59);
	border-radius: 7px;
	border-width: 0px;
	border-color: rgb(255,255,255);
	font-family: Roboto;
	font-weight: 400;
	font-style: normal;
	color: rgb(255,255,255);
	font-size: 18px;
	letter-spacing: 0px;
}

.rmwidget.widget-button .common-button[data-id="6205389b0ba0080035ab2161"].hovered .icon {
	 background-image: url("data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjIiIGJhc2VQcm9maWxlPSJ0aW55IiBpZD0iTGF5ZXJfMSIgeD0iMHB4IiB5PSIwcHgiIHZpZXdCb3g9IjAuMjAwMDAwMjg2MTAyMjk0OTIgMC4wOTk5OTc1MjA0NDY3NzczNCAxMjcuNjAwMDA2MTAzNTE1NjIgMTI3LjcwMDAwNDU3NzYzNjcyIiB4bWw6c3BhY2U9InByZXNlcnZlIiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiBzdHlsZT0id2lkdGg6IDEwMCU7IGhlaWdodDogMTAwJTsiIGZpbGw9InJnYigyNTUsMjU1LDI1NSkiIGZpbGwtb3BhY2l0eT0iMSI+CjxwYXRoIGQ9Ik0xMjcuOCwxMjEuNHYtMy4yYzAtNC43LTEuNC02LjQtNi43LTYuNEg2LjljLTUsMC02LjcsMS42LTYuNyw2LjR2My4yYzAsNSwxLjcsNi40LDYuNyw2LjRoMTE0LjIgIEMxMjYuMiwxMjcuOCwxMjcuOCwxMjYuMiwxMjcuOCwxMjEuNHogTTc1LjgsMC4xSDUyYy03LjgsMC05LjQsMS41LTkuNCw5LjN2MzMuM0gxMC45TDY0LDk1LjhsNTMuMS01My4ySDg1LjJWOS40ICBDODUuMiwxLjYsODMuNSwwLjEsNzUuOCwwLjF6Ii8+Cjwvc3ZnPg==");
}

</style><style data-styled="active" data-styled-version="5.3.0"></style>

<style type="text/css" id="individual_button_style_616db335239f1d0014ca1362_viewer" class="button_styles">
	.rmwidget.widget-button .common-button[data-id="616db335239f1d0014ca1362"] {
		background-color: rgb(21, 71, 99);
		border-radius: 5px;
		border-width: 0px;
		border-color: rgb(0, 0, 0);
		font-family: Roboto;
		font-weight: 400;
		font-style: normal;
		color: rgb(255, 255, 255);
		font-size: 16px;
		letter-spacing: -0.1px;
	}
	
	.rmwidget.widget-button 616db3302f2a240027ad5c19[data-id="616db335239f1d0014ca1362"].current {
		background-color: rgb(0, 120, 255);
		border-radius: 5px;
		border-width: 0px;
		border-color: rgb(0, 0, 0);
		font-family: Arial;
		font-weight: 400;
		font-style: normal;
		color: rgb(255, 255, 255);
		font-size: 18px;
		letter-spacing: 0px;
	}
	
	.rmwidget.widget-button .common-button[data-id="616db335239f1d0014ca1362"]:hover {
		background-color: rgb(245, 130, 32);
		border-radius: 5px;
		border-width: 0px;
		border-color: rgb(0, 0, 0);
		font-family: Roboto;
		font-weight: 400;
		font-style: normal;
		color: rgb(255, 255, 255);
		font-size: 16px;
		letter-spacing: -0.1px;
	}
	/* Fade-in Effect Css Start Here */
	
	@-webkit-keyframes fadeIn {
		from {
			opacity: 0;
			opacity: 1\9;
			* IE9 only *
		}
		to {
			opacity: 1;
		}
	}
	
	@-moz-keyframes fadeIn {
		from {
			opacity: 0;
			opacity: 1\9;
			* IE9 only *
		}
		to {
			opacity: 1;
		}
	}
	
	@keyframes fadeIn {
		from {
			opacity: 0;
			opacity: 1\9;
			* IE9 only *
		}
		to {
			opacity: 1;
		}
	}
	
	.fade-in {
		opacity: 0;
		/* make things invisible upon start */
		-webkit-animation: fadeIn ease-in 1;
		/* call our keyframe named fadeIn, use animattion ease-in and repeat it only 1 time */
		-moz-animation: fadeIn ease-in 1;
		animation: fadeIn ease-in 1;
		-webkit-animation-fill-mode: forwards;
		/* this makes sure that after animation is done we remain at the last keyframe value (opacity: 1)*/
		-moz-animation-fill-mode: forwards;
		animation-fill-mode: forwards;
		-webkit-animation-duration: 1s;
		-moz-animation-duration: 1s;
		animation-duration: 1s;
	}
	
	.fade-in.one {
		-webkit-animation-delay: 1.5s;
		-moz-animation-delay: 1.5s;
		animation-delay: 1.5s;
	}
	
	.fade-in.two {
		-webkit-animation-delay: 2s;
		-moz-animation-delay: 2s;
		animation-delay: 2s;
	}
	
	.fade-in.three {
		-webkit-animation-delay: 3s;
		-moz-animation-delay: 3s;
		animation-delay: 3s;
	}
	
	.fade-in.four {
		-webkit-animation-delay: 3.5s;
		-moz-animation-delay: 3.5s;
		animation-delay: 3.5s;
	}
	
	.fade-in.five {
		-webkit-animation-delay: 4.5s;
		-moz-animation-delay: 4.5s;
		animation-delay: 4.5s;
	}
	
	.fade-in.six {
		-webkit-animation-delay: 9.5s;
		-moz-animation-delay: 9.5s;
		animation-delay: 9.5s;
	}
	
	.fade-in.seven {
		-webkit-animation-delay: 10.5s;
		-moz-animation-delay: 10.5s;
		animation-delay: 10.5s;
	}
	
	.fade-in.eight {
		-webkit-animation-delay: 11.5s;
		-moz-animation-delay: 11.5s;
		animation-delay: 11.5s;
	}
	
	.fade-in.nine {
		-webkit-animation-delay: 12.5s;
		-moz-animation-delay: 12.5s;
		animation-delay: 12.5s;
	}
	
	.fade-in.ten {
		-webkit-animation-delay: 13.5s;
		-moz-animation-delay: 13.5s;
		animation-delay: 13.5s;
	}
	
	.fade-in.eleven {
		-webkit-animation-delay: 14.5s;
		-moz-animation-delay: 14.5s;
		animation-delay: 14.5s;
	}
	/* Fade-in Css End Here */
	
	.text1 {
		border: none;
		background-color: transparent;
		-moz-appearance: none;
		line-height: 1.4;
		text-align: center;
		font-family: Roboto !important;
		text-transform: inherit;
		font-weight: inherit;
		font-style: inherit;
		text-decoration: inherit;
		color: inherit;
		font-size: inherit;
		letter-spacing: inherit;
	}
	
		.text1 {
			border: none;
			background-color: transparent;
			-moz-appearance: none;
			line-height: 1.4;
			text-align: center;
			font-family: Roboto !important;
			text-transform: inherit;
			font-weight: inherit;
			font-style: inherit;
			text-decoration: inherit;
			color: inherit;
			font-size: inherit;
			letter-spacing: inherit;
		}
		
		
		.<!-- slide-top {
	-webkit-animation: slide-top .5s forwards;
	        animation: slide-top 2.5s forwards;
			width:100%;
			visibility:visible;
}
@-webkit-keyframes slide-top {
  0% {
    -webkit-transform: translateY(0);
            transform: translateY(0);
            
  }
  100% {
    -webkit-transform: translateY(-800px);
            transform: translateY(-800px);
  }
} -->

.slide-top {
	-webkit-animation: slide-top 5s forwards;
	        animation: slide-top 5s forwards;
}
@-webkit-keyframes slide-top {
  0% {
    -webkit-transform: translateY(0);
            transform: translateY(0);
            
  }
  100% {
    -webkit-transform: translateY(-225px);
            transform: translateY(-225px);
  }
}




.gayab{
transition: ease-in 0.4;
}


.scale-up-center{

animation-name: animation_11_1;
animation-duration: 10s;
animation-delay:0;	   
}

@-webkit-keyframes scale-up-center {
  from {
    -webkit-transform: scale(0.5);
            transform: scale(0.5);
			opacity:1;
  }
  
  to {
    -webkit-transform: scale(1);
            transform: scale(1);
			opacity:0;
  }
}
@keyframes scale-up-center {
  0% {
    -webkit-transform: scale(0.5);
            transform: scale(0.5);
  }
  100% {
    -webkit-transform: scale(1);
            transform: scale(1);
  }
} 
@keyframes gayab {
  0%{
    opacity: 1;
  }
  100%{
    opacity: 0;
  }
}
		
		
	</style>
	
	
	
	<style>
			/* Extra small devices (phones, 600px and down) */
				@media only screen and (max-width: 600px) {
				.page-content-container{
						width: 1024px;
						height: 706px;
						top: 0;
						left:0 ;
					}
					
				}
		
		
		
		
			/* Small devices (portrait tablets and large phones, 600px and up) */
				@media only screen and (min-width: 600px) {
				.page-content-container{
						width: 1024px;
						height: 706px;
						top: 0;
						left:0 ;
						
					}
				
				}
				
				
				
			/* Medium devices (landscape tablets, 768px and up) */
				@media only screen and (max-width: 768px) {
					.page-content-container{
						width: 1024px;
						height: 706px;
						top: 0px;
						left:0 !important;
					}
				}
				
			/* Large devices (laptops/desktops, 992px and up) */
				@media only screen and (max-width: 1024px) {
					.page-content-container{
						width: 1024px;
						height: 706px;
						top: 0px;
						left:0 !important;
					}
				
				}
				
				
				
			/* Extra large devices (large laptops and desktops, 1200px and up) */
			@media only screen and (max-width: 1200px) {
				width: 1024px;
						height: 706px;
						top: 0px;
						left:0;
			}
		
		#scollbar::-webkit-scrollbar {
  display: none;
   -ms-overflow-style: none;  /* IE and Edge */
  scrollbar-width: none;  /* Firefox */
}
#scollbar::-webkit-scrollbar {
  display: none;
   -ms-overflow-style: none;  /* IE and Edge */
  scrollbar-width: none;  /* Firefox */
}

		
	</style>
	
	
	
	

</head>  <body> 

   <div id="root"></div><div id="mags">
   
<div class="mag viewer-type-horizontal pages-pos-overlap" style="overflow-y: visible; scrollbar-width: none; -ms-overflow-style: none; " id="scollbar">

		<div >
			<div class="container disable-transitions">

				<div class="blackout"></div>
		
	
	<div class="page center-page neighbour">
		<div id="page-2-password-container" class="polyfill-sticky"></div>
		<div class="page-fixed-bg-container polyfill-sticky"><div class="rmwidget widget-background" style="background-color: #ffffff">

        

        

		
	</div></div>
		<div class="fixed-position-container-top polyfill-sticky"></div>
		<div class="fixed-position-container polyfill-sticky"></div>
		<div class="content-scroll-wrapper has-vertical-scroll accelerated-scroll">
			<div class="content-bounds" style="width: 100%; height: auto;position:absolute">
			
				<div class="page-content-container" tabindex="-1" style="width: 1024px; height: auto; top: 0px; margin: 0 auto;position:relative">

				
				<div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 486px; top: 642px; width: 132px; height: 57px; z-index: 317;"><style>@keyframes animation_1_1 {
	0%, 32.43243243243243% {transform: matrix(1,0,0,1,0,0); opacity: 0; animation-timing-function: ease-out}
	100% {transform: matrix(1,0,0,1,0,0); opacity: 1; }
}
</style>

	<a class="maglink" href="form.php?name=<?php echo $leadtype; ?>" target="">
<div class="rmwidget widget-button fade-in seven" data-id="6205389b0ba0080035ab2161" style="left: 0px; top: 0px; width: 132px; height: 57px; z-index: 317; border-radius: 7px;"><div class="common-button transition" data-id="6205389b0ba0080035ab2161" style="flex-direction: row;">
        <div class="icon" style="display: inline-block; width: 29px; height: 30px; margin-right: 0px; margin-left: 0px;"></div>
    <div class="text" style="display: none; width: 16px; padding-left: 0px; text-indent: 0px; height: 57px; line-height: 57px;"></div>
	</div>
	</div>
	</a>
	</div>
	
	<div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 17px; top: 448px; width: 265px; height: 149px; z-index: 321;"><style>@keyframes animation_2_1 {
	0%, 58.333333333333336% {transform: matrix(1,0,0,1,0,0); opacity: 0; animation-timing-function: ease-out}
	100% {transform: matrix(1,0,0,1,0,0); opacity: 1; }
}
</style><div class="rmwidget widget-picture fade-in eight" data-id="6205389b0ba0080035ab2162" style="left: 0px; top: 0px; width: 265px; height: 149px; z-index: 321;"><div class="bgpic" url="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-290cdced-0ed0-417f-8989-27d32522353f.png?e=webp&amp;nll=true" style="background-image: url(&quot;https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-290cdced-0ed0-417f-8989-27d32522353f.png?e=webp&amp;nll=true&quot;); background-position: 50% 50%; box-shadow: rgb(179, 181, 181) 0px 0px 0px 1px inset; border-radius: 0px; opacity: 1;"></div><img src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-290cdced-0ed0-417f-8989-27d32522353f.png?e=webp&amp;nll=true" class="viewable saveable" style="opacity: 1;"></div></div><div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 298px; top: 547px; width: 507px; height: 76px; z-index: 318;"><style>@keyframes animation_3_1 {
	0%, 75.3846153846154% {transform: matrix(1,0,0,1,0,0); opacity: 0; animation-timing-function: ease-out}
	100% {transform: matrix(1,0,0,1,0,0); opacity: 1; }
}
</style><div class="rmwidget widget-text-v3 fade-in seven" data-id="6205389b0ba0080035ab2170" style="left: 0px; top: 0px; width: 507px; height: 76px; z-index: 318;"><div class="Box-sc-n41d2v-0 TextBase___StyledBox-sc-1o28pgm-0 jXOqqG kKESck"><div class="text-viewer"><p style="line-height:28px" class="view-mode unstyled align-center"><span style="font-weight:700;text-transform:none;font-size:22px;color:rgba(97, 74, 90, 1);font-family:Roboto;font-style:normal;letter-spacing:0.1px;text-decoration:none">Download this whitepaper provided by Dell Technologies and Intel<span style="vertical-align:baseline;position:relative;top:-0.4em;font-size:smaller">®</span> to learn more.</span></p></div></div></div></div><div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 14px; top: 28px; width: 917px; height: 46px; z-index: 319;"><style>@keyframes animation_4_1 {
	0%, 55.55555555555556% {transform: matrix(1,0,0,1,0,0); opacity: 0; animation-timing-function: ease-out}
	100% {transform: matrix(1,0,0,1,0,0); opacity: 1; }
}
</style><div class="rmwidget widget-text-v3 fade-in four" data-id="6205389b0ba0080035ab2171" style="left: 0px; top: 0px; width: 917px; height: 46px; z-index: 319;"><div class="Box-sc-n41d2v-0 TextBase___StyledBox-sc-1o28pgm-0 jXOqqG kKESck"><div class="text-viewer"><p style="line-height:46px" class="view-mode unstyled align-left"><span style="font-weight:300;font-family:Roboto;font-style:normal;text-decoration:none;text-transform:none;font-size:35px;color:rgba(97, 74, 90, 1)">Digital Workplace Accelerators Enjoy Big Rewards</span></p></div></div></div></div><div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 16px; top: 83px; width: 297px; height: 371px; z-index: 320;"><style>@keyframes animation_5_1 {
	0%, 50% {transform: matrix(1,0,0,1,0,0); opacity: 0; animation-timing-function: ease-out}
	100% {transform: matrix(1,0,0,1,0,0); opacity: 1; }
}
</style><div class="rmwidget widget-text-v3 fade-in five" data-id="6205389b0ba0080035ab2172" style="left: 0px; top: 0px; width: 297px; height: 371px; z-index: 320;"><div class="Box-sc-n41d2v-0 TextBase___StyledBox-sc-1o28pgm-0 jXOqqG kKESck"><div class="text-viewer"><p style="line-height:24px;padding-right:0;padding-top:0" class="view-mode unstyled"><span style="letter-spacing:0px;font-style:normal;font-weight:400;text-decoration:none;text-transform:none;color:rgba(97, 74, 90, 1);font-family:Roboto;font-size:15px">Is modern device technology adoption correlated to broader business success and resiliency? It seems so. The study put organizations in one of three buckets, based on their modern device technology adoption and usage: Digital Workplace Accelerators, Digital Workplace Evaluators, and Digital Workplace Reactors.</span></p><p style="line-height:24px;padding-right:0;padding-top:10px" class="view-mode unstyled"><span style="letter-spacing:0px;font-style:normal;font-weight:400;text-decoration:none;text-transform:none;color:rgba(97, 74, 90, 1);font-family:Roboto;font-size:15px">The Digital Workplace Accelerators see higher levels of productivity, are more likely to exceed customer satisfaction goals, and are positioned to adapt and thrive through uncertainty, as opposed to Digital Workplace Evaluators and Digital Workplace Reactors.</span></p></div></div></div></div><div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 840px; top: 12px; width: 241px; height: 509px; z-index: 329;"><style>@keyframes animation_6_1 {
	0%, 70.37037037037037% {transform: matrix(1,0,0,1,0,0); opacity: 0; animation-timing-function: ease-out}
	100% {transform: matrix(1,0,0,1,0,0); opacity: 1; }
}
</style><div class="rmwidget widget-shape div-instead-of-svg fade-in six" data-id="6205389b0ba0080035ab2178" style="left: 47px; top: 169px; width: 53px; height: 111px; z-index: 329; background-color: rgb(0, 118, 206); border-color: rgb(255, 255, 255); border-radius: 0px; border-style: solid; border-width: 0px; box-sizing: border-box;"></div><div class="rmwidget widget-picture fade-in six" data-id="6205389b0ba0080035ab2177" style="left: 0px; top: 0px; width: 134px; height: 293px; z-index: 328;"><img src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/1238321/upload-549474a0-f44b-11e8-babd-f9d297e5e30e.png?e=webp&amp;nll=true" class="viewable" style="opacity: 1;"></div><div class="rmwidget widget-text-v3 fade-in six" data-id="6205389b0ba0080035ab217a" style="left: 31px; top: 288px; width: 210px; height: 82px; z-index: 322;"><div class="Box-sc-n41d2v-0 TextBase___StyledBox-sc-1o28pgm-0 jXOqqG kKESck"><div class="text-viewer"><p style="line-height:58px" class="view-mode unstyled align-left"><span style="font-size:46px;font-weight:900;font-family:Roboto;font-style:normal;text-decoration:none;text-transform:none;color:rgba(0, 118, 206, 1)">40%</span></p></div></div></div><div class="rmwidget widget-text-v3 fade-in six" data-id="6205389b0ba0080035ab217b" style="left: 33px; top: 342px; width: 130px; height: 167px; z-index: 323;"><div class="Box-sc-n41d2v-0 TextBase___StyledBox-sc-1o28pgm-0 jXOqqG kKESck"><div class="text-viewer"><p style="line-height:15px;padding-right:0;padding-top:0;padding-bottom:8px" class="view-mode unstyled"><span style="letter-spacing:-0.2px;font-style:normal;font-weight:400;text-decoration:none;text-transform:none;color:rgba(97, 74, 90, 1);font-size:13px;font-family:Roboto">Digital Workplace Accelerators reported 40% more revenue by adopting technologies that keep users productive in any location</span></p><p style="line-height:12px;padding-right:0;padding-bottom:8px" class="view-mode unstyled"><span style="font-family:Roboto;text-decoration:none;text-transform:none;font-style:normal;font-weight:400;font-size:9px;color:rgba(0, 0, 0, 1)">Source: “Organizations Accelerating Their Digital Workplace Achieve Improvements”</span></p></div></div></div></div><div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 834px; top: 552px; width: 171px; height: 57px; z-index: 327;"><style>@keyframes animation_7_1 {
	0%, 42.85714285714286% {transform: matrix(1,0,0,1,0,0); opacity: 0; animation-timing-function: ease-out}
	100% {transform: matrix(1,0,0,1,0,0); opacity: 1; }
}
</style><div class="rmwidget widget-picture fade-in nine" data-id="6205389b0ba0080035ab2180" style="left: 0px; top: 0px; width: 171px; height: 22px; z-index: 324;"><img srcset="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3421547/upload-0d0b0100-a286-4cd8-b1e8-ea5e37806ab8.png?w=342&amp;e=webp&amp;nll=true 2x, https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3421547/upload-0d0b0100-a286-4cd8-b1e8-ea5e37806ab8.png?w=513&amp;e=webp&amp;nll=true 3x" src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3421547/upload-0d0b0100-a286-4cd8-b1e8-ea5e37806ab8.png?w=342&amp;e=webp&amp;nll=true" class="viewable" style="opacity: 1;"></div>

<div class="rmwidget widget-picture svg fade-in nine" data-id="6205389b0ba0080035ab2183" style="left: 54px; top: 40px; width: 63px; height: 26px; z-index: 327;">

<img srcset="https://advance.biz-tech-insights.com/Dell-CSG_Work-Redefined_LE-2/intel-logo.png?w=342&amp;e=webp&amp;nll=true 2x, https://advance.biz-tech-insights.com/Dell-CSG_Work-Redefined_LE-2/intel-logo.png?w=513&amp;e=webp&amp;nll=true 3x" src="https://advance.biz-tech-insights.com/Dell-CSG_Work-Redefined_LE-2/intel-logo.png?w=342&amp;e=webp&amp;nll=true" class="viewable" style="opacity: 1;">
												


</div></div><div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 859px; top: 645px; width: 122px; height: 59px; z-index: 326;"><style>@keyframes animation_8_1 {
	0%, 42.85714285714286% {transform: matrix(1,0,0,1,0,0); opacity: 0; animation-timing-function: ease-out}
	100% {transform: matrix(1,0,0,1,0,0); opacity: 1; }
}
</style><div class="rmwidget widget-text-v3 fade-in nine" data-id="6205389b0ba0080035ab2182" style="left: 7px; top: 0px; width: 110px; height: 10px; z-index: 326;"><div class="Box-sc-n41d2v-0 TextBase___StyledBox-sc-1o28pgm-0 jBjUfz fxqkJG"><div class="text-viewer"><p style="line-height:10px;font-family:Roboto;font-weight:500;font-size:10px" class="view-mode unstyled align-center"><span style="font-family:Roboto;color:rgba(97, 74, 90, 1);font-size:10px;letter-spacing:2.3px;font-style:normal;font-weight:500">POWERED BY:</span></p></div></div></div><div class="rmwidget widget-picture fade-in nine" data-id="6205389b0ba0080035ab2181" style="left: 0px; top: 12px; width: 122px; height: 47px; z-index: 325;"><img srcset="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/2643407/upload-60e98185-cc69-4f03-8941-1dfcb9e5a79b.png?w=244&amp;e=webp&amp;nll=true&amp;cX=23&amp;cY=7&amp;cW=213&amp;cH=82 2x, https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/2643407/upload-60e98185-cc69-4f03-8941-1dfcb9e5a79b.png?e=webp&amp;nll=true&amp;cX=23&amp;cY=7&amp;cW=213&amp;cH=82 3x" src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/2643407/upload-60e98185-cc69-4f03-8941-1dfcb9e5a79b.png?w=244&amp;e=webp&amp;nll=true&amp;cX=23&amp;cY=7&amp;cW=213&amp;cH=82" class="viewable" style="opacity: 1;"></div></div><div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 0; left: 650px; top: 124px; width: 158px; height: 90px; z-index: 330; animation-name: animation_9_1; animation-duration: 8.3s; animation-delay: 0s; animation-iteration-count: infinite; animation-direction: alternate; animation-fill-mode: none; animation-play-state: running;"><style>@keyframes animation_9_1 {
	0%, 6.024096385542168% {transform: matrix(1,0,0,1,0,0); opacity: 0; animation-timing-function: ease-in-out}
	100% {transform: matrix(1,0,0,1,74,-1); opacity: 0.84; }
}
</style><div class="rmwidget widget-picture fade-in three" data-id="620c191e6b332b0013e49ad1" style="left: 0px; top: 0px; width: 158px; height: 90px; z-index: 330;"><img srcset="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-626b22e7-f027-4f1e-a8bd-59924b34543b.png?w=316&amp;e=webp&amp;nll=true 2x, https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-626b22e7-f027-4f1e-a8bd-59924b34543b.png?e=webp&amp;nll=true 3x" src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-626b22e7-f027-4f1e-a8bd-59924b34543b.png?w=316&amp;e=webp&amp;nll=true" class="viewable" style="opacity: 1;"></div></div><div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 341px; top: 143px; width: 360px; height: 360px; z-index: 332;"><style>@keyframes animation_10_1 {
	0% {transform: translate(0px, 0px) rotate(0deg) scale(1); opacity: 0; animation-timing-function: ease-out}
	12.222222222222223% {transform: translate(0px, 0px) rotate(0deg) scale(1); opacity: 1; animation-timing-function: linear}
	100% {transform: translate(0px, 0px) rotate(360deg) scale(1); opacity: 1; }
}
</style><div class="rmwidget widget-picture" data-id="620c191e6fc77f0021388b1a" style="left: 0px; top: 0px; width: 360px; height: 360px; z-index: 332;"><img src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-0daf4210-a912-43a9-a520-d00f012afa02.png?e=webp&amp;nll=true" class="viewable" style="opacity: 1;"></div></div><div class="animation-container invisible" style="transform: matrix(1, 0, 0, 1, 0, -72); opacity: 0; left: 480px; top: 406px; width: 71px; height: 92px; z-index: 334;"><style>@keyframes animation_11_1 {
	0%, 50.793650793650805% {transform: matrix(1,0,0,1,0,0); opacity: 0; animation-timing-function: ease-in-out}
	80.95238095238095% {transform: matrix(1,0,0,1,0,-72); opacity: 1; animation-timing-function: linear}
	100% {transform: matrix(1,0,0,1,0,-72); opacity: 0; }
}
</style><div class="rmwidget widget-picture" data-id="620c191f3d62eb002b924e12" style="left: 0px; top: 0px; width: 71px; height: 92px; z-index: 334;"><img srcset="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-1b48d300-e03f-43ca-ae63-edfcaf5bd536.png?w=142&amp;e=webp&amp;nll=true 2x, https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-1b48d300-e03f-43ca-ae63-edfcaf5bd536.png?w=213&amp;e=webp&amp;nll=true 3x" src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-1b48d300-e03f-43ca-ae63-edfcaf5bd536.png?w=142&amp;e=webp&amp;nll=true" class="viewable" style="opacity: 1;"></div></div><div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, -230); opacity: 1; left: 473px; top: 314px; width: 78px; height: 169px; z-index: 335;"><style>@keyframes animation_12_1 {
	0%, 46.26865671641791% {transform: matrix(1,0,0,1,0,0); opacity: 0; animation-timing-function: ease-in-out}
	100% {transform: matrix(1,0,0,1,0,-230); opacity: 1; }
}
</style><div class="rmwidget widget-picture slide-top" data-id="620c191fc797f2003ab8c02a" style="left: 0px;top: 232px;width: 78px;height: 169px;z-index: 318;"><img srcset="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-ed0f5071-affb-4504-ae89-fbd8e536c664.png?w=156&amp;e=webp&amp;nll=true 2x, https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-ed0f5071-affb-4504-ae89-fbd8e536c664.png?w=234&amp;e=webp&amp;nll=true 3x" src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-ed0f5071-affb-4504-ae89-fbd8e536c664.png?w=156&amp;e=webp&amp;nll=true" class="viewable" style="opacity: 1;"></div></div><div class="animation-container invisible" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 0; left: 267px; top: 393px; width: 480px; height: 99.82px; z-index: 336;"><style>@keyframes animation_13_1 {
	0%, 17.441860465116278% {transform: matrix(0.001,0,0,0.001,0,0); opacity: 0; animation-timing-function: ease-out}
	48.837209302325576% {transform: matrix(1,0,0,1,0,0); opacity: 1; animation-timing-function: ease-in-out}
	100% {transform: matrix(1,0,0,1,0,0); opacity: 0; }
}
</style><div class="rmwidget widget-picture fade-in four" data-id="620c191fe40ba10016215fc4" style="left: 0px; top: 0px; width: 480px; height: 99.82px; z-index: 336;"><img srcset="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-9b0a21df-5574-40f5-8336-5afd2e246972.png?w=960&amp;e=webp&amp;nll=true 2x, https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-9b0a21df-5574-40f5-8336-5afd2e246972.png?e=webp&amp;nll=true 3x" src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-9b0a21df-5574-40f5-8336-5afd2e246972.png?w=960&amp;e=webp&amp;nll=true" class="viewable" style="opacity: 1;"></div></div><div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 304px; top: 177px; width: 105px; height: 107px; z-index: 337;"><style>@keyframes animation_14_1 {
	0%, 69.81132075471697% {transform: matrix(1,0,0,1,0,0); opacity: 0; animation-timing-function: ease-out}
	100% {transform: matrix(1,0,0,1,0,0); opacity: 1; }
}
</style><div class="rmwidget widget-picture fade-in three" data-id="620c191fe9ebd60035545ff3" style="left: 0px; top: 0px; width: 105px; height: 107px; z-index: 337;"><img srcset="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-6861b73d-2f79-40eb-b455-dff0a8642c51.png?w=210&amp;e=webp&amp;nll=true 2x, https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-6861b73d-2f79-40eb-b455-dff0a8642c51.png?e=webp&amp;nll=true 3x" src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-6861b73d-2f79-40eb-b455-dff0a8642c51.png?w=210&amp;e=webp&amp;nll=true" class="viewable" style="opacity: 1;"></div></div><div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 623px; top: 178px; width: 96px; height: 78px; z-index: 338;"><style>@keyframes animation_15_1 {
	0%, 71.42857142857143% {transform: matrix(1,0,0,1,0,0); opacity: 0; animation-timing-function: ease-out}
	100% {transform: matrix(1,0,0,1,0,0); opacity: 1; }
}
</style><div class="rmwidget widget-picture fade-in three" data-id="620c191ff27c82002b3285d9" style="left: 0px; top: 0px; width: 96px; height: 78px; z-index: 338;"><img srcset="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-7acd822d-91a6-4fd5-a5df-00b0179b97f4.png?w=192&amp;e=webp&amp;nll=true 2x, https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-7acd822d-91a6-4fd5-a5df-00b0179b97f4.png?e=webp&amp;nll=true 3x" src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-7acd822d-91a6-4fd5-a5df-00b0179b97f4.png?w=192&amp;e=webp&amp;nll=true" class="viewable" style="opacity: 1;"></div></div><div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 743px; top: 222px; width: 43px; height: 36px; z-index: 339;"><style>@keyframes animation_16_1 {
	0%, 88.60759493670885% {transform: matrix(1,0,0,1,0,0); opacity: 0; animation-timing-function: ease-out}
	100% {transform: matrix(1,0,0,1,0,0); opacity: 1; }
}
</style><div class="rmwidget widget-picture fade-in two" data-id="620c191f6fc77f0021388b49" style="left: 0px; top: 0px; width: 43px; height: 36px; z-index: 339;"><img srcset="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-0fc240a3-e55e-4aaa-af6f-6b5851b2ed95.png?w=86&amp;e=webp&amp;nll=true 2x, https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-0fc240a3-e55e-4aaa-af6f-6b5851b2ed95.png?e=webp&amp;nll=true 3x" src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-0fc240a3-e55e-4aaa-af6f-6b5851b2ed95.png?w=86&amp;e=webp&amp;nll=true" class="viewable" style="opacity: 1;"></div></div><div class="animation-container invisible" style="transform: matrix(0.707107, 0.707107, -0.707107, 0.707107, 86, 40); opacity: 0; left: 663px; top: 162px; width: 38px; height: 28px; z-index: 340;"><style>@keyframes animation_17_1 {
	0%, 48.75% {transform: translate(0px, 0px) rotate(0deg) scale(1); opacity: 0; animation-timing-function: ease-out}
	63.74999999999999% {transform: translate(0px, 0px) rotate(0deg) scale(1); opacity: 1; animation-timing-function: linear}
	72.5% {transform: translate(0px, 0px) rotate(45deg) scale(1); opacity: 1; animation-timing-function: linear}
	78.75% {transform: translate(86px, 1px) rotate(45deg) scale(1); opacity: 1; animation-timing-function: linear}
	95% {transform: translate(86px, 40px) rotate(45deg) scale(1); opacity: 1; animation-timing-function: linear}
	100% {transform: translate(86px, 40px) rotate(45deg) scale(1); opacity: 0; }
}
</style><div class="rmwidget widget-picture" data-id="620c1920504a810014662c7b" style="left: 0px; top: 0px; width: 38px; height: 28px; z-index: 340;"><img srcset="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-bf2f6100-9531-4313-8b91-d8e42a4b8ee6.png?w=76&amp;e=webp&amp;nll=true&amp;cX=0&amp;cY=0&amp;cW=77&amp;cH=57 2x, https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-bf2f6100-9531-4313-8b91-d8e42a4b8ee6.png?e=webp&amp;nll=true&amp;cX=0&amp;cY=0&amp;cW=77&amp;cH=57 3x" src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-bf2f6100-9531-4313-8b91-d8e42a4b8ee6.png?w=76&amp;e=webp&amp;nll=true&amp;cX=0&amp;cY=0&amp;cW=77&amp;cH=57" class="viewable" style="opacity: 1;"></div></div><div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 717px; top: 226px; width: 43px; height: 36px; z-index: 341;"><style>@keyframes animation_18_1 {
	0%, 86.04651162790698% {transform: matrix(1,0,0,1,0,0); opacity: 0; animation-timing-function: ease-out}
	100% {transform: matrix(1,0,0,1,0,0); opacity: 1; }
}
</style><div class="rmwidget widget-picture fade-in two" data-id="620c192040b62500217cc729" style="left: 0px; top: 0px; width: 43px; height: 36px; z-index: 341;"><img srcset="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-0fc240a3-e55e-4aaa-af6f-6b5851b2ed95.png?w=86&amp;e=webp&amp;nll=true 2x, https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-0fc240a3-e55e-4aaa-af6f-6b5851b2ed95.png?e=webp&amp;nll=true 3x" src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-0fc240a3-e55e-4aaa-af6f-6b5851b2ed95.png?w=86&amp;e=webp&amp;nll=true" class="viewable" style="opacity: 1;"></div></div><div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 769px; top: 232px; width: 37px; height: 31px; z-index: 342;"><style>@keyframes animation_19_1 {
	0%, 89.53488372093024% {transform: matrix(1,0,0,1,0,0); opacity: 0; animation-timing-function: ease-out}
	100% {transform: matrix(1,0,0,1,0,0); opacity: 1; }
}
</style><div class="rmwidget widget-picture fade-in two" data-id="620c19203d62eb002b924e22" style="left: 0px; top: 0px; width: 37px; height: 31px; z-index: 342;"><img srcset="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-0fc240a3-e55e-4aaa-af6f-6b5851b2ed95.png?w=74&amp;e=webp&amp;nll=true 2x, https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-0fc240a3-e55e-4aaa-af6f-6b5851b2ed95.png?e=webp&amp;nll=true 3x" src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-0fc240a3-e55e-4aaa-af6f-6b5851b2ed95.png?w=74&amp;e=webp&amp;nll=true" class="viewable" style="opacity: 1;"></div></div><div class="animation-container" style="transform: matrix(1, 0, 0, 1, -76, -1); opacity: 0.89; left: 384px; top: 104px; width: 90px; height: 45px; z-index: 343;"><style>@keyframes animation_20_1 {
	0%, 10.714285714285715% {transform: matrix(1,0,0,1,0,0); opacity: 0; animation-timing-function: ease-in-out}
	100% {transform: matrix(1,0,0,1,-76,-1); opacity: 0.89; }
}
</style><div class="rmwidget widget-picture fade-in three" data-id="620c1920b9968d0040bb95c0" style="left: 0px; top: 0px; width: 90px; height: 45px; z-index: 343;"><img srcset="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-11789c01-ccf9-470c-8ad2-e11d15a83b27.png?w=180&amp;e=webp&amp;nll=true 2x, https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-11789c01-ccf9-470c-8ad2-e11d15a83b27.png?w=270&amp;e=webp&amp;nll=true 3x" src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-11789c01-ccf9-470c-8ad2-e11d15a83b27.png?w=180&amp;e=webp&amp;nll=true" class="viewable" style="opacity: 1;"></div></div><div class="animation-container" style="transform: matrix(1, 0, 0, 1, 0, 0); opacity: 1; left: 447px; top: 319px; width: 141px; height: 127px; z-index: 344;"><style>@keyframes animation_21_1 {
	0%, 78.72340425531915% {transform: matrix(0.001,0,0,0.001,0,0); opacity: 0; animation-timing-function: ease-out}
	100% {transform: matrix(1,0,0,1,0,0); opacity: 1; }
}
</style><div class="rmwidget widget-picture" data-id="620c19206b332b0013e49af4" style="left: 0px; top: 0px; width: 141px; height: 127px; z-index: 344;"><img srcset="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-ab05898b-3fb9-421a-96b2-aec87bac9ef5.png?w=282&amp;e=webp&amp;nll=true 2x, https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-ab05898b-3fb9-421a-96b2-aec87bac9ef5.png?w=423&amp;e=webp&amp;nll=true 3x" src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-ab05898b-3fb9-421a-96b2-aec87bac9ef5.png?w=282&amp;e=webp&amp;nll=true" class="viewable" style="opacity: 1;"></div></div><div class="animation-container" style="transform: matrix(1, 0, 0, 1, 245, 234); opacity: 1; left: 65px; top: -61px; width: 44px; height: 53px; z-index: 345;"><style>@keyframes animation_22_1 {
	0%, 88.63636363636363% {transform: matrix(1,0,0,1,0,0); opacity: 0; animation-timing-function: ease-in-out}
	100% {transform: matrix(1,0,0,1,245,234); opacity: 1; }
}
</style><div class="rmwidget widget-picture fade-in three" data-id="620c197f40b62500217ccab2" style="left: 0px; top: 0px; width: 44px; height: 53px; z-index: 345;"><img srcset="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-896319ce-dc98-4f88-bca6-87a928241c3b.png?w=88&amp;e=webp&amp;nll=true 2x, https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-896319ce-dc98-4f88-bca6-87a928241c3b.png?w=132&amp;e=webp&amp;nll=true 3x" src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-896319ce-dc98-4f88-bca6-87a928241c3b.png?w=88&amp;e=webp&amp;nll=true" class="viewable" style="opacity: 1;"></div></div><div class="rmwidget widget-picture" data-id="6205411083f8c0003773eeba" style="left: -169px; top: -490px; width: 1402px; height: 1002px; z-index: 301;"><img src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-1eed4154-a01c-4c18-8dae-65563613fac4.jpg?e=webp" class="viewable" style="opacity: 1;"></div><div class="rmwidget widget-picture" data-id="620c191f24d160002040b515" style="left: 355px; top: 307px; width: 328px; height: 191px; z-index: 333;"><img srcset="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-680e5960-9f1d-4153-b8b6-01583acc36e0.png?w=656&amp;e=webp&amp;nll=true 2x, https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-680e5960-9f1d-4153-b8b6-01583acc36e0.png?w=984&amp;e=webp&amp;nll=true 3x" src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-680e5960-9f1d-4153-b8b6-01583acc36e0.png?w=656&amp;e=webp&amp;nll=true" class="viewable" style="opacity: 1;"></div><div class="rmwidget widget-picture" data-id="620c191e0c72d4001c8691db" style="left: 646px; top: 375px; width: 84px; height: 120px; z-index: 331;"><img srcset="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-72cec8d0-ac1a-4226-80d1-07eff0ab1304.png?w=168&amp;e=webp&amp;nll=true 2x, https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-72cec8d0-ac1a-4226-80d1-07eff0ab1304.png?e=webp&amp;nll=true 3x" src="https://d2kq0urxkarztv.cloudfront.net/56969df1bd02a4a3292a2178/3422974/upload-72cec8d0-ac1a-4226-80d1-07eff0ab1304.png?w=168&amp;e=webp&amp;nll=true" class="viewable" style="opacity: 1;"></div></div>
			</div>
		</div>
	<div class="lightbox-wrapper"></div></div>
	
	
	
	
	</div>
			<div class="above-pages-container"></div>
		</div>

		


		
	<style id="page-transition-style" type="text/css" class="">        .mag .mag-pages-container .container .page {
          -webkit-transition:	all 550ms cubic-bezier(0.40, 0.24, 0.40, 1);          transition: all 550ms cubic-bezier(0.40, 0.24, 0.40, 1);        }
        .mag .mag-pages-container .container .page.center-page {
          -webkit-transition:	all 545ms cubic-bezier(0.40, 0.24, 0.40, 1);          transition: all 545ms cubic-bezier(0.40, 0.24, 0.40, 1);        }
        </style><div class="toolbar for-viewer default">

		

		

		

		

		

		

	</div><style id="page-position-style" type="text/css" class="">        .mag .mag-pages-container .container {
          left: 0px;
          width: 1600px;
        }
        .mag .mag-pages-container .container .page {
          left: 0px;
          width: 1600px;
        }
          .mag .mag-pages-container .container .page.prev-page {
            -webkit-transform: translateX(0px) ;
            transform: translateX(0px) ;
          }
          .mag .mag-pages-container .container .page.center-page {
            -webkit-transform: translateX(0) ;
            transform: translateX(0) ;
          }
          .mag .mag-pages-container .container .page.next-page {
            -webkit-transform: translateX(1600px) ;
            transform: translateX(1600px) ;
          }</style></div></div><div id="service-pages"></div><div class="popups"></div><div id="tmp"></div> 
 <div id="fake" style="position: fixed; opacity: 1.0"></div> 

   <div id="text-global-styles"><style class="">
          .align-left { text-align: left !important; } .align-center { text-align: center !important; } .align-right { text-align: right !important; } .align-justify {
      text-align: justify !important;
      
    } 
      .unordered-list-item {
        padding: 0;
        margin: 0;
        list-style-type: none;
      }

      .unordered-list-item div[data-offset-key]:before,
      .unordered-list-item > li:before {
        white-space: nowrap;
        content: "•\00a0";
      }
     
      .ordered-list-item {
        padding: 0;
        margin: 0;
        list-style-type: none;
      }

      .ordered-list-item div[data-offset-key]:before,
      .ordered-list-item > li:before {
        white-space: nowrap;
        counter-increment: ordered-key;
        content: counter(ordered-key)".";
      }
     
           .paragraph-728601a3-c6ea-4ae9-b905-3d5d7b7cd420 { color: rgba(102, 102, 102, 1); font-family: Roboto; font-size: 10px; font-style: normal; font-weight: 400; letter-spacing: 0px; line-height: 22px; text-align: center;  }   .paragraph-1 { color: rgba(34, 34, 34, 1); font-family: Nobel; font-size: 48px; font-style: normal; font-weight: 700; line-height: 60px; text-align: left;  }   .paragraph-2 { color: rgba(34, 34, 34, 1); font-family: Georgia; font-size: 24px; font-style: normal; font-weight: 400; line-height: 30px; text-align: left;  }   .paragraph-3 { color: rgba(34, 34, 34, 1); font-family: Georgia; font-size: 18px; font-style: normal; font-weight: 400; line-height: 23px; text-align: left;  }   .paragraph-4 { color: rgba(34, 34, 34, 0.5); font-family: Georgia; font-size: 14px; font-style: italic; font-weight: 400; line-height: 18px; text-align: left;  } 
          
        
        .link-1 {
          text-decoration: none; padding-bottom: 1px; background: none; 
          color: rgba(17, 90, 127, 1); 
        }

        .link-1 * {
          color: rgba(17, 90, 127, 1); 
        }
        
        .link-1 .hover, .link-1:hover {
          text-decoration: none; padding-bottom: 1px; background: none; 
          color: rgba(17, 90, 127, 1) !important; 
        }

        .link-1 .hover *, .link-1:hover * {
            color: rgba(17, 90, 127, 1) !important; 
        }
        
        .link-1.current {
          text-decoration: none; padding-bottom: 1px; background: none; 
          color: rgba(17, 90, 127, 1); 
        }

        .link-1.current * {
          color: rgba(17, 90, 127, 1); 
        }
       
        
        .link-5a1abc8a-c29e-44ec-8cc1-19095381f694 {
          text-decoration: none; padding-bottom: 1px; background: linear-gradient(to right, rgba(0, 120, 255, 1) 0%, rgba(0, 120, 255, 1) 100%) 0 100%/1px 1px repeat-x; 
          color: rgba(0, 120, 255, 1); 
        }

        .link-5a1abc8a-c29e-44ec-8cc1-19095381f694 * {
          color: rgba(0, 120, 255, 1); 
        }
        
        .link-5a1abc8a-c29e-44ec-8cc1-19095381f694 .hover, .link-5a1abc8a-c29e-44ec-8cc1-19095381f694:hover {
          text-decoration: none; padding-bottom: 1px; background: none; 
          color: rgba(0, 120, 255, 1) !important; 
        }

        .link-5a1abc8a-c29e-44ec-8cc1-19095381f694 .hover *, .link-5a1abc8a-c29e-44ec-8cc1-19095381f694:hover * {
            color: rgba(0, 120, 255, 1) !important; 
        }
        
        .link-5a1abc8a-c29e-44ec-8cc1-19095381f694.current {
          text-decoration: none; padding-bottom: 1px; background: none; 
          color: rgba(0, 120, 255, 1); 
        }

        .link-5a1abc8a-c29e-44ec-8cc1-19095381f694.current * {
          color: rgba(0, 120, 255, 1); 
        }
       
        
        .link-style-1b4297b2-2701-485a-8c54-bc9664f9d834 {
          text-decoration: none; padding-bottom: 1px; background: linear-gradient(to right, rgba(255, 255, 255, 1) 0%, rgba(255, 255, 255, 1) 100%) 0 100%/1px 1px repeat-x; 
          color: rgba(255, 255, 255, 1); 
        }

        .link-style-1b4297b2-2701-485a-8c54-bc9664f9d834 * {
          color: rgba(255, 255, 255, 1); 
        }
        
        .link-style-1b4297b2-2701-485a-8c54-bc9664f9d834 .hover, .link-style-1b4297b2-2701-485a-8c54-bc9664f9d834:hover {
          text-decoration: none; padding-bottom: 1px; background: linear-gradient(to right, rgba(1, 148, 211, 1) 0%, rgba(1, 148, 211, 1) 100%) 0 100%/1px 1px repeat-x; 
          color: rgba(1, 148, 211, 1) !important; 
        }

        .link-style-1b4297b2-2701-485a-8c54-bc9664f9d834 .hover *, .link-style-1b4297b2-2701-485a-8c54-bc9664f9d834:hover * {
            color: rgba(1, 148, 211, 1) !important; 
        }
        
        .link-style-1b4297b2-2701-485a-8c54-bc9664f9d834.current {
          text-decoration: none; padding-bottom: 1px; background: linear-gradient(to right, rgba(0, 0, 0, 1) 0%, rgba(0, 0, 0, 1) 100%) 0 100%/1px 1px repeat-x; 
          color: rgba(0, 0, 0, 1); 
        }

        .link-style-1b4297b2-2701-485a-8c54-bc9664f9d834.current * {
          color: rgba(0, 0, 0, 1); 
        }
      
          
      .default-list-style.edit-mode .editor-block-wrapper {
        display: flex;
      }
      .default-list-style.view-mode {
        display: flex;
      }
      .default-list-style.view-mode:before {
        display: inline-block;
      }

      .unordered-list-item.default-list-style.edit-mode .editor-block-wrapper:before {
        content: "•\00a0";
        display: inline-block;
      }
      .unordered-list-item.default-list-style.edit-mode div[data-offset-key]:before {
        content: "•\00a0";
        display: none;
      }

      .ordered-list-item.default-list-style.edit-mode .editor-block-wrapper:before {
        counter-increment: ordered-key;
        content: counter(ordered-key)".";
        display: inline-block;
        white-space: nowrap;
      }
      .ordered-list-item.default-list-style.edit-mode div[data-offset-key]:before {
        counter-increment: ordered-key;
        content: counter(ordered-key)".";
        display: none;
        white-space: nowrap;
      }

      .unordered-list-item .default-list-style.view-mode:before {
        content: "•\00a0";
      }
        </style></div>
		
		
		
		</body></html>